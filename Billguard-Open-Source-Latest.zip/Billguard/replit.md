# Billguard

Orbyte invoice-review app with authenticated accounts and a separate synthetic demo.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm --filter @workspace/api-server run test` — validation, security, OCR and disposable-database HTTP regression tests
- `pnpm --filter @workspace/api-server assign-role <verified-email> <Staff|Accountant|Owner|revoke>` — deliberate first-Owner bootstrap or trusted-operator recovery; Owners manage routine access in `/workspace/team-access`
- `pnpm --filter @workspace/invoice-assistant run dev` — web app (use its managed workflow)
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Invoice demo keys: explicit `ENCRYPTION_KEY` and `HMAC_KEY`, or domain-separated HKDF keys derived at runtime from `SESSION_SECRET`. Never log secrets.

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- Invoice DB: original SQLite + better-sqlite3, with encrypted fields/files; no migration of the user's storage.
- Shared PostgreSQL/Drizzle scaffold is unused by invoices.
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/invoice-assistant/` — imported React UI and existing Orbyte theme
- `artifacts/api-server/src/lib/` — invoice persistence, corrections, actions and regression tests
- `server/rules/` — deterministic validation and workflow transitions
- `server/ocr/` — cached extraction and live Replit AI image/PDF reading
- `lib/api-spec/openapi.yaml` — generated-client contract source
- `README.md` and `docs/verification.md` — demo guide, findings and test boundaries

## Architecture decisions

Preserve the imported app rather than replacing it. Do not import its archived database,
encrypted uploads, Git history or secrets. Use synthetic fixtures only. Keep sample
simulation distinct from live AI. Do not silently fall back to cached extraction on
live failures. The existing submitter/final-approver separation is retained.

## Product

All three roles upload and submit. Owner or accountant can correct and decide.
Submission may contain errors; approval cannot. Corrections must re-evaluate all
rules, and final invoices remain read-only. Issues include explanations and
recommended corrections.

## User preferences

The user requested corrected workflow logic, extra tests, identification of app
problems and a runnable demo version.

## Gotchas

The role switcher/header only applies to the public `/demo` simulation; never use real data there.
Account routes require Clerk sessions and admin-controlled roles. New signups have no role;
the first Owner must be assigned deliberately (see README), never auto-promoted.
All assigned accounts share one business workspace, not separate tenants.
TIN checks are format and synthetic supplier matching,
not government verification. Live AI consumes Replit credits and is fallible.
Local SQLite/files are demo storage, not durable multi-instance production storage.
Keep secrets stable to retain access to encrypted records.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
