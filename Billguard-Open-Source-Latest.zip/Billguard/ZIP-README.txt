BILLGUARD — OPEN-SOURCE PROJECT ZIP

This ZIP contains the latest Billguard source: the no-sign-in synthetic invoice demo, API server, project overview animation, tests, and workspace packages.

GITHUB
1. Create an empty GitHub repository.
2. Extract this ZIP, then upload the contents of the Billguard folder into the repository.
3. Keep your own API keys and encryption secrets in the hosting platform's secure Secrets settings; never commit them.

REPLIT
The per-app artifact configurations are included. The private root .replit file is intentionally omitted because it can contain environment credentials. Configure Replit workflows after importing the project, and add any required production secrets through the Production app secrets settings.

DEMO SAFETY
The homepage opens into a public demo with simulated Staff, Accountant, and Owner roles. Demo records are shared with visitors. Use only the synthetic samples or non-sensitive test documents; do not use real invoices or personal data. Cached samples work without Runpod credentials. Live image/PDF reading is optional and requires server-side Runpod secrets plus explicit upload consent.

DEPENDENCIES
Node.js 24 and pnpm 10 are used by this workspace. Install with `pnpm install --frozen-lockfile`. API and web apps are separate Replit artifacts; their service configuration lives in each artifact's .replit-artifact/artifact.toml.

SECURITY
This source ZIP deliberately excludes .replit, .npmrc, .env files, API keys, SQLite databases, generated builds, node_modules, Git history, and uploaded source archives. Check your GitHub repository's visibility before uploading. Rotate any credentials that were previously stored as ordinary project configuration.

TESTS
Run `pnpm --filter @workspace/api-server run test` and `pnpm --filter @workspace/api-server run typecheck` from the repository root.
