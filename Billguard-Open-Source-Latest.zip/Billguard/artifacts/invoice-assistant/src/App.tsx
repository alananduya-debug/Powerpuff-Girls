import { useEffect, useMemo, useRef, useState } from 'react';
import type { ChangeEvent, ReactNode } from 'react';
import { QueryClient, QueryClientProvider, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  Activity, ArrowDownToLine, ArrowLeft, ArrowRight, BadgeCheck, Bell, Check, CheckCircle2,
  ChevronDown, ChevronRight, CircleHelp, Clock3, FileCheck2, FilePlus2, FileText, Filter,
  FolderArchive, Inbox, LockKeyhole, Menu, Search, Settings, ShieldCheck, Upload, UsersRound,
  AlertTriangle, Eye, RotateCw, Sparkles, XCircle,
} from 'lucide-react';
import type { ActivityEntry, HubUser, InvoiceListItem, InvoiceUpdateInput } from '@workspace/api-client-react';
import {
  getGetActivityQueryKey, getGetApprovedRecordsQueryKey, getGetInvoiceActivityQueryKey,
  getGetInvoiceQueryKey, getGetOcrSettingsQueryKey, getListUsersQueryKey, getGetSummaryQueryKey, getListInvoicesQueryKey,
  useApproveInvoice, useExportRecords, useGetActivity, useGetApprovedRecords,
  useGetInvoice, useGetInvoiceActivity, useGetOcrSettings, useGetSummary, useListInvoices, useListUsers,
  usePassInvoiceToOwner, useRejectInvoice, useRevealInvoiceField, useSendBackInvoice,
  useSubmitInvoice, useUpdateInvoice, useUpdateOcrSettings,
} from '@workspace/api-client-react';
import { Link, Route, Switch, useLocation, useParams } from 'wouter';
import NotFound from '@/pages/not-found';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import './styles.css';
import { isDemo, apiPath } from './workspace';
import { DemoShell } from './demo-shell';
import { AuthShell } from './auth';
import { TeamAccessPage } from './pages/team-access';
import { flushPendingCorrections, registerCorrectionGuard } from './pending-corrections';

const client = new QueryClient({ defaultOptions: { queries: { staleTime: 4_000, retry: 1, refetchInterval: 8_000, refetchOnWindowFocus: true } } });
const header = (id: string): { headers: Record<string, string> } => ({ headers: isDemo ? { 'X-Demo-User-Id': id } : {} });
const errMsg = (error: unknown, fallback = 'Something went wrong. Please try again.') => {
  const data = (error as { data?: { error?: string } | null } | null)?.data;
  if (data && typeof data.error === 'string' && data.error) return data.error;
  return error instanceof Error && error.message ? error.message : fallback;
};
const SUPPLIERS = [
  { id: 'bumi-office', name: 'Bumi Office Supply Sdn Bhd' },
  { id: 'serene-pantry', name: 'Serene Pantry Trading' },
  { id: 'sinar-print', name: 'Sinar Printworks' },
  { id: 'northstar-it', name: 'Northstar IT Services' },
  { id: 'ming-hua', name: '明华文具贸易有限公司' },
];
type Sample = { fileName: string; label: string; description: string };
type DemoInfo = { demo: boolean; liveAiConfigured: boolean; tinVerification: string };
type Role = HubUser['role'];

function AppFrame() {
  const [location, navigate] = useLocation();
  const [selectedId, setSelectedId] = useState(() => isDemo ? localStorage.getItem('invoice-hub-user') || '' : '');
  const [mobileOpen, setMobileOpen] = useState(false);
  const [noticeOpen, setNoticeOpen] = useState(false);
  const usersQuery = useListUsers({ query: { queryKey: getListUsersQueryKey(), refetchInterval: 8_000 }, request: header(selectedId) });
  const infoQuery = useQuery<DemoInfo>({ queryKey: ['demo-info'], enabled: isDemo, queryFn: async () => { const r = await fetch(apiPath('/api/demo/info')); if (!r.ok) throw new Error('n/a'); return r.json(); }, retry: false, refetchInterval: false });
  const users = usersQuery.data || [];
  const currentUser = usersQuery.isError ? undefined : users.find((user) => user.id === selectedId) || users[0];
  useEffect(() => {
    if (currentUser && currentUser.id !== selectedId) {
      setSelectedId(currentUser.id);
      if (isDemo) localStorage.setItem('invoice-hub-user', currentUser.id);
    }
  }, [currentUser, selectedId]);
  const onUserChange = async (id: string) => {
    if (!(await flushPendingCorrections())) return;
    void client.cancelQueries();
    client.clear();
    setSelectedId(id);
    localStorage.setItem('invoice-hub-user', id);
    navigate('/');
  };
  const navItems = [
    { href: '/', label: 'Inbox', icon: Inbox },
    ...(currentUser?.role !== 'Staff' ? [{ href: '/approvals', label: 'Approvals', icon: BadgeCheck }] : []),
    ...(currentUser?.role === 'Owner' ? [{ href: '/records', label: 'Records', icon: FolderArchive }] : []),
    { href: '/activity', label: 'Activity', icon: Activity },
    ...(!isDemo && currentUser?.role === 'Owner' ? [{ href: '/team-access', label: 'Team access', icon: UsersRound }] : []),
    ...(currentUser?.role === 'Owner' ? [{ href: '/settings', label: 'Settings', icon: Settings }] : []),
  ];
  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileOpen ? 'sidebar-open' : ''}`}>
        <Link href="/" className="brand" onClick={(event) => { event.preventDefault(); void flushPendingCorrections().then((saved) => { if (saved) { setMobileOpen(false); navigate('/'); } }); }}>
          <span className="brand-mark"><span>B</span></span>
          <span className="brand-name">Billguard</span>
        </Link>
        <div className="workspace-tag"><span className="workspace-dot" /> {isDemo ? 'SIMULATED WORKSPACE' : 'ACCOUNT WORKSPACE'}</div>
        <div className="side-label">WORKSPACE</div>
        <nav className="primary-nav" aria-label="Main navigation">
          {navItems.map(({ href, label, icon: Icon }) => (
            <Link key={href} href={href} onClick={(event) => { event.preventDefault(); void flushPendingCorrections().then((saved) => { if (saved) { setMobileOpen(false); navigate(href); } }); }} className={`nav-link ${location === href || (href === '/' && location.startsWith('/review')) ? 'nav-active' : ''}`} data-testid={`link-nav-${label.toLowerCase()}`}>
              <Icon size={18} strokeWidth={1.8} /><span>{label}</span>
              {label === 'Approvals' && currentUser?.role === 'Owner' ? <span className="nav-dot" /> : null}
            </Link>
          ))}
        </nav>
        <div className="side-bottom">
          <div className="security-card">
            <div className="security-icon"><ShieldCheck size={17} /></div>
            <div><strong>{isDemo ? 'Synthetic data only' : 'Authenticated workspace'}</strong><span>{isDemo ? 'Do not upload real invoices or personal data.' : 'Access is controlled by your assigned role.'}</span></div>
          </div>
          <div className="nav-help"><CircleHelp size={16} /> <span>About this workspace</span></div>
        </div>
      </aside>
      {mobileOpen && <button className="mobile-scrim" aria-label="Close navigation" onClick={() => setMobileOpen(false)} />}
      <section className="main-column">
        <header className="topbar">
          <button className="mobile-menu icon-button" aria-label="Open navigation" onClick={() => setMobileOpen((v) => !v)}><Menu size={19} /></button>
          <div className="breadcrumb"><span>Billguard</span><ChevronRight size={14} /><b>{navItems.find((item) => item.href === location)?.label || (location.startsWith('/review') ? 'Invoice review' : 'Workspace')}</b></div>
          <div className="top-actions">
            <span className="environment-pill"><span /> {isDemo ? 'Demo environment' : 'Account environment'}</span>
            <button className="icon-button notice-button" aria-label="Workspace notices" onClick={() => setNoticeOpen((open) => !open)}><Bell size={18} /><i /></button>
            <label className="user-switcher">
              <span className="avatar">{currentUser?.name?.split(' ').map((p) => p[0]).join('').slice(0, 2) || '—'}</span>
              <span className="user-meta"><strong>{currentUser?.name || (usersQuery.isLoading ? 'Loading team…' : 'No user available')}</strong><small>{currentUser?.role || 'Workspace'}</small></span>
              {isDemo && <ChevronDown size={15} />}
              {isDemo && <select aria-label="Switch workspace user" value={currentUser?.id || ''} onChange={(event) => onUserChange(event.target.value)} disabled={!users.length} data-testid="select-current-user">
                {users.map((user) => <option key={user.id} value={user.id}>{user.name} · {user.role}</option>)}
              </select>}
            </label>
          </div>
        </header>
        <div className="demo-banner" role="note" data-testid="banner-demo-notice"><AlertTriangle size={15} /><span><b>Public test workspace—non-sensitive test data only.</b> Other visitors can view shared records. The user switcher simulates roles, not authentication. In Live AI mode, uploads are sent to Runpod. TIN checks are format and supplier matching, not government verification.</span></div>
        {noticeOpen && <div className="notice-popover"><strong>All caught up</strong><span>New invoice activity will appear in your workspace timeline.</span><button onClick={() => setNoticeOpen(false)} aria-label="Dismiss notices"><XCircle size={14} /></button></div>}
        {currentUser ? (
          <Switch>
            <Route path="/">{() => <InboxPage key={currentUser.id} user={currentUser} />}</Route>
            <Route path="/review/:id">{() => <ReviewRoute user={currentUser} />}</Route>
            <Route path="/approvals">{() => currentUser.role === 'Staff' ? <RestrictedPage /> : <ApprovalsPage user={currentUser} />}</Route>
            <Route path="/records">{() => currentUser.role === 'Owner' ? <RecordsPage user={currentUser} /> : <RestrictedPage />}</Route>
            <Route path="/activity">{() => <ActivityPage user={currentUser} />}</Route>
            <Route path="/team-access">{() => !isDemo && currentUser.role === 'Owner' ? <TeamAccessPage currentUserId={currentUser.id} /> : <RestrictedPage />}</Route>
            <Route path="/settings">{() => <SettingsPage user={currentUser} />}</Route>
            <Route component={NotFound} />
          </Switch>
        ) : (
          <main className="page-content"><div className="page-heading"><div><div className="eyebrow">BILLGUARD</div><h1>Getting your workspace ready</h1><p>{usersQuery.isError ? errMsg(usersQuery.error) : 'Connecting to your workspace.'}</p></div></div><LoadingPanel label={usersQuery.isError ? 'Workspace access unavailable.' : 'Loading workspace…'} retry={() => usersQuery.refetch()} /></main>
        )}
        <footer className="app-footer"><span>Tax treatment is decided by your accountant.</span><span>This app prepares records only. It never submits invoices to an authority or makes payments, and does not provide tax advice.</span></footer>
      </section>
    </div>
  );
}

function App() {
  return <QueryClientProvider client={client}>{isDemo ? <DemoShell><AppFrame /></DemoShell> : <AuthShell><AppFrame /></AuthShell>}</QueryClientProvider>;
}
export default App;

function PageHeader({ eyebrow, title, children }: { eyebrow: string; title: string; children?: ReactNode }) {
  return <div className="page-heading"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1></div><div className="heading-actions">{children}</div></div>;
}

function RestrictedPage() {
  return <main className="page-content"><Link href="/" className="back-link">Back to inbox</Link><EmptyState title="This page is not available to your role" text="Your inbox shows the invoice statuses you are allowed to access." /></main>;
}

function LoadingPanel({ label = 'Loading your workspace…', retry }: { label?: string; retry?: () => void }) {
  return <div className="loading-panel"><div className="skeleton-line wide" /><div className="skeleton-line" /><div className="loading-copy">{label}</div>{retry && <Button variant="outline" onClick={retry}><RotateCw size={15} /> Try again</Button>}</div>;
}

function StatusPill({ status }: { status: string }) {
  const cls = status.toLowerCase().replaceAll(' ', '-');
  return <span className={`status-pill status-${cls}`}><i />{status}</span>;
}

function SecureBadge() { return <span className="secure-badge"><LockKeyhole size={12} /> Masked by default</span>; }

function Workflow({ active }: { active: number }) {
  const labels = ['Staff', 'Accountant', 'Owner'];
  return <div className="workflow">
    {labels.map((label, index) => <div className={`workflow-step ${index < active ? 'step-done' : ''} ${index === active ? 'step-current' : ''}`} key={label}>
      <span className="workflow-node">{index < active ? <Check size={13} /> : index + 1}</span><span>{label}</span>
      {index < labels.length - 1 && <i className={`workflow-line ${index < active ? 'line-done' : ''}`} />}
    </div>)}
  </div>;
}

function roleStep(status: string) {
  if (status === 'Approved' || status === 'Rejected') return 3;
  if (status === 'Awaiting approval') return 2;
  if (status === 'In review') return 1;
  return 0;
}

function Metric({ icon: Icon, label, value, tone, caption }: { icon: typeof Inbox; label: string; value: number; tone: string; caption: string }) {
  return <div className={`metric-card metric-${tone}`}><div className="metric-top"><span className="metric-icon"><Icon size={17} /></span><span>{caption}</span></div><strong className="metric-number">{value}</strong><span className="metric-label">{label}</span></div>;
}

function InboxPage({ user }: { user: HubUser }) {
  const ocr = useGetOcrSettings({ request: header(user.id) });
  const [liveConsent, setLiveConsent] = useState(false);
  const query = useListInvoices({ request: header(user.id) });
  const summaryQuery = useGetSummary({ request: header(user.id) });
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('All');
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState('');
  const [uploadNotice, setUploadNotice] = useState('');
  const queryClient = useQueryClient();
  const [, navigate] = useLocation();
  const rows = query.data || [];
  const statuses = user.role === 'Staff' ? ['Draft', 'Needs fixes', 'Rejected'] : user.role === 'Accountant' ? ['In review', 'Awaiting approval'] : ['Draft', 'Needs fixes', 'In review', 'Awaiting approval', 'Approved', 'Rejected'];
  const summary = summaryQuery.data;
  const filtered = useMemo(() => rows.filter((row) => {
    const matchesSearch = `${row.supplier} ${row.invoiceNumberMasked} ${row.fileName}`.toLowerCase().includes(search.toLowerCase());
    return matchesSearch && (filter === 'All' || row.status === filter);
  }), [rows, search, filter]);
  const upload = async (file?: File) => {
    if (!file) return;
    if (ocr.data?.mode === 'live' && !liveConsent) { setUploadError('Confirm the Live AI upload notice first.'); return; }
    setUploading(true); setUploadError(''); setUploadNotice('');
    const form = new FormData(); form.append('file', file);
    try {
      const response = await fetch(apiPath('/api/invoices/upload'), { method: 'POST', headers: { ...header(user.id).headers, ...(liveConsent ? { 'X-Live-AI-Consent': 'yes' } : {}) }, body: form });
      const body = await response.json().catch(() => null) as { error?: string; source?: string } | null;
      if (!response.ok) throw new Error(body?.error || `Upload failed (HTTP ${response.status}).`);
      setUploadNotice(body?.source === 'cached-fallback'
        ? 'Live reading was unavailable; a saved sample extraction was used.'
        : body?.source === 'live' ? 'Invoice read with live OCR.' : 'Invoice read with the saved extraction.');
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: getListInvoicesQueryKey() }),
        queryClient.invalidateQueries({ queryKey: getGetSummaryQueryKey() }),
      ]);
    } catch (error) { setUploadError(error instanceof Error ? error.message : 'Upload failed.'); }
    finally { setUploading(false); }
  };
  const handleFiles = (event: ChangeEvent<HTMLInputElement>) => { void upload(event.target.files?.[0]); event.target.value = ''; };
  if (query.isLoading || summaryQuery.isLoading) return <main className="page-content"><PageHeader eyebrow="INVOICE WORKSPACE" title="Good to see you" /><LoadingPanel /></main>;
  if (query.isError || summaryQuery.isError) return <main className="page-content"><PageHeader eyebrow="INVOICE WORKSPACE" title="Your inbox" /><LoadingPanel label="We couldn't load invoices just now." retry={() => { void query.refetch(); void summaryQuery.refetch(); }} /></main>;
  const queueLabel = user.role === 'Owner' ? 'ready for your approval' : user.role === 'Accountant' ? 'waiting for your review' : 'needing your attention';
  return <main className="page-content">
    <PageHeader eyebrow={`${user.role.toUpperCase()} · INVOICE WORKSPACE`} title={`Good ${greeting()}, ${user.name.split(' ')[0]}.`}>
      {<label className={`button-primary upload-button ${uploading ? 'disabled' : ''}`}><Upload size={16} />{uploading ? 'Reading your invoice…' : user.role === 'Accountant' ? 'Upload & submit' : 'Upload invoice'}<input type="file" accept=".pdf,.png,.jpg,.jpeg,.webp,.svg" onChange={handleFiles} disabled={uploading || (ocr.data?.mode === 'live' && !liveConsent)} data-testid="input-upload-invoice" /></label>}
    </PageHeader>
    <p className="permission-note">{user.role === 'Owner' ? 'Owner access: all invoices and statuses.' : `Your role can access: ${statuses.join(', ')}.`}{user.role === 'Accountant' && ' Uploading or loading a sample submits it directly for review.'}</p>
    {ocr.data?.mode === 'live' && <div className="permission-note" role="note"><label><input type="checkbox" checked={liveConsent} onChange={(event) => setLiveConsent(event.target.checked)} data-testid="checkbox-live-consent" /> I consent to sending non-sensitive test invoices to Runpod. These shared records are visible to other testers. PDFs: up to 3 pages; PDF/PNG/JPEG/WebP: up to 15 MB. Provider charges apply.</label></div>}
    {isDemo && <SamplePicker user={user} onLoaded={(id) => navigate(`/review/${id}`)} />}
    <div className="overview-strip"><div className="overview-intro"><div className="overview-icon"><Sparkles size={17} /></div><div><strong>{summary?.pendingForRole || 0} {summary?.pendingForRole === 1 ? 'invoice' : 'invoices'} {queueLabel}</strong><p>Every invoice moves through a clear, human review before it becomes a record.</p></div></div><Workflow active={user.role === 'Staff' ? 0 : user.role === 'Accountant' ? 1 : 2} /></div>
    <section className="metric-grid" aria-label="Invoice overview">
      <Metric icon={FileText} label="Accessible invoices" value={summary?.total || 0} tone="ink" caption="Visible to your role" />
      <Metric icon={Clock3} label="In review" value={summary?.inReview || 0} tone="blue" caption="With the accountant" />
      <Metric icon={BadgeCheck} label="Awaiting approval" value={summary?.awaitingApproval || 0} tone="gold" caption="Owner's next step" />
      <Metric icon={AlertTriangle} label="Needs fixes" value={summary?.needsFixes || 0} tone="gold" caption="Returned for correction" />
      <Metric icon={CheckCircle2} label="Approved" value={summary?.approved || 0} tone="sage" caption="Owner approved" />
      <Metric icon={FileCheck2} label="Ready records" value={summary?.readyRecords || 0} tone="sage" caption="Available to export" />
    </section>
    {uploading && <div className="inline-processing" role="status"><Sparkles size={15} />Reading your invoice… This can take up to 90 seconds.</div>}
    {uploadError && <div className="inline-error" role="alert"><AlertTriangle size={16} />{uploadError}</div>}
    {uploadNotice && <div className="inline-success" role="status"><CheckCircle2 size={16} />{uploadNotice}</div>}
    <section className="data-section">
      <div className="section-head"><div><div className="section-kicker">YOUR WORK QUEUE</div><h2>Invoices <span className="count-chip">{rows.length}</span></h2></div><div className="table-tools"><label className="search-box"><Search size={16} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search invoices" aria-label="Search invoices" data-testid="input-search-invoices" /></label><label className="filter-select"><Filter size={14} /><select value={filter} onChange={(e) => setFilter(e.target.value)} aria-label="Filter invoice status" data-testid="select-invoice-status"><option>All</option>{statuses.map((item) => <option key={item}>{item}</option>)}</select></label></div></div>
      {filtered.length ? <InvoiceTable rows={filtered} /> : <EmptyState title={search || filter !== 'All' ? 'No matching invoices' : 'A fresh start for your records'} text={search || filter !== 'All' ? 'Try another search or status filter.' : rows.length ? 'Nothing is waiting in this view. New work will appear here when it is ready.' : 'Upload an invoice file, or load a demo sample above, to begin a reviewable workflow.'} action={!rows.length ? <label className="button-primary upload-button"><FilePlus2 size={16} /> Upload first invoice<input type="file" accept=".pdf,.png,.jpg,.jpeg,.webp,.svg" onChange={handleFiles} data-testid="input-upload-first" /></label> : undefined} />}
    </section>
    <div className="notice-band"><LockKeyhole size={16} /><span>Invoice values are masked until an authorized reviewer chooses to reveal a single field.</span><SecureBadge /></div>
  </main>;
}

function SamplePicker({ user, onLoaded }: { user: HubUser; onLoaded: (id: string) => void }) {
  const queryClient = useQueryClient();
  const samples = useQuery<Sample[]>({ queryKey: ['demo-samples'], queryFn: async () => { const r = await fetch(apiPath('/api/demo/samples')); if (!r.ok) throw new Error('Samples unavailable'); return r.json(); }, refetchInterval: false });
  const ocr = useGetOcrSettings({ request: header(user.id) });
  const [busy, setBusy] = useState('');
  const [error, setError] = useState('');
  const load = async (fileName: string) => {
    setBusy(fileName); setError('');
    try {
      const r = await fetch(apiPath(`/api/demo/load/${encodeURIComponent(fileName)}`), { method: 'POST', ...header(user.id) });
      const body = await r.json().catch(() => null) as { id?: string; error?: string } | null;
      if (!r.ok || !body?.id) throw new Error(body?.error || `Sample could not be loaded (HTTP ${r.status}).`);
      await Promise.all([queryClient.invalidateQueries({ queryKey: getListInvoicesQueryKey() }), queryClient.invalidateQueries({ queryKey: getGetSummaryQueryKey() }), queryClient.invalidateQueries({ queryKey: getGetActivityQueryKey() })]);
      onLoaded(body.id);
    } catch (e) { setError(errMsg(e)); } finally { setBusy(''); }
  };
  return <section className="sample-picker" aria-label="Demo samples" data-testid="section-demo-samples">
    <div className="sample-head"><div><span className="section-kicker">DEMO SAMPLES</span><h2>Try a synthetic invoice</h2></div>{ocr.data && <span className="mode-chip" data-testid="text-ocr-mode">{ocr.data.mode === 'cached' ? 'Cached sample mode: a simulation, not real AI' : 'Live AI mode'}</span>}</div>
    <p>Each sample creates an editable invoice under {user.name} using saved sample results, even in Live mode. Corrections save automatically. To test Runpod with an image or PDF, enable Live AI in Owner settings, then use Upload invoice.</p>
    {samples.isLoading ? <div className="mini-loading">Loading samples…</div> : samples.isError ? <div className="inline-error"><AlertTriangle size={16} />Demo samples are unavailable right now.<Button variant="outline" onClick={() => void samples.refetch()}>Retry</Button></div> : <div className="sample-grid">{(samples.data || []).map((sample) => <div className="sample-card" key={sample.fileName}><strong>{sample.label}</strong><span>{sample.description}</span><div className="sample-actions"><Button onClick={() => void load(sample.fileName)} disabled={!!busy} data-testid={`button-load-${sample.fileName}`}>{busy === sample.fileName ? 'Loading…' : 'Load sample'}</Button><a className="sample-download" href={apiPath(`/api/demo/samples/${encodeURIComponent(sample.fileName)}`)} download={sample.fileName}><ArrowDownToLine size={13} /> Download</a></div></div>)}</div>}
    {error && <div className="inline-error" role="alert"><AlertTriangle size={16} />{error}</div>}
  </section>;
}

function greeting() {
  const hour = new Date().getHours();
  return hour < 12 ? 'morning' : hour < 18 ? 'afternoon' : 'evening';
}

function InvoiceTable({ rows }: { rows: InvoiceListItem[] }) {
  return <div className="table-wrap"><table className="invoice-table"><thead><tr><th>Supplier</th><th>Invoice</th><th>Date</th><th>Amount</th><th>Status</th><th>Review</th></tr></thead><tbody>{rows.map((row) => <tr key={row.id} data-testid={`row-invoice-${row.id}`}><td><Link href={`/review/${row.id}`} className="supplier-cell"><span className="file-symbol"><FileText size={17} /></span><span><strong>{row.supplier}</strong><small>{row.fileName}</small></span></Link></td><td><span className="masked-data">{row.invoiceNumberMasked}</span></td><td>{formatDate(row.date)}</td><td><span className="masked-data">{row.currency} {row.totalMasked}</span></td><td><StatusPill status={row.status} /></td><td><Link className="row-link" href={`/review/${row.id}`}>Open <ArrowRight size={14} /></Link>{row.warnings > 0 && <span className="warning-count"><AlertTriangle size={12} /> {row.warnings}</span>}</td></tr>)}</tbody></table></div>;
}

function EmptyState({ title, text, action }: { title: string; text: string; action?: ReactNode }) {
  return <div className="empty-state"><div className="empty-art"><div className="empty-paper"><FileText size={24} /></div><span className="empty-spark" /></div><h3>{title}</h3><p>{text}</p>{action}</div>;
}

function ReviewRoute({ user }: { user: HubUser }) {
  const params = useParams<{ id: string }>();
  return <ReviewPage key={`${user.id}:${params.id}`} user={user} invoiceId={params.id || ''} />;
}

function ReviewPage({ user, invoiceId }: { user: HubUser; invoiceId: string }) {
  const queryClient = useQueryClient();
  const [, navigate] = useLocation();
  const options = { query: { queryKey: getGetInvoiceQueryKey(invoiceId), enabled: !!invoiceId }, request: header(user.id) };
  const invoiceQuery = useGetInvoice(invoiceId, options);
  const activityQuery = useGetInvoiceActivity(invoiceId, { query: { queryKey: getGetInvoiceActivityQueryKey(invoiceId), enabled: !!invoiceId }, request: header(user.id) });
  const update = useUpdateInvoice({ request: header(user.id) });
  const reveal = useRevealInvoiceField({ request: header(user.id) });
  const submit = useSubmitInvoice({ request: header(user.id) });
  const sendBack = useSendBackInvoice({ request: header(user.id) });
  const passOwner = usePassInvoiceToOwner({ request: header(user.id) });
  const approve = useApproveInvoice({ request: header(user.id) });
  const reject = useRejectInvoice({ request: header(user.id) });
  const [comment, setComment] = useState('');
  const [actionError, setActionError] = useState('');
  const [revealed, setRevealed] = useState<Record<string, string>>({});
  const [edits, setEdits] = useState<Record<string, string>>({});
  const editsRef = useRef(edits);
  editsRef.current = edits;
  const savePromise = useRef<Promise<boolean> | null>(null);
  const autoSave = useRef<() => Promise<boolean>>(async () => true);
  const [notice, setNotice] = useState('');
  const [fileUrl, setFileUrl] = useState('');
  const [fileError, setFileError] = useState('');
  const invoice = invoiceQuery.data;
  const isStaff = user.role === 'Staff';
  const editableStatus = !!invoice && ['Draft', 'Needs fixes'].includes(invoice.status);
  const canEditInvoice = !!invoice && (isStaff ? editableStatus : editableStatus || ['In review', 'Awaiting approval'].includes(invoice.status));
  const canEditField = (field: string) => {
    if (!canEditInvoice) return false;
    if (!isStaff) return true;
    const warningField = field.startsWith('lineItems.') ? 'lineItems' : field;
    return !!invoice?.warnings.some((warning) =>
      warning.field === warningField ||
      (warningField === 'supplier' && warning.field === 'supplierId') ||
      (warningField === 'lineItems' && warning.field === 'subtotal')
    );
  };
  const canReveal = !isStaff;
  const busy = update.isPending || reveal.isPending || submit.isPending || sendBack.isPending || passOwner.isPending || approve.isPending || reject.isPending;
  const invalidateAll = async () => Promise.all([
    queryClient.invalidateQueries({ queryKey: getGetInvoiceQueryKey(invoiceId) }),
    queryClient.invalidateQueries({ queryKey: getGetInvoiceActivityQueryKey(invoiceId) }),
    queryClient.invalidateQueries({ queryKey: getGetActivityQueryKey() }),
    queryClient.invalidateQueries({ queryKey: getListInvoicesQueryKey() }),
    queryClient.invalidateQueries({ queryKey: getGetSummaryQueryKey() }),
    queryClient.invalidateQueries({ queryKey: getGetApprovedRecordsQueryKey() }),
  ]);
  useEffect(() => {
    if (!invoice) return;
    let active = true;
    let url = '';
    setFileError('');
    fetch(apiPath(`/api/invoices/${encodeURIComponent(invoiceId)}/file`), header(user.id))
      .then((response) => { if (!response.ok) throw new Error('Original file is not available.'); return response.blob(); })
      .then((blob) => { if (!active) return; url = URL.createObjectURL(blob); setFileUrl(url); })
      .catch(() => { if (active) setFileError('The original file could not be opened.'); });
    return () => { active = false; if (url) URL.revokeObjectURL(url); setFileUrl(''); };
  }, [invoiceId, user.id, invoice?.id]);
  const revealField = (field: string) => {
    if (!canReveal) return;
    reveal.mutate({ invoiceId, data: { field } }, { onSuccess: (result) => setRevealed((current) => ({ ...current, [result.field]: result.value })), onError: (e) => setNotice(errMsg(e, 'This field could not be revealed.')) });
  };
  const runAction = async (action: 'submit' | 'sendBack' | 'pass' | 'approve' | 'reject') => {
    if ((action === 'sendBack' || action === 'reject') && !comment.trim()) { setNotice(''); setActionError('A reason is required to send back or reject an invoice.'); return; }
    if (!(await saveEdits())) return;
    const onSuccess = () => {
      setNotice('Invoice updated.'); setActionError(''); setRevealed({}); setEdits({});
      if (action === 'sendBack' || action === 'reject') setComment('');
      // These transitions move the invoice out of the current role's scope.
      if ((user.role === 'Staff' && action === 'submit') || (user.role === 'Accountant' && ['sendBack', 'approve', 'reject'].includes(action))) {
        queryClient.removeQueries({ queryKey: getGetInvoiceQueryKey(invoiceId) });
        queryClient.removeQueries({ queryKey: getGetInvoiceActivityQueryKey(invoiceId) });
        navigate('/');
      }
      void invalidateAll();
    };
    const onError = (e: unknown) => { setNotice(''); setActionError(errMsg(e, 'That action could not be completed.')); };
    if ((action === 'sendBack' || action === 'reject') && !comment.trim()) { setNotice(''); setActionError('A reason is required to send back or reject an invoice.'); return; }
    const vars = { invoiceId, data: { comment: comment.trim() } };
    if (action === 'submit') submit.mutate({ invoiceId }, { onSuccess, onError });
    if (action === 'sendBack') sendBack.mutate(vars, { onSuccess, onError });
    if (action === 'pass') passOwner.mutate(vars, { onSuccess, onError });
    if (action === 'approve') approve.mutate({ invoiceId }, { onSuccess, onError });
    if (action === 'reject') reject.mutate(vars, { onSuccess, onError });
  };
  const saveEdits = async (): Promise<boolean> => {
    if (savePromise.current) {
      if (!(await savePromise.current)) return false;
    }
    if (!invoice) return false;
    const edits = { ...editsRef.current };
    if (!Object.keys(edits).length) return true;
    setActionError('');
    const data: Record<string, unknown> = {};
    for (const f of ['supplierTin', 'invoiceNumber', 'date', 'currency'] as const) if (f in edits) data[f] = (edits[f] ?? '').trim();
    if (edits.supplierId) data.supplierId = edits.supplierId;
    for (const f of ['subtotal', 'tax', 'total'] as const) {
      if (!(f in edits)) continue;
      const raw = (edits[f] ?? '').trim();
      if (!raw) { data[f] = null; continue; }
      const value = Number(raw);
      if (!Number.isFinite(value)) { setNotice(''); setActionError(`Enter a valid number for ${f}.`); return false; }
      data[f] = value;
    }
    let invalid = false;
    const lineItems = invoice.lineItems.flatMap((line, index) => {
      const dk = `lineItems.${index}.description`; const ak = `lineItems.${index}.amount`;
      const corrected: Record<string, unknown> = { id: line.id };
      if (dk in edits) corrected.description = (edits[dk] ?? '').trim();
      if (ak in edits) {
        const raw = (edits[ak] ?? '').trim();
        if (!raw) corrected.amount = null;
        else if (!Number.isFinite(Number(raw))) { invalid = true; return []; }
        else corrected.amount = Number(raw);
      }
      return Object.keys(corrected).length > 1 ? [corrected] : [];
    });
    if (invalid) { setNotice(''); setActionError('Enter a valid amount for each corrected line item.'); return false; }
    if (lineItems.length) data.lineItems = lineItems;
    if (!Object.keys(data).length) return true;
    setNotice('Saving corrections…');
    const pending = update.mutateAsync({ invoiceId, data: data as InvoiceUpdateInput })
      .then((saved) => {
        // Retain anything typed while this request was in flight.
        const remaining = Object.fromEntries(Object.entries(editsRef.current)
          .filter(([field, value]) => !(field in edits) || value !== edits[field]));
        editsRef.current = remaining;
        setEdits(remaining);
        setRevealed({});
        queryClient.setQueryData(getGetInvoiceQueryKey(invoiceId), saved);
        setNotice('Saved. Warnings and totals were re-checked.');
        void invalidateAll();
        return true;
      })
      .catch((e: unknown) => { setNotice(''); setActionError(errMsg(e, 'Changes could not be saved. Your edits are still in the form; retry Save corrections.')); return false; });
    savePromise.current = pending;
    const saved = await pending;
    if (savePromise.current === pending) savePromise.current = null;
    if (saved && Object.keys(editsRef.current).length) return saveEdits();
    return saved;
  };
  autoSave.current = saveEdits;
  useEffect(() => registerCorrectionGuard(() => autoSave.current()), []);
  useEffect(() => {
    if (!canEditInvoice || !Object.keys(edits).length) return;
    const timer = window.setTimeout(() => { void autoSave.current(); }, 1000);
    return () => window.clearTimeout(timer);
  }, [edits, canEditInvoice]);
  useEffect(() => {
    const warnBeforeLeaving = (event: BeforeUnloadEvent) => {
      if (!Object.keys(editsRef.current).length) return;
      event.preventDefault();
      event.returnValue = '';
    };
    window.addEventListener('beforeunload', warnBeforeLeaving);
    return () => window.removeEventListener('beforeunload', warnBeforeLeaving);
  }, []);
  if (invoiceQuery.isLoading) return <main className="page-content"><Link href="/" className="back-link"><ArrowLeft size={15} /> Back to inbox</Link><LoadingPanel /></main>;
  if (invoiceQuery.isError || !invoice) return <main className="page-content"><Link href="/" className="back-link"><ArrowLeft size={15} /> Back to inbox</Link><LoadingPanel label={invoiceQuery.isError ? errMsg(invoiceQuery.error, 'This invoice could not be found.') : 'This invoice could not be found.'} retry={() => invoiceQuery.refetch()} /></main>;
  const renderValue = (field: string, masked: string) => <span className="protected-value"><span>{revealed[field] || masked}</span>{canReveal && !revealed[field] && <button className="reveal-button" onClick={() => revealField(field)} disabled={reveal.isPending} aria-label={`Reveal ${field}`}><Eye size={13} /> Reveal</button>}{canEditField(field) && <Input className="edit-inline" placeholder="Enter corrected value" value={edits[field] ?? ''} onChange={(e) => setEdits({ ...edits, [field]: e.target.value })} aria-label={`Edit ${field}`} data-testid={`input-edit-${field}`} />}</span>;
  const canSubmit = editableStatus;
  const canDecide = !isStaff && ['In review', 'Awaiting approval'].includes(invoice.status);
  const hasActions = canSubmit || canDecide;
  const errorWarnings = invoice.warnings.filter((w) => w.severity === 'error').length;
  const ownSubmission = !!invoice.submittedBy && invoice.submittedBy === user.id;
  const approveBlock = errorWarnings > 0 ? `Approval is disabled: ${errorWarnings} error ${errorWarnings === 1 ? 'warning remains' : 'warnings remain'}. Correct the flagged fields or reject the invoice.` : ownSubmission ? 'Approval is disabled: you submitted this invoice, so someone else must approve it.' : '';
  const finalState = ['Approved', 'Rejected'].includes(invoice.status);
  return <main className="page-content review-page">
    <Link href="/" className="back-link" onClick={(event) => { event.preventDefault(); void saveEdits().then((saved) => { if (saved) navigate('/'); }); }}><ArrowLeft size={15} /> Back to inbox</Link>
    <div className="review-title"><div><div className="eyebrow">INVOICE REVIEW</div><h1>{invoice.supplier}</h1><div className="review-subtitle">{invoice.fileName}<span>·</span><StatusPill status={invoice.status} /></div></div><SecureBadge /></div>
    <div className="review-columns">
      <section className="review-main">
        <div className="review-card">
          <div className="card-head"><div><span className="section-kicker">REVIEW DETAILS</span><h2>Invoice information</h2></div><div className="review-id">REF <span>{invoice.id}</span></div></div>
          <div className="detail-grid">
            <Detail label="Supplier" value={<span className="protected-value"><span>{invoice.supplier}</span>{canEditField('supplier') && <select className="edit-select" value={edits.supplierId ?? ''} onChange={(e) => setEdits({ ...edits, supplierId: e.target.value })} aria-label="Correct supplier" data-testid="select-edit-supplier"><option value="">Keep current supplier</option>{SUPPLIERS.map((sp) => <option key={sp.id} value={sp.id}>{sp.name}</option>)}</select>}</span>} />
            <Detail label="Supplier TIN" value={renderValue('supplierTin', invoice.supplierTinMasked)} />
            <Detail label="Invoice number" value={renderValue('invoiceNumber', invoice.invoiceNumberMasked)} />
            <Detail label="Invoice date" value={canEditField('date') ? <span className="protected-value"><span>{formatDate(invoice.date)}</span><Input className="edit-inline" type="date" value={edits.date ?? invoice.date} onChange={(e) => setEdits({ ...edits, date: e.target.value })} aria-label="Edit invoice date" /></span> : <span>{formatDate(invoice.date)}</span>} />
            <Detail label="Currency" value={<span className="protected-value"><span>{invoice.currency || 'Not provided'}</span>{canEditField('currency') && <Input className="edit-inline" placeholder="e.g. MYR" value={edits.currency ?? invoice.currency} onChange={(e) => setEdits({ ...edits, currency: e.target.value })} aria-label="Edit currency" />}</span>} />
          </div>
          <div className="amount-list">
            <AmountLine label="Subtotal" value={renderValue('subtotal', invoice.subtotalMasked)} />
            <AmountLine label="Tax" value={renderValue('tax', invoice.taxMasked)} />
            <AmountLine label="Total" value={renderValue('total', invoice.totalMasked)} total />
          </div>
          <div className="line-items-head"><h3>Line items</h3><span>{invoice.lineItems.length} extracted</span></div>
          {invoice.lineItems.map((line, index) => <div className="line-item" key={line.id}>
            <div className="line-item-title"><span className="line-index">{String(index + 1).padStart(2, '0')}</span><div>{renderValue(`lineItems.${index}.description`, line.descriptionMasked)}<small>{line.confidence} confidence</small></div></div>
            <div className="line-item-amount">{renderValue(`lineItems.${index}.amount`, line.amountMasked)}</div>
          </div>)}
          {canEditInvoice && <div className="edit-actions"><span role="status" data-testid="text-save-status">{update.isPending ? 'Saving corrections…' : Object.keys(edits).length ? 'Unsaved changes—saving automatically after you stop typing.' : 'All corrections saved. Only changed fields are sent.'}</span><Button onClick={() => void saveEdits()} disabled={busy || !Object.keys(edits).length} data-testid="button-save-corrections">Save corrections</Button></div>}
        </div>
        {invoice.warnings.length > 0 && <div className="warnings-card"><div className="warnings-heading"><div className="warning-icon"><AlertTriangle size={17} /></div><div><h2>Needs a closer look</h2><p>{invoice.warnings.length} {invoice.warnings.length === 1 ? 'item needs' : 'items need'} attention. Errors block approval; invoices can still be submitted for review.</p></div></div><div className="warning-list">{invoice.warnings.map((warning) => <div className={`warning-row warning-${warning.severity}`} key={warning.code}><span className="warning-mark"><AlertTriangle size={14} /></span><div><strong>{warning.message}</strong><small>{warning.severity === 'error' ? 'Error' : 'Warning'} · {warning.field}</small></div></div>)}</div></div>}
        {invoice.comment && <div className="comment-card"><span className="section-kicker">LATEST NOTE</span><p>{invoice.comment}</p></div>}
        <div className="activity-card"><div className="card-head"><div><span className="section-kicker">AUDIT TRAIL</span><h2>Invoice activity</h2></div><Activity size={17} /></div>{activityQuery.isLoading ? <div className="mini-loading">Loading activity…</div> : <ActivityTimeline entries={activityQuery.data || []} compact />}</div>
      </section>
      <aside className="review-aside">
        <div className="workflow-card"><span className="section-kicker">APPROVAL PATH</span><h3>One careful step at a time</h3><Workflow active={roleStep(invoice.status)} /><p>Staff prepares it. An accountant or owner reviews it. Either reviewer may approve, but never their own submission. Passing to the owner is optional.</p></div>
        <div className="file-card"><div className="file-card-title"><span className="file-symbol"><FileText size={17} /></span><div><strong>Original document</strong><small>{invoice.fileName}</small></div></div>{fileUrl ? <div className="document-preview">{invoice.mimeType === 'application/pdf' ? <iframe src={fileUrl} title="Original invoice document" /> : <img src={fileUrl} alt="Original invoice" />}</div> : <div className="file-placeholder">{fileError || 'Loading secure document…'}</div>}</div>
        {hasActions && <div className="action-card"><span className="section-kicker">NEXT STEP</span><h3>{canSubmit ? 'Ready to send for review?' : 'Your review decision'}</h3><p>{canSubmit ? 'You can submit even while warnings remain; the reviewer will see them.' : 'Approve or reject, send it back with a reason, or optionally pass it to the owner.'}</p>
          {canDecide && <Textarea value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Reason (required to send back)" aria-label="Workflow comment" data-testid="input-workflow-comment" />}
          <div className="action-buttons">
            {canSubmit && <Button onClick={() => runAction('submit')} disabled={busy} data-testid="button-submit"><ArrowRight size={15} /> Submit for review</Button>}
            {canDecide && <>
              <Button variant="outline" onClick={() => runAction('sendBack')} disabled={busy || !comment.trim()} data-testid="button-send-back"><RotateCw size={15} /> Send back</Button>
              {invoice.status === 'In review' && <Button variant="outline" onClick={() => runAction('pass')} disabled={busy} data-testid="button-pass-owner"><ArrowRight size={15} /> Pass to owner</Button>}
              <Button variant="outline" onClick={() => runAction('reject')} disabled={busy} data-testid="button-reject"><XCircle size={15} /> Reject</Button>
              <Button onClick={() => runAction('approve')} disabled={busy || !!approveBlock} data-testid="button-approve"><CheckCircle2 size={15} /> Approve</Button>
            </>}
          </div>
          {canDecide && approveBlock && <div className="approve-block" role="note">{approveBlock}</div>}
          {actionError && <div className="inline-error action-error" role="alert"><AlertTriangle size={14} />{actionError}</div>}
          {notice && <div className="action-notice" role="status">{notice}</div>}
        </div>}
        {!hasActions && <div className="action-card"><span className="section-kicker">STATUS</span><h3>{finalState ? `This invoice is ${invoice.status.toLowerCase()}` : 'No action for your role'}</h3><p>{finalState ? 'Final decisions cannot be edited.' : 'This invoice is with a reviewer. You can still read it and follow its activity.'}</p>{actionError && <div className="inline-error action-error" role="alert"><AlertTriangle size={14} />{actionError}</div>}</div>}
      </aside>
    </div>
    {notice && !hasActions && <div className="toast-note" role="status">{notice}</div>}
  </main>;
}

function Detail({ label, value }: { label: string; value: ReactNode }) { return <div className="detail-field"><span>{label}</span><strong>{value}</strong></div>; }
function AmountLine({ label, value, total }: { label: string; value: ReactNode; total?: boolean }) { return <div className={`amount-line ${total ? 'amount-total' : ''}`}><span>{label}</span><strong>{value}</strong></div>; }

function ApprovalsPage({ user }: { user: HubUser }) {
  const query = useListInvoices({ request: header(user.id) });
  const rows = (query.data || []).filter((item) => item.status === 'In review' || item.status === 'Awaiting approval');
  const description = user.role === 'Owner' ? 'Invoices in review or awaiting approval. You can approve, reject or send back with a reason.' : user.role === 'Accountant' ? 'Invoices in review or awaiting approval. Approve, reject, send back with a reason, or pass to the owner.' : 'Your submitted invoices are currently with the accountant.';
  return <main className="page-content"><PageHeader eyebrow="WORKFLOW" title="Approvals"><span className="pending-count">{rows.length} waiting</span></PageHeader><div className="queue-intro"><div className="queue-emblem"><BadgeCheck size={21} /></div><div><h2>{user.role === 'Owner' ? 'Your final review' : user.role === 'Accountant' ? 'Accountant review queue' : 'Review progress'}</h2><p>{description}</p></div><Workflow active={user.role === 'Staff' ? 0 : user.role === 'Accountant' ? 1 : 2} /></div>{query.isLoading ? <LoadingPanel /> : query.isError ? <LoadingPanel label="Approvals couldn't be loaded." retry={() => query.refetch()} /> : rows.length ? <div className="approval-list">{rows.map((row) => <ApprovalCard row={row} key={row.id} />)}</div> : <EmptyState title={user.role === 'Staff' ? 'Nothing in review yet' : 'Your queue is clear'} text={user.role === 'Staff' ? 'Once you submit an invoice, its progress will be visible here.' : 'There are no invoices waiting at this step. New submissions will appear here.'} />}</main>;
}

function ApprovalCard({ row }: { row: InvoiceListItem }) {
  return <Link href={`/review/${row.id}`} className="approval-card" data-testid={`card-approval-${row.id}`}><div className="approval-file-icon"><FileText size={19} /></div><div className="approval-info"><div className="approval-name">{row.supplier}<StatusPill status={row.status} /></div><div className="approval-meta">{row.fileName}<span>·</span>{formatDate(row.date)}<span>·</span><span className="masked-data">{row.currency} {row.totalMasked}</span></div></div><div className="approval-warning">{row.warnings ? <><AlertTriangle size={14} />{row.warnings} {row.warnings === 1 ? 'warning' : 'warnings'}</> : <><ShieldCheck size={14} />No warnings</>}</div><ArrowRight size={17} className="approval-arrow" /></Link>;
}

function RecordsPage({ user }: { user: HubUser }) {
  const query = useGetApprovedRecords({ request: header(user.id) });
  const exportCsv = useExportRecords('csv', { query: { queryKey: ['exportRecords', 'csv', user.id], enabled: false }, request: header(user.id) });
  const exportJson = useExportRecords('json', { query: { queryKey: ['exportRecords', 'json', user.id], enabled: false }, request: header(user.id) });
  const [exportError, setExportError] = useState('');
  const canExport = user.role === 'Owner';
  const onExport = (format: 'csv' | 'json') => {
    setExportError('');
    const queryHook = format === 'csv' ? exportCsv : exportJson;
    void queryHook.refetch().then(({ data, error }) => {
      if (error || typeof data !== 'string') { setExportError(errMsg(error, 'Export could not be created. Please try again.')); return; }
      const blob = new Blob([data], { type: format === 'csv' ? 'text/csv;charset=utf-8' : 'application/json;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement('a'); anchor.href = url; anchor.download = `billguard-approved-records.${format}`; anchor.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    });
  };
  return <main className="page-content"><PageHeader eyebrow="APPROVED ARCHIVE" title="Records">{canExport && <div className="export-group"><Button variant="outline" onClick={() => onExport('csv')} disabled={exportCsv.isFetching || exportJson.isFetching}><ArrowDownToLine size={15} /> Export CSV</Button><Button onClick={() => onExport('json')} disabled={exportCsv.isFetching || exportJson.isFetching}><ArrowDownToLine size={15} /> Export JSON</Button></div>}</PageHeader><div className="records-intro"><div className="records-mark"><FolderArchive size={20} /></div><div><strong>Approved and ready to keep</strong><p>These records are finalised in this workspace and remain securely stored.</p></div><SecureBadge /></div>{exportError && <div className="inline-error"><AlertTriangle size={16} />{exportError}</div>}{query.isLoading ? <LoadingPanel /> : query.isError ? <LoadingPanel label="Approved records could not be loaded." retry={() => query.refetch()} /> : query.data?.length ? <div className="data-section records-table-section"><div className="section-head"><div><div className="section-kicker">SECURE ARCHIVE</div><h2>Approved records <span className="count-chip">{query.data.length}</span></h2></div><SecureBadge /></div><InvoiceTable rows={query.data} /></div> : <EmptyState title="Your archive begins with approval" text="Once an owner approves an invoice, the protected record will be available here." />}{!canExport && <div className="permission-note"><LockKeyhole size={15} />Exports are available to the workspace owner.</div>}</main>;
}

function SettingsPage({ user }: { user: HubUser }) {
  const queryClient = useQueryClient();
  const settings = useGetOcrSettings({ request: header(user.id) });
  const update = useUpdateOcrSettings({ request: header(user.id) });
  const [notice, setNotice] = useState('');
  const setMode = (mode: 'live' | 'cached') => {
    setNotice('');
    update.mutate({ data: { mode } }, {
      onSuccess: async () => {
        setNotice(`Invoice reading mode set to ${mode}.`);
        await Promise.all([
          queryClient.invalidateQueries({ queryKey: getGetOcrSettingsQueryKey() }),
          queryClient.invalidateQueries({ queryKey: getGetActivityQueryKey() }),
        ]);
      },
      onError: (e) => setNotice(errMsg(e, 'The OCR setting could not be changed.')),
    });
  };
  if (user.role !== 'Owner') {
    return <main className="page-content"><PageHeader eyebrow="WORKSPACE" title="Settings" /><div className="permission-note"><LockKeyhole size={15} />Only the owner can change OCR settings.</div></main>;
  }
  return <main className="page-content">
    <PageHeader eyebrow="WORKSPACE CONFIGURATION" title="Settings" />
    <section className="settings-panel">
      <div className="settings-panel-head"><span className="settings-icon"><Settings size={19} /></span><div><span className="section-kicker">INVOICE READING</span><h2>OCR mode</h2><p>Cached mode uses saved synthetic results. Live mode reads PDFs and images through your Runpod vision model. No user sign-in is required.</p></div></div>
      {settings.isLoading ? <LoadingPanel label="Loading OCR settings…" /> : settings.isError ? <LoadingPanel label="OCR settings could not be loaded." retry={() => settings.refetch()} /> : <>
        <div className="ocr-readiness"><span className={`readiness-dot ${settings.data?.liveConfigured ? 'ready' : ''}`} /><span>{settings.data?.liveConfigured ? 'Runpod is configured. Public Live AI uploads are available without sign-in.' : 'Runpod is not connected yet. Configure its server-side endpoint, model and API key to enable Live AI.'}</span></div>
        <div className="ocr-mode-options" role="group" aria-label="Invoice OCR mode">
          <button type="button" className={`ocr-mode-option ${settings.data?.mode === 'cached' ? 'selected' : ''}`} aria-pressed={settings.data?.mode === 'cached'} disabled={update.isPending || !isDemo} onClick={() => setMode('cached')}>
            <strong>Cached · Synthetic samples</strong><span>Saved results for the exact downloaded sample files. Loaded invoices stay editable and corrections are saved.</span>
          </button>
          <button type="button" className={`ocr-mode-option ${settings.data?.mode === 'live' ? 'selected' : ''}`} aria-pressed={settings.data?.mode === 'live'} disabled={update.isPending || !settings.data?.liveConfigured} onClick={() => setMode('live')} data-testid="button-enable-live-ai">
            <strong>Live AI · Runpod</strong><span>Test PDFs (up to 3 pages), PNG, JPEG and WebP images, up to 15 MB. Public usage spends your Runpod credits. Failed reads never use cached results. Default per-server limits: 30 attempted reads/day, 5/minute and 2 concurrent reads.</span>
          </button>
        </div>
        {!settings.data?.liveConfigured && <p className="settings-help">A Runpod OpenAI-compatible endpoint with a vision-capable model is required. Credentials stay on the server.</p>}
        {notice && <div className="settings-notice" role="status">{notice}</div>}
      </>}
    </section>
  </main>;
}

function ActivityPage({ user }: { user: HubUser }) {
  const query = useGetActivity({ request: header(user.id) });
  return <main className="page-content"><PageHeader eyebrow="WORKSPACE HISTORY" title="Activity"><span className="audit-tag"><ShieldCheck size={14} /> Audit trail</span></PageHeader><div className="activity-intro"><div className="activity-intro-icon"><Activity size={19} /></div><div><strong>A clear history, by design</strong><p>Reviews, decisions and access to protected fields are recorded for accountability.</p></div></div><section className="timeline-panel"><div className="section-head"><div><div className="section-kicker">RECENT EVENTS</div><h2>Workspace timeline</h2></div></div>{query.isLoading ? <LoadingPanel /> : query.isError ? <LoadingPanel label="Activity couldn't be loaded." retry={() => query.refetch()} /> : query.data?.length ? <ActivityTimeline entries={query.data} /> : <EmptyState title="No activity to show yet" text="When someone uploads, reviews or approves an invoice, the event will be recorded here." />}</section></main>;
}

function ActivityTimeline({ entries, compact = false }: { entries: ActivityEntry[]; compact?: boolean }) {
  if (!entries.length) return <div className="empty-timeline">No activity has been recorded for this invoice yet.</div>;
  return <div className={`timeline ${compact ? 'timeline-compact' : ''}`}>{entries.map((entry) => <div className="timeline-item" key={entry.id}><span className="timeline-dot"><Activity size={12} /></span><div className="timeline-copy"><strong>{entry.action}</strong><p><span>{entry.actor}</span>{entry.field && <> · <span className="field-chip">{entry.field}</span></>}</p></div>{entry.invoiceId && !compact && <Link href={`/review/${entry.invoiceId}`} className="timeline-ref">Open invoice <ArrowRight size={12} /></Link>}<time>{formatRelative(entry.createdAt)}</time></div>)}</div>;
}

function formatDate(date: string) {
  const parsed = new Date(date);
  if (Number.isNaN(parsed.getTime())) return date;
  return new Intl.DateTimeFormat('en-MY', { day: 'numeric', month: 'short', year: 'numeric' }).format(parsed);
}

function formatRelative(date: string) {
  const time = new Date(date).getTime();
  if (!Number.isFinite(time)) return date;
  const delta = Date.now() - time;
  if (delta < 60_000) return 'Just now';
  if (delta < 3_600_000) return `${Math.floor(delta / 60_000)}m ago`;
  if (delta < 86_400_000) return `${Math.floor(delta / 3_600_000)}h ago`;
  return formatDate(date);
}
