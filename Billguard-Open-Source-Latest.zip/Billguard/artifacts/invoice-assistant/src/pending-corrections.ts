let beforeLeaving: (() => Promise<boolean>) | undefined;

export function registerCorrectionGuard(guard: () => Promise<boolean>) {
  beforeLeaving = guard;
  return () => { if (beforeLeaving === guard) beforeLeaving = undefined; };
}

export async function flushPendingCorrections(): Promise<boolean> {
  return beforeLeaving ? beforeLeaving() : true;
}
