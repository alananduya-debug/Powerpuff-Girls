import { setRequestUrlMapper } from '@workspace/api-client-react';

export const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
// Keep the public root on the synthetic demo; account routes opt into Clerk.
const routePath = window.location.pathname;
const accountRoutes = ['/sign-in', '/sign-up', '/workspace'].map((route) => `${basePath}${route}` || route);
export const isDemo = !accountRoutes.some((route) => routePath === route || routePath.startsWith(`${route}/`));
export const apiPath = (url: string) => isDemo ? url.replace(/^\/api(?=\/|$)/, '/api/demo-workspace') : url;
setRequestUrlMapper(apiPath);
