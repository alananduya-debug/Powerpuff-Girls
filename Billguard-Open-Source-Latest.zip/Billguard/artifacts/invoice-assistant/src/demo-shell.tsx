import type { ReactNode } from 'react';
import { Router } from 'wouter';
import { basePath } from './workspace';

export function DemoShell({ children }: { children: ReactNode }) {
  // Keep previously shared /demo links usable while opening the demo at /.
  const legacyDemo = window.location.pathname === `${basePath}/demo` ||
    window.location.pathname.startsWith(`${basePath}/demo/`);
  return <Router base={`${basePath}${legacyDemo ? '/demo' : ''}`}>{children}</Router>;
}
