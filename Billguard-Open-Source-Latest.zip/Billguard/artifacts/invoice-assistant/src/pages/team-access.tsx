import { useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import {
  AlertTriangle, ArrowDownRight, ArrowUpRight, Check, Clock3, LockKeyhole,
  RotateCw, Search, ShieldCheck, UserRound, UserRoundMinus,
} from 'lucide-react';
import {
  getGetTeamAccessAuditQueryKey, getSearchTeamMembersQueryKey,
  useGetTeamAccessAudit, useSearchTeamMembers, useUpdateTeamMemberRole,
} from '@workspace/api-client-react';
import type { TeamMember } from '@workspace/api-client-react';
import { Button } from '@/components/ui/button';

type TeamRole = 'Staff' | 'Accountant' | 'Owner';
const roles: TeamRole[] = ['Staff', 'Accountant', 'Owner'];

function errorMessage(error: unknown) {
  const data = (error as { data?: { error?: string } } | null)?.data;
  return data?.error || (error instanceof Error ? error.message : 'The change could not be saved. Try again.');
}

function SkeletonRows() {
  return <div className="team-skeleton" aria-label="Loading team members" data-testid="loading-team-members">
    {[0, 1, 2].map((row) => <div className="team-skeleton-row" key={row}><i /><span /><b /></div>)}
  </div>;
}

function roleDescription(role: TeamRole | null) {
  if (!role) return 'No workspace access';
  if (role === 'Owner') return 'Full workspace control';
  if (role === 'Accountant') return 'Review and approve invoices';
  return 'Prepare and submit invoices';
}

export function TeamAccessPage({ currentUserId }: { currentUserId: string }) {
  const [search, setSearch] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const queryClient = useQueryClient();
  const query = search.trim();
  const memberQuery = useSearchTeamMembers(
    { query },
    { query: { enabled: query.length >= 2, queryKey: getSearchTeamMembersQueryKey({ query }) } },
  );
  const auditQuery = useGetTeamAccessAudit({
    query: { queryKey: getGetTeamAccessAuditQueryKey() },
  });
  const updateRole = useUpdateTeamMemberRole();

  const saveRole = (member: TeamMember, role: TeamRole | null) => {
    setError('');
    setMessage('');
    updateRole.mutate({ userId: member.id, data: { role } }, {
      onSuccess: async () => {
        setMessage(role ? `${member.name}'s access is now ${role}.` : `${member.name}'s workspace access was revoked.`);
        await Promise.all([
          queryClient.invalidateQueries({ queryKey: getSearchTeamMembersQueryKey({ query }) }),
          queryClient.invalidateQueries({ queryKey: getGetTeamAccessAuditQueryKey() }),
        ]);
      },
      onError: (cause) => {
        setError(errorMessage(cause));
        void Promise.all([
          queryClient.invalidateQueries({ queryKey: getSearchTeamMembersQueryKey({ query }) }),
          queryClient.invalidateQueries({ queryKey: getGetTeamAccessAuditQueryKey() }),
        ]);
      },
    });
  };

  const revoke = (member: TeamMember) => {
    if (window.confirm(`Revoke workspace access for ${member.name}?`)) saveRole(member, null);
  };

  const members = memberQuery.data || [];
  const hasSearch = query.length >= 2;

  return <main className="page-content team-access-page">
    <div className="team-access-hero">
      <div className="team-access-title">
        <div className="eyebrow">WORKSPACE GOVERNANCE · OWNER ONLY</div>
        <h1>Team access</h1>
        <p>Manage verified members already known to Billguard. Every role change is recorded.</p>
      </div>
      <div className="team-owner-mark"><ShieldCheck size={19} /><span>Owner controls</span></div>
    </div>

    <div className="team-policy-band" data-testid="text-team-access-policy">
      <LockKeyhole size={17} />
      <p><strong>Verified accounts only.</strong> Search members by name or email, then assign the access they need. Invitations and account creation are not available here.</p>
      <span className="team-policy-count">3 roles</span>
    </div>

    {(message || error) && <div className={error ? 'team-feedback team-feedback-error' : 'team-feedback team-feedback-success'} role={error ? 'alert' : 'status'} data-testid={error ? 'status-team-access-error' : 'status-team-access-success'}>
      {error ? <AlertTriangle size={16} /> : <Check size={16} />}
      <span>{error || message}</span>
      {error && <Button variant="outline" size="sm" onClick={() => { setError(''); setMessage(''); }} data-testid="button-dismiss-team-error">Dismiss</Button>}
    </div>}

    <div className="team-access-layout">
      <section className="team-panel" aria-labelledby="members-title">
        <div className="team-panel-heading">
          <div><div className="section-kicker">MEMBER DIRECTORY</div><h2 id="members-title">Manage access</h2></div>
          <span className="team-verified-label"><span /> Verified members</span>
        </div>
        <p className="team-panel-intro">Roles determine which invoice actions are available in the workspace.</p>

        <label className="team-search" htmlFor="team-member-search">
          <Search size={17} />
          <input id="team-member-search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search by name or email" autoComplete="off" data-testid="input-search-team-members" />
          {search && <button type="button" onClick={() => setSearch('')} aria-label="Clear member search" data-testid="button-clear-team-search">Clear</button>}
        </label>
        {!hasSearch ? <div className="team-prompt" data-testid="text-team-search-prompt"><div className="team-prompt-icon"><UserRound size={19} /></div><strong>Find a verified member</strong><span>Enter at least two characters to search.</span></div>
          : memberQuery.isLoading ? <SkeletonRows />
          : memberQuery.isError ? <div className="team-query-error" role="alert" data-testid="status-team-search-error"><AlertTriangle size={17} /><span>Member search is unavailable right now.</span><Button variant="outline" size="sm" onClick={() => void memberQuery.refetch()} data-testid="button-retry-team-search"><RotateCw size={13} /> Retry</Button></div>
          : members.length === 0 ? <div className="team-empty" data-testid="empty-team-members"><div className="team-empty-icon"><Search size={18} /></div><strong>No verified members found</strong><span>Try a different name or email address.</span></div>
          : <div className="team-member-list" data-testid="list-team-members">
            {members.map((member) => {
              const isCurrentUser = member.id === currentUserId;
              return <article className={`team-member-row ${isCurrentUser ? 'team-member-self' : ''}`} key={member.id} data-testid={`row-team-member-${member.id}`}>
                <span className="team-avatar" data-testid={`avatar-team-member-${member.id}`}>{member.name.split(/\s+/).map((part) => part[0]).join('').slice(0, 2).toUpperCase() || 'M'}</span>
                <div className="team-member-identity">
                  <div className="team-member-name" data-testid={`text-team-member-name-${member.id}`}>{member.name}{isCurrentUser && <span className="team-you-chip" data-testid="badge-current-team-member">You</span>}</div>
                  <div className="team-member-email" data-testid={`text-team-member-email-${member.id}`}>{member.email}</div>
                  <div className="team-member-role-caption">{roleDescription(member.role)}</div>
                </div>
                <div className="team-member-controls">
                  <label className="team-role-select-label" htmlFor={`team-role-${member.id}`}>Workspace role</label>
                  <select id={`team-role-${member.id}`} value={member.role || ''} disabled={isCurrentUser || updateRole.isPending} onChange={(event) => saveRole(member, (event.target.value || null) as TeamRole | null)} aria-label={`Set role for ${member.name}`} data-testid={`select-team-role-${member.id}`}>
                    <option value="">No access</option>
                    {roles.map((role) => <option value={role} key={role}>{role}</option>)}
                  </select>
                  <button className="team-revoke-button" type="button" onClick={() => revoke(member)} disabled={isCurrentUser || !member.role || updateRole.isPending} data-testid={`button-revoke-team-member-${member.id}`}>
                    <UserRoundMinus size={14} /><span>Revoke</span>
                  </button>
                </div>
                {isCurrentUser && <div className="team-self-note" data-testid="text-self-access-protected"><LockKeyhole size={12} /> Your access is protected</div>}
              </article>;
            })}
          </div>}

        {updateRole.isPending && <div className="team-saving" role="status" data-testid="status-saving-team-access"><span className="team-saving-dot" /> Saving access change…</div>}
        <div className="team-role-legend" data-testid="list-team-role-descriptions">
          {roles.map((role, index) => <div className="team-role-legend-item" key={role} data-testid={`text-role-description-${role.toLowerCase()}`}>
            <span className={`team-role-index role-index-${index + 1}`}>0{index + 1}</span>
            <div><strong>{role}</strong><span>{roleDescription(role)}</span></div>
          </div>)}
        </div>
      </section>

      <aside className="team-audit-panel" aria-labelledby="audit-title">
        <div className="team-panel-heading">
          <div><div className="section-kicker">ACCOUNTABILITY</div><h2 id="audit-title">Recent access history</h2></div>
          <span className="team-audit-icon"><Clock3 size={16} /></span>
        </div>
        <p className="team-panel-intro">A record of role grants and revocations in this workspace.</p>
        {auditQuery.isLoading ? <div className="audit-skeleton" data-testid="loading-team-audit">{[0, 1, 2].map((item) => <div key={item}><i /><span /></div>)}</div>
          : auditQuery.isError ? <div className="team-audit-error" role="alert" data-testid="status-team-audit-error"><AlertTriangle size={16} /><span>Access history could not be loaded.</span><Button variant="outline" size="sm" onClick={() => void auditQuery.refetch()} data-testid="button-retry-team-audit">Try again</Button></div>
          : auditQuery.data?.length ? <div className="team-audit-list" data-testid="list-team-access-audit">
            {auditQuery.data.map((entry) => {
              const granted = !!entry.toRole;
              const eventLabel = granted ? 'Role updated' : 'Access revoked';
              const target = entry.targetEmail || 'Verified member';
              return <article className={`team-audit-event audit-${entry.outcome}`} key={entry.id} data-testid={`row-team-audit-${entry.id}`}>
                <span className={`team-audit-event-icon ${granted ? 'audit-grant-icon' : 'audit-revoke-icon'}`}>{granted ? <ArrowUpRight size={15} /> : <ArrowDownRight size={15} />}</span>
                <div className="team-audit-event-copy">
                  <strong data-testid={`text-team-audit-title-${entry.id}`}>{eventLabel}</strong>
                  <span data-testid={`text-team-audit-target-${entry.id}`}>{target}</span>
                  <p data-testid={`text-team-audit-roles-${entry.id}`}><b>{entry.fromRole || 'No access'}</b><span aria-hidden="true"> → </span><b>{entry.toRole || 'No access'}</b></p>
                  <small data-testid={`text-team-audit-actor-time-${entry.id}`}>By {entry.actorName} · {new Date(entry.updatedAt || entry.createdAt).toLocaleString()}</small>
                  {entry.outcome !== 'success' && <em data-testid={`status-team-audit-outcome-${entry.id}`}>{entry.outcome === 'pending' ? 'Pending' : 'Not completed'}</em>}
                </div>
              </article>;
            })}
          </div> : <div className="team-audit-empty" data-testid="empty-team-access-audit"><div className="team-empty-icon"><Clock3 size={18} /></div><strong>No access changes yet</strong><span>Role changes will appear here with who made them and when.</span></div>}
        <div className="audit-integrity-note" data-testid="text-audit-integrity-note"><ShieldCheck size={15} /><span>Changes are checked and recorded by Billguard before they take effect.</span></div>
      </aside>
    </div>
  </main>;
}
