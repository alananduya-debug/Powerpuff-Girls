import { useEffect, type ReactNode } from 'react';
import { ClerkProvider, SignIn, SignUp, useAuth, useClerk } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { Router, Route, Switch, Redirect, useLocation } from 'wouter';
import { useQueryClient } from '@tanstack/react-query';
import { basePath, isDemo } from './workspace';

const clerkPubKey = publishableKeyFromHost(window.location.hostname, import.meta.env.VITE_CLERK_PUBLISHABLE_KEY);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;

function Landing() {
  return <main className="page-content" style={{ maxWidth: 760, margin: '12vh auto' }}>
    <img src={`${basePath}/logo.svg`} alt="Billguard" width={180} height={44} />
    <h1 style={{ marginTop: 32, marginBottom: 16, fontSize: 32, lineHeight: 1.25, fontWeight: 700 }}>Invoice review with clear responsibilities</h1>
    <p>Upload, check and approve invoices in a signed-in workspace. Your administrator assigns Staff, Accountant or Owner access.</p>
    <div className="heading-actions" style={{ marginTop: 24 }}>
      <a className="button-primary" href={`${basePath}/sign-in`}>Sign in</a>
      <a className="button-primary" href={`${basePath}/sign-up`}>Create account</a>
      <a href={`${basePath}/demo/`}>Explore synthetic demo</a>
    </div>
    <p style={{ marginTop: 24 }}>Demo roles and synthetic records are separate from authenticated accounts. New accounts need an assigned role before accessing invoices.</p>
  </main>;
}

function SessionRoutes({ children }: { children: ReactNode }) {
  const { isLoaded, isSignedIn, userId, sessionId } = useAuth();
  const cache = useQueryClient();
  const [location] = useLocation();
  useEffect(() => {
    void cache.cancelQueries();
    cache.clear();
  }, [cache, userId, sessionId]);
  if (!isLoaded) return <main className="page-content">Loading sign-in…</main>;
  return <Switch>
    <Route path="/sign-in/*?"><SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} forceRedirectUrl={`${basePath}/workspace`} /></Route>
    <Route path="/sign-up/*?"><SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} forceRedirectUrl={`${basePath}/workspace`} /></Route>
    <Route path="/">{isSignedIn ? <Redirect to="/workspace" /> : <Landing />}</Route>
    <Route>{isSignedIn
      ? <Router base="/workspace" key={`${userId}:${sessionId}`}>{location.startsWith('/workspace') ? children : <Redirect to="/" />}</Router>
      : <Redirect to="/" />}</Route>
  </Switch>;
}

export function AccountControls() {
  const { signOut } = useClerk();
  const cache = useQueryClient();
  return <button className="button-primary" onClick={() => {
    void cache.cancelQueries(); cache.clear();
    void signOut({ redirectUrl: basePath || '/' });
  }}>Sign out</button>;
}

export function AuthShell({ children }: { children: ReactNode }) {
  if (isDemo) return <Router base={`${basePath}/demo`}>{children}</Router>;
  return <ClerkProvider publishableKey={clerkPubKey} proxyUrl={clerkProxyUrl}
    appearance={{
      theme: shadcn, cssLayerName: 'clerk',
      options: { logoImageUrl: `${window.location.origin}${basePath}/logo.svg`, logoLinkUrl: basePath || '/' },
      variables: { colorPrimary: '#355bd9', colorForeground: '#182333', colorMutedForeground: '#526176', colorBackground: '#ffffff', colorInput: '#ffffff', colorInputForeground: '#182333', colorDanger: '#b42318', colorNeutral: '#526176', fontFamily: 'DM Sans, sans-serif' },
      elements: { cardBox: { background: '#ffffff', width: 440, maxWidth: '100%' }, headerTitle: { color: '#182333' }, headerSubtitle: { color: '#526176' } },
    }}
    localization={{ signIn: { start: { title: 'Sign in to Billguard', subtitle: 'Access your invoice workspace' } }, signUp: { start: { title: 'Create your Billguard account', subtitle: 'Your administrator will assign workspace access' } } }}>
    <Router base={basePath}><SessionRoutes>{children}</SessionRoutes></Router>
  </ClerkProvider>;
}
