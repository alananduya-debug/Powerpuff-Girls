import { useCallback, useEffect, useRef, useState } from 'react';
import { Play, Pause, Repeat, Volume2, VolumeX, ChevronDown, ChevronUp } from 'lucide-react';
import VideoTemplate, { SCENE_DURATIONS } from './VideoTemplate';
import { useSceneControls } from './useSceneControls';

const SCENE_DETAILS: Record<string, { title: string; filePath: string }> = {
  hook: { title: 'Opening', filePath: 'src/components/video/scenes/Scenes.tsx' },
  upload: { title: 'Staff inbox', filePath: 'src/components/video/scenes/Scenes.tsx' },
  issues: { title: 'Accountant review', filePath: 'src/components/video/scenes/Scenes.tsx' },
  fix: { title: 'Owner inbox and records', filePath: 'src/components/video/scenes/Scenes.tsx' },
  roles: { title: 'Review safeguards', filePath: 'src/components/video/scenes/Scenes.tsx' },
  outro: { title: 'Billguard close', filePath: 'src/components/video/scenes/Scenes.tsx' },
};
function announce(index: number, keys: string[]) {
  const d = SCENE_DETAILS[keys[index]]; if (!d) return;
  window.parent.postMessage({ type: 'REPLIT_VIDEO_SCENE_SELECTED', payload: { sceneIndex: index, sceneCount: keys.length, sceneTitle: d.title, filePath: d.filePath, lineNumber: 1 } }, '*');
}
const fmt = (ms: number) => { const s = Math.max(0, Math.floor(ms / 1000)); return `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, '0')}`; };

function Status(p: { sceneKeys: string[]; activeIndex: number; activeDuration: number; activeStartTime: number; totalDuration: number; tick: number; paused: boolean; onJumpTo: (i: number) => void }) {
  const [elapsed, setElapsed] = useState(0);
  const base = useRef(0);
  useEffect(() => { setElapsed(0); base.current = 0; }, [p.tick]);
  useEffect(() => {
    if (p.paused) return;
    const st = performance.now();
    const id = window.setInterval(() => setElapsed(base.current + performance.now() - st), 60);
    return () => { window.clearInterval(id); base.current += performance.now() - st; };
  }, [p.tick, p.paused]);
  const prog = p.activeDuration > 0 ? Math.min(1, elapsed / p.activeDuration) : 0;
  const total = Math.min(p.totalDuration, p.activeStartTime + Math.min(elapsed, p.activeDuration));
  return (<>
    <div className="flex-1 flex items-center gap-1.5">
      {p.sceneKeys.map((k, i) => (
        <button key={k} onClick={() => p.onJumpTo(i)} aria-label={`Jump to scene ${i + 1}`} className="flex-1 h-3 bg-white/20 rounded-full overflow-hidden cursor-pointer relative">
          <div className="absolute inset-y-0 left-0 bg-white/90 rounded-full" style={{ width: `${i === p.activeIndex ? prog * 100 : 0}%` }} />
        </button>))}
    </div>
    <div className="text-xl text-white/60 font-mono tabular-nums shrink-0">{p.activeIndex + 1}/{p.sceneKeys.length}</div>
    <div className="min-w-[11ch] text-right text-xl text-white/80 font-mono tabular-nums shrink-0" role="timer">{fmt(total)} / {fmt(p.totalDuration)}</div>
  </>);
}

export default function VideoWithControls() {
  const isIframed = typeof window !== 'undefined' && window.self !== window.top;
  const c = useSceneControls(SCENE_DURATIONS);
  const [muted, setMuted] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const [hover, setHover] = useState(false);
  const [pin, setPin] = useState(false);
  const jump = useCallback((i: number) => { c.jumpTo(i); announce(i, c.sceneKeys); }, [c.jumpTo, c.sceneKeys]);
  useEffect(() => {
    if (!c.paused) return;
    const f = document.getAnimations().filter((a) => a.playState === 'running');
    f.forEach((a) => a.pause());
    return () => f.forEach((a) => a.play());
  }, [c.paused]);
  if (!isIframed) return <VideoTemplate />;
  const visible = !collapsed || hover || pin;
  const btn = 'w-14 h-14 flex items-center justify-center text-white/60 hover:text-white hover:bg-white/10 rounded-lg shrink-0';
  return (
    <div className="relative w-full h-screen">
      <VideoTemplate key={c.mountKey} durations={c.durations} loop paused={c.paused} muted={muted} onSceneChange={c.onSceneChange} />
      <div className="absolute bottom-0 left-0 right-0 z-50 flex flex-col justify-end" style={{ height: '25%' }}
        onPointerEnter={(e) => e.pointerType === 'mouse' && setHover(true)} onPointerLeave={(e) => e.pointerType === 'mouse' && setHover(false)}
        onPointerDown={(e) => { if (e.pointerType !== 'mouse' && collapsed) setPin(true); }}>
        <div className="flex-1 w-full" aria-hidden="true" />
        <div className={`flex items-center gap-3 bg-black/50 backdrop-blur-sm px-5 py-4 transition-all duration-200 ${visible ? 'translate-y-0 opacity-100 pointer-events-auto' : 'translate-y-full opacity-0 pointer-events-none'}`}>
          <button className={btn} onClick={c.togglePause} aria-label={c.paused ? 'Play' : 'Pause'}>{c.paused ? <Play className="w-8 h-8" /> : <Pause className="w-8 h-8" />}</button>
          <button className={`${btn} ${c.locked ? 'text-white bg-white/15' : ''}`} onClick={c.toggleLock} aria-label="Loop current scene" aria-pressed={c.locked}><Repeat className="w-8 h-8" /></button>
          <button className={btn} onClick={() => setMuted((m) => !m)} aria-label={muted ? 'Unmute' : 'Mute'}>{muted ? <VolumeX className="w-8 h-8" /> : <Volume2 className="w-8 h-8" />}</button>
          <div className="w-px self-stretch bg-white/15" aria-hidden="true" />
          <Status {...c} onJumpTo={jump} />
          <button className={btn} onClick={() => { setCollapsed((x) => !x); setHover(false); setPin(false); }} aria-label="Toggle controls">{collapsed ? <ChevronUp className="w-10 h-10" /> : <ChevronDown className="w-10 h-10" />}</button>
        </div>
      </div>
    </div>
  );
}
