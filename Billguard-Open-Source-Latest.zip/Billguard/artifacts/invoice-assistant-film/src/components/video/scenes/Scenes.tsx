import type { CSSProperties, ReactNode } from 'react';
import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

const G = '#294f45';
const GD = '#10231d';
const GOLD = '#d6b779';
const CREAM = '#f6f4ed';
const PAPER = '#fffefa';
const TEXT = '#334b44';
const MUTED = '#849087';
const RUST = '#b65f4c';
const BORDER = '#e7e3d9';
const v = (n: number) => `${n}vmin`;
const mono = "'IBM Plex Mono', monospace";
const ease = [0.22, 1, 0.36, 1] as const;

function Stage({ children, bg = CREAM }: { children: ReactNode; bg?: string }) {
  return (
    <motion.div className="absolute inset-0 overflow-hidden" style={{ background: bg, fontFamily: 'Manrope, sans-serif' }}
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.32 }}>
      {children}
    </motion.div>
  );
}

function Reveal({ children, delay = 0, style, from = 22 }: { children: ReactNode; delay?: number; style?: CSSProperties; from?: number }) {
  return <motion.div style={{ position: 'absolute', ...style }} initial={{ opacity: 0, y: from }} animate={{ opacity: 1, y: 0 }} transition={{ delay, duration: 0.55, ease }}>{children}</motion.div>;
}

function Label({ children, color = MUTED }: { children: ReactNode; color?: string }) {
  return <div style={{ fontFamily: mono, fontSize: v(1.45), letterSpacing: '.13em', color, fontWeight: 600 }}>{children}</div>;
}

function Title({ children, color = G, size = 6 }: { children: ReactNode; color?: string; size?: number }) {
  return <div style={{ fontSize: v(size), lineHeight: 1.03, letterSpacing: '-.045em', fontWeight: 800, color }}>{children}</div>;
}

function Chip({ children, tone = 'green' }: { children: ReactNode; tone?: 'green' | 'amber' | 'red' | 'gray' | 'blue' }) {
  const tones = {
    green: ['#e8f0e6', '#528061'],
    amber: ['#f5efdf', '#9a783e'],
    red: ['#faece6', RUST],
    gray: ['#f0eee7', '#777b6c'],
    blue: ['#e9eff0', '#537b89'],
  };
  const [bg, fg] = tones[tone];
  return <span style={{ display: 'inline-flex', borderRadius: 99, padding: `${v(0.45)} ${v(1.15)}`, background: bg, color: fg, fontSize: v(1.35), fontWeight: 700, whiteSpace: 'nowrap' }}>{children}</span>;
}

function RoleTracker({ active }: { active: 0 | 1 | 2 }) {
  return (
    <div style={{ position: 'absolute', right: '4%', top: '3.2%', display: 'flex', gap: v(0.8), zIndex: 9 }}>
      {['STAFF', 'ACCOUNTANT', 'OWNER'].map((r, i) => (
        <span key={r} style={{ fontFamily: mono, fontSize: v(1.2), fontWeight: 700, letterSpacing: '.1em', padding: `${v(0.5)} ${v(1.1)}`, borderRadius: 99, border: `1px solid ${i === active ? GOLD : '#c9cfc3'}`, background: i === active ? G : '#faf9f4', color: i === active ? '#f7f2e7' : '#97a198' }}>{i + 1} {r}</span>
      ))}
    </div>
  );
}

function Browser({ children, width = '94%', height = '78%', top = '12%', left = '3%' }: { children: ReactNode; width?: string; height?: string; top?: string; left?: string }) {
  return (
    <motion.div initial={{ opacity: 0, y: 42, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} transition={{ duration: 0.65, ease }}
      style={{ position: 'absolute', left, top, width, height, borderRadius: v(1.2), overflow: 'hidden', background: CREAM, border: '1px solid #cbd4c9', boxShadow: '0 2.6vmin 7vmin #10231d30' }}>
      <div style={{ height: '7%', background: '#faf9f4', borderBottom: `1px solid ${BORDER}`, display: 'flex', alignItems: 'center', gap: v(0.8), padding: `0 ${v(1.5)}` }}>
        {['#cf8d78', '#d7b66f', '#8eaa91'].map((c) => <i key={c} style={{ width: v(0.7), height: v(0.7), borderRadius: '50%', background: c }} />)}
        <div style={{ marginLeft: v(1), width: '29%', background: '#f0efe8', borderRadius: 99, padding: `${v(0.4)} ${v(1.2)}`, color: '#8e978e', fontSize: v(1.2) }}>billguard · demo workspace</div>
      </div>
      <div style={{ height: '93%', position: 'relative' }}>{children}</div>
    </motion.div>
  );
}

function useT() {
  const [t, setT] = useState(0);
  useEffect(() => { const s = performance.now(); const id = setInterval(() => setT((performance.now() - s) / 1000), 60); return () => clearInterval(id); }, []);
  return t;
}

function Shell({ crumb, children }: { crumb: string; children: ReactNode }) {
  const nav = ['Inbox', 'Approvals', 'Records', 'Activity'];
  return (
    <div style={{ position: 'absolute', inset: 0, display: 'flex', background: CREAM, color: TEXT }}>
      <aside style={{ width: '15%', background: GD, padding: `${v(1.6)} ${v(1.2)}`, color: '#f7f2e7', display: 'flex', flexDirection: 'column' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: v(0.8), fontWeight: 800, fontSize: v(1.8) }}>
          <span style={{ color: GOLD, border: `1px solid ${GOLD}`, borderRadius: '28% 28% 28% 9%', width: v(2.2), height: v(2.2), display: 'grid', placeItems: 'center', fontSize: v(1.6) }}>B</span>Billguard
        </div>
        <div style={{ marginTop: v(2.5), border: '1px solid #3d5953', borderRadius: 5, padding: v(0.8), fontFamily: mono, fontSize: v(0.9), color: '#a7bbb2' }}>● SYNTHETIC DEMO</div>
        <div style={{ marginTop: v(2), marginBottom: v(0.8), color: '#81958c', fontFamily: mono, fontSize: v(0.95), letterSpacing: '.12em' }}>WORKSPACE</div>
        {nav.map((n) => <div key={n} style={{ marginBottom: v(0.5), padding: `${v(0.9)} ${v(1)}`, borderRadius: 5, background: n === crumb ? '#36534b' : 'transparent', color: n === crumb ? '#f7f0e2' : '#b6c4be', fontSize: v(1.45), borderLeft: n === crumb ? `2px solid ${GOLD}` : '2px solid transparent' }}>{n}</div>)}
        <div style={{ marginTop: 'auto', border: '1px solid #39584f', borderRadius: 6, padding: v(0.9), color: '#9fb3a9', fontSize: v(1.05) }}>Synthetic data only</div>
      </aside>
      <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>
        <header style={{ height: '9%', borderBottom: `1px solid ${BORDER}`, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: `0 ${v(2.2)}`, fontSize: v(1.3), color: MUTED, background: '#faf9f4' }}>
          <span>Billguard　›　{crumb === 'Records' ? 'Records' : 'Invoice review'}</span><small style={{ border: `1px solid ${BORDER}`, padding: `${v(0.4)} ${v(0.8)}`, borderRadius: 99, color: G }}>● Demo environment</small>
        </header>
        <div style={{ height: '6.5%', background: '#f3f0e6', borderBottom: '1px solid #e6e1d4', display: 'flex', alignItems: 'center', padding: `0 ${v(2.2)}`, color: '#69776e', fontSize: v(1), whiteSpace: 'nowrap', overflow: 'hidden' }}>
          <b style={{ color: '#9b7841', marginRight: v(0.6) }}>△</b><span><b>Synthetic data only.</b> TIN checks are format and supplier matching, not official verification.</span>
        </div>
        <div style={{ flex: 1, minHeight: 0, padding: `${v(1.6)} ${v(2)}`, position: 'relative', overflow: 'hidden' }}>{children}</div>
      </div>
    </div>
  );
}

type Banner = 'warn' | 'error' | 'ok' | null;
type Btn = 'off' | 'ready' | 'pressed';
function Button({ children, state = 'ready', primary = false }: { children: ReactNode; state?: Btn; primary?: boolean }) {
  const off = state === 'off'; const pr = state === 'pressed';
  return <div style={{ padding: `${v(0.75)} ${v(1.2)}`, borderRadius: 5, fontWeight: 700, fontSize: v(1.2), textAlign: 'center', transform: pr ? 'scale(.95)' : 'none', transition: 'transform .12s, background .3s',
    background: off ? '#e9e8e0' : primary ? (pr ? '#1d3b33' : G) : '#f7f7f2', color: off ? '#92978e' : primary ? PAPER : '#56695e', border: primary || off ? 'none' : `1px solid ${BORDER}`,
    boxShadow: pr ? `0 0 0 ${v(0.5)} ${GOLD}66` : 'none' }}>{children}</div>;
}

function Review({ status, tone, date, dateTone, banner, bannerText, actions, locked = false, toast, meta }: {
  status: string; tone: 'green' | 'amber' | 'red' | 'gray' | 'blue'; date: string; dateTone: 'bad' | 'warn' | 'ok' | 'edit'; banner: Banner; bannerText: string;
  actions: ReactNode; locked?: boolean; toast?: string; meta?: string;
}) {
  const bc = banner === 'error' ? ['#faece6', '#ecc8bb', RUST] : banner === 'warn' ? ['#fff8ef', '#f0dfce', '#735f4c'] : ['#e8f0e6', '#cfdccc', '#528061'];
  const dc = dateTone === 'bad' ? RUST : dateTone === 'warn' ? '#9a783e' : G;
  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', gap: v(1), position: 'relative' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div><Label>INVOICE REVIEW</Label><div style={{ fontSize: v(2.4), fontWeight: 800, color: G, marginTop: v(0.4) }}>Serene Pantry Trading</div><div style={{ color: MUTED, fontSize: v(1.05), marginTop: v(0.3) }}>serene-pantry.pdf　·　{meta}</div></div>
        <div style={{ display: 'flex', gap: v(0.8), alignItems: 'center' }}>{locked && <Chip tone="gray">Read-only</Chip>}<motion.div key={status} initial={{ scale: 1.3, opacity: 0.4 }} animate={{ scale: 1, opacity: 1 }} transition={{ type: 'spring', stiffness: 300, damping: 18 }}><Chip tone={tone}>{status}</Chip></motion.div></div>
      </div>
      <div style={{ flex: 1, minHeight: 0, display: 'grid', gridTemplateColumns: '1fr 1.15fr', gap: v(1) }}>
        <div style={{ background: '#e9e9e0', border: `1px solid ${BORDER}`, borderRadius: v(0.8), display: 'grid', placeItems: 'center', padding: v(1.2) }}>
          <div style={{ width: '80%', background: PAPER, boxShadow: '0 1vmin 3vmin #243f391c', padding: v(1.4), color: G }}>
            <Label>INVOICE / ORIGINAL</Label>
            <div style={{ fontSize: v(1.6), fontWeight: 800, marginTop: v(1) }}>Serene Pantry Trading</div>
            <div style={{ height: 1, background: BORDER, margin: `${v(1.3)} 0` }} />
            <div style={{ display: 'grid', gap: v(0.9), fontFamily: mono, fontSize: v(1.05), color: '#68786d' }}>
              <div>Invoice no.　SP-0421</div><div>Date　14 Mar 2025</div><div>Supplier TIN　•••• 784</div><div>Subtotal　MYR 1,000.00</div><div>Tax　MYR 80.00</div><div style={{ color: G, fontWeight: 700 }}>Total　MYR 1,080.00</div>
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: v(0.9) }}>
          <div style={{ border: `1px solid ${BORDER}`, borderRadius: v(0.8), background: PAPER, padding: v(1.2) }}>
            <Label>EXTRACTED FIELDS</Label>
            <div style={{ padding: `${v(0.7)} 0`, borderTop: '1px solid #f0eee7', marginTop: v(0.7), fontSize: v(1.1), color: '#55655b' }}>Invoice number　<b>SP-0421</b></div>
            <div style={{ padding: `${v(0.7)} 0`, borderTop: '1px solid #f0eee7', fontSize: v(1.1), color: '#55655b' }}>Total　<b>MYR 1,080.00</b></div>
            <div style={{ padding: `${v(0.5)} ${v(0.7)}`, border: `1px solid ${dc}`, borderRadius: 4, background: dateTone === 'bad' ? '#fdf4f0' : '#fff', fontSize: v(1.15), color: '#55655b', display: 'flex', justifyContent: 'space-between', minHeight: v(3.2), alignItems: 'center' }}>
              <span>Invoice date</span><b style={{ color: dc, fontFamily: mono }}>{date || 'missing'}{dateTone === 'edit' && <span style={{ opacity: 0.6 }}>|</span>}</b>
            </div>
          </div>
          <motion.div key={bannerText} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} style={{ padding: v(1), background: bc[0], border: `1px solid ${bc[1]}`, borderRadius: 5 }}>
            <div style={{ fontWeight: 800, color: bc[2], fontSize: v(1.2) }}>{banner === 'error' ? 'Blocking error' : banner === 'warn' ? 'Needs a closer look' : 'Checks passed'}</div>
            <div style={{ color: bc[2], fontSize: v(1.02), marginTop: v(0.4), opacity: 0.9 }}>{bannerText}</div>
          </motion.div>
          <div style={{ flex: 1, background: PAPER, border: `1px solid ${BORDER}`, borderRadius: v(0.8), padding: v(1.1), display: 'flex', flexDirection: 'column', gap: v(0.6) }}>
            <Label>{locked ? 'FINAL DECISION' : 'NEXT STEP'}</Label>{actions}
          </div>
        </div>
      </div>
      {toast && <motion.div key={toast} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} style={{ position: 'absolute', right: 0, bottom: 0, background: G, color: PAPER, borderRadius: v(0.6), padding: `${v(0.8)} ${v(1.4)}`, fontSize: v(1.2), fontWeight: 700 }}>{toast}</motion.div>}
    </div>
  );
}

const STEPS = ['SUBMIT', 'FIX', 'APPROVE'];
function Rail({ n, title, lines, t }: { n: 0 | 1 | 2; title: ReactNode; lines: { at: number; head: string; body: string }[]; t: number }) {
  return (
    <>
      <div style={{ position: 'absolute', left: '72%', top: '5%', display: 'flex', gap: v(0.8) }}>
        {STEPS.map((s, i) => <span key={s} style={{ fontFamily: mono, fontSize: v(1.2), fontWeight: 700, letterSpacing: '.1em', padding: `${v(0.5)} ${v(1.1)}`, borderRadius: 99, border: `1px solid ${i === n ? GOLD : '#c9cfc3'}`, background: i === n ? G : '#faf9f4', color: i === n ? '#f7f2e7' : '#97a198' }}>{i + 1} {s}</span>)}
      </div>
      <Reveal delay={0.4} style={{ left: '72%', top: '16%', width: '25%' }}><Title size={5.4}>{title}</Title></Reveal>
      <div style={{ position: 'absolute', left: '72%', top: '40%', width: '25%', display: 'grid', gap: v(1.4) }}>
        {lines.map((l) => (
          <motion.div key={l.head} initial={false} animate={{ opacity: t >= l.at ? 1 : 0, y: t >= l.at ? 0 : 14 }} transition={{ duration: 0.45, ease }} style={{ borderLeft: `3px solid ${GOLD}`, paddingLeft: v(1.2) }}>
            <div style={{ color: G, fontWeight: 800, fontSize: v(1.9) }}>{l.head}</div>
            <div style={{ color: '#627269', fontSize: v(1.45), lineHeight: 1.4, marginTop: v(0.3) }}>{l.body}</div>
          </motion.div>
        ))}
      </div>
    </>
  );
}

export function UploadScene() {
  const t = useT();
  const pressed = t > 6.4 && t < 6.9; const sent = t >= 6.9;
  return (
    <Stage bg="#eef0e8">
      <div style={{ position: 'absolute', left: '4%', top: '4%' }}><Label>01 / SUBMIT — RECONSTRUCTED INVOICE VIEW · SYNTHETIC DATA</Label></div>
      <Rail n={0} t={t} title={<>Submit, even<br />with warnings.</>} lines={[
        { at: 1.8, head: 'Warnings travel', body: 'A flagged date does not stop submission.' },
        { at: 4.5, head: 'One press', body: 'Submit for review sends it to a reviewer.' },
        { at: 8.2, head: 'Now In review', body: 'The invoice leaves Draft and waits for a fix.' },
      ]} />
      <Browser width="66%" top="12%" height="78%">
        <Shell crumb="Inbox">
          <Review status={sent ? 'In review' : 'Draft'} tone={sent ? 'blue' : 'gray'} date="" dateTone={t > 1.8 ? 'warn' : 'bad'}
            banner={t > 1.2 ? 'warn' : null} bannerText="Missing date. Add the date from the original document. You can still submit."
            meta={sent ? 'Submitted for review' : 'Draft'} toast={t > 7.2 ? 'Invoice updated. Sent for review.' : undefined}
            actions={<>
              <Button state="off">Approve (reviewers only)</Button>
              <motion.div animate={t > 5 && !sent ? { scale: [1, 1.04, 1] } : {}} transition={{ repeat: Infinity, duration: 0.9 }}><Button state={sent ? 'off' : pressed ? 'pressed' : 'ready'} primary>{sent ? 'Submitted' : 'Submit for review'}</Button></motion.div>
              <div style={{ fontSize: v(1), color: MUTED }}>Issues block approval, not submission.</div>
            </>} />
        </Shell>
      </Browser>
    </Stage>
  );
}

const TYPED = '14 Mar 2025';
export function IssuesScene() {
  const t = useT();
  const typed = t < 2.8 ? '' : TYPED.slice(0, Math.min(TYPED.length, Math.floor((t - 2.8) / 0.18) + 1));
  const typing = t >= 2.8 && t < 5.4; const saving = t >= 6.4 && t < 6.9; const checking = t >= 6.9 && t < 8; const ok = t >= 8;
  return (
    <Stage bg="#eef0e8">
      <div style={{ position: 'absolute', left: '4%', top: '4%' }}><Label>02 / FIX — RECONSTRUCTED REVIEW VIEW · SYNTHETIC DATA</Label></div>
      <Rail n={1} t={t} title={<>Fix the<br />blocking error.</>} lines={[
        { at: 0.8, head: 'Approval is locked', body: 'A blocking error must be fixed first.' },
        { at: 3, head: 'Compare, then correct', body: 'Match the field to the original document.' },
        { at: 8.4, head: 'Rules re-run', body: 'Saving a correction re-checks everything.' },
        { at: 10.4, head: 'Accountant or Owner', body: 'Either reviewer can correct and approve.' },
      ]} />
      <Browser width="66%" top="12%" height="78%">
        <Shell crumb="Approvals">
          <Review status="In review" tone="blue" date={ok ? TYPED : typed} dateTone={ok ? 'ok' : typing ? 'edit' : t > 6 ? 'warn' : 'bad'}
            banner={ok ? 'ok' : checking ? 'warn' : 'error'}
            bannerText={ok ? 'No blocking errors remain. Approval is now available.' : checking ? 'Re-running validation on the corrected invoice...' : 'Missing date blocks approval. Add it from the original.'}
            meta="In review" toast={ok ? 'Corrections saved. Validation re-run.' : undefined}
            actions={<>
              <Button state={saving ? 'pressed' : t > 5.4 && t < 6.4 ? 'ready' : 'ready'}>Save corrections</Button>
              <Button state="ready">Send back with reason</Button>
              <Button state={ok ? 'ready' : 'off'} primary={ok}>{ok ? 'Approve' : 'Approve (blocked)'}</Button>
              <div style={{ fontSize: v(0.95), color: MUTED }}>TIN checks are format and supplier matching, not official.</div>
            </>} />
        </Shell>
      </Browser>
    </Stage>
  );
}

export function FixScene() {
  const t = useT();
  const pressed = t > 2.6 && t < 3.1; const done = t >= 3.1; const rec = t >= 6.6;
  const rows = [
    ['Bumi Office Supply Sdn Bhd', 'bumi-office.pdf', '12 Mar 2025', 'MYR 1,280.00'],
    ['Sinar Printworks', 'sinar-print.pdf', '16 Mar 2025', 'MYR 820.50'],
  ];
  return (
    <Stage bg="#e9ede2">
      <div style={{ position: 'absolute', left: '4%', top: '4%' }}><Label>03 / APPROVE — RECONSTRUCTED VIEW · SYNTHETIC DATA</Label></div>
      <Rail n={2} t={t} title={<>Approve, then<br />it is a record.</>} lines={[
        { at: 0.8, head: 'Not your own', body: 'The submitter cannot approve their own invoice.' },
        { at: 3.4, head: 'Locked once approved', body: 'Final decisions are read-only.' },
        { at: 7.2, head: 'Records and export', body: 'Approved invoices go to Records for CSV or JSON.' },
      ]} />
      <Browser width="66%" top="12%" height="78%">
        <Shell crumb={rec ? 'Records' : 'Approvals'}>
          {!rec ? (
            <Review status={done ? 'Approved' : 'Awaiting approval'} tone={done ? 'green' : 'amber'} date={TYPED} dateTone="ok" banner="ok"
              bannerText={done ? 'Approved by a different person than the submitter.' : 'No blocking errors remain. Submitted by Siti, so Siti cannot approve it.'}
              meta={done ? 'Approved' : 'Awaiting approval'} locked={done} toast={done ? 'Invoice updated. Approved.' : undefined}
              actions={done ? <><Button state="off">Fields locked</Button><div style={{ fontSize: v(1.1), color: G, fontWeight: 700 }}>Final decisions are read-only.</div></> : <>
                <Button state={pressed ? 'pressed' : 'ready'} primary>Approve</Button><Button>Send back with reason</Button><Button>Reject with reason</Button></>} />
          ) : (
            <motion.div initial={{ opacity: 0, x: 40 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5, ease }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div><Label>APPROVED ARCHIVE</Label><div style={{ color: G, fontWeight: 800, fontSize: v(2.5), marginTop: v(0.4) }}>Records</div></div>
                <div style={{ display: 'flex', gap: v(0.8) }}><span style={{ padding: `${v(0.8)} ${v(1)}`, border: `1px solid ${BORDER}`, borderRadius: 4, color: G, fontSize: v(1.05), fontWeight: 700 }}>Export CSV</span><span style={{ padding: `${v(0.8)} ${v(1)}`, background: G, borderRadius: 4, color: PAPER, fontSize: v(1.05), fontWeight: 700 }}>Export JSON</span></div>
              </div>
              <div style={{ margin: `${v(1.2)} 0`, background: '#e9ede2', padding: v(1), borderRadius: 5, color: '#3f594b', fontSize: v(1.15), fontWeight: 700 }}>Approved and ready to keep</div>
              <div style={{ border: `1px solid ${BORDER}`, borderRadius: v(0.8), background: PAPER, overflow: 'hidden' }}>
                {[['Serene Pantry Trading', 'serene-pantry.pdf', '14 Mar 2025', 'MYR 1,080.00'], ...rows].map(([a, b, c, d], i) => (
                  <motion.div key={a} initial={{ opacity: 0, x: 18 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 + i * 0.2 }} style={{ display: 'flex', alignItems: 'center', minHeight: v(4.6), padding: `0 ${v(1.2)}`, borderTop: i ? '1px solid #f0eee7' : 'none', background: i === 0 ? '#f1f6ee' : PAPER, fontSize: v(1.2), color: '#647168' }}>
                    <span style={{ flex: 2.2, color: G, fontWeight: 700 }}>{a}<small style={{ display: 'block', color: '#a0a59d', fontSize: v(0.9), fontWeight: 400 }}>{b}</small></span>
                    <span style={{ flex: 1 }}>{c}</span><span style={{ flex: 1, fontFamily: mono }}>{d}</span><span style={{ flex: 0.8 }}><Chip tone="green">Approved</Chip></span>
                  </motion.div>))}
              </div>
            </motion.div>
          )}
        </Shell>
      </Browser>
    </Stage>
  );
}

export function RolesScene() {
  const gates = [
    { n: 'SUBMIT', h: 'Warnings may pass.', d: 'Submission is never blocked by a warning.', c: '#c9d8bf' },
    { n: 'FIX', h: 'Every correction re-runs rules.', d: 'Blocking errors clear before approval.', c: GOLD },
    { n: 'APPROVE', h: 'Different person, no errors.', d: 'Then the record is read-only.', c: '#c9d8bf' },
  ];
  return (
    <Stage bg={GD}>
      <Reveal delay={0.1} style={{ left: '6%', top: '9%' }}><Label color={GOLD}>THE CHECKS THAT KEEP APPROVAL HONEST</Label></Reveal>
      <Reveal delay={0.25} style={{ left: '6%', top: '17%' }}><Title color="#f7f2e7" size={6.2}>A reviewer stays human.</Title></Reveal>
      <div style={{ position: 'absolute', left: '7%', right: '7%', top: '41%', display: 'grid', gridTemplateColumns: '1fr 1.2fr 1fr', gap: v(1) }}>
        {gates.map((x, i) => (
          <motion.div key={x.n} initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 + i * 0.3, duration: 0.45 }} style={{ borderTop: `3px solid ${x.c}`, padding: `${v(1.5)} ${v(1.4)}`, background: '#1b3932' }}>
            <Label color={x.c}>{i + 1} {x.n}</Label><div style={{ color: '#f7f2e7', fontSize: v(2.5), fontWeight: 800, margin: `${v(0.9)} 0` }}>{x.h}</div><div style={{ color: '#a7bbb2', fontSize: v(1.65) }}>{x.d}</div>
          </motion.div>))}
      </div>
      <motion.div initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 1.6, type: 'spring', stiffness: 240 }} style={{ position: 'absolute', left: '39%', top: '70%', width: '22%', height: v(3), borderRadius: 99, background: '#42302d', boxShadow: `0 0 0 ${v(0.5)} ${RUST}` }}>
        <motion.div animate={{ x: ['0%', '100%'] }} transition={{ delay: 2.1, duration: 1.1, ease: 'linear' }} style={{ width: v(2.8), height: v(2.8), marginTop: '-0.4vmin', background: RUST, borderRadius: '50%' }} />
      </motion.div>
      <Reveal delay={1.9} style={{ left: '7%', top: '68%' }}><div style={{ color: '#f7f2e7', fontSize: v(2.3), fontWeight: 800 }}>Unresolved error → approval blocked</div></Reveal>
      <Reveal delay={2.6} style={{ right: '7%', top: '68%' }}><div style={{ color: GOLD, fontSize: v(2.3), fontWeight: 800 }}>Submitter ≠ approver</div></Reveal>
      <Reveal delay={4} style={{ left: '7%', bottom: '9%' }}><div style={{ color: '#a7bbb2', fontSize: v(1.75) }}>Synthetic demo. TIN checks are not official verification.</div></Reveal>
      <Reveal delay={5.5} style={{ right: '7%', bottom: '9%' }}><div style={{ color: '#a7bbb2', fontSize: v(1.5) }}>AI extraction can err. Check the original.</div></Reveal>
    </Stage>
  );
}

export function HookScene() {
  return (
    <Stage bg={GD}>
      <motion.div style={{ position: 'absolute', left: '57%', top: '14%', width: '28%', height: '70%', borderRadius: v(2), background: CREAM, border: `2px solid ${GOLD}`, transformOrigin: 'center' }}
        initial={{ opacity: 0, rotate: -18, scale: 0.64, x: 120 }} animate={{ opacity: 1, rotate: -6, scale: 1, x: 0 }} transition={{ type: 'spring', stiffness: 170, damping: 20 }}>
        <div style={{ padding: v(3), color: G }}><Label>INVOICE / SAMPLE 04</Label><div style={{ marginTop: v(4), fontSize: v(4), fontWeight: 800 }}>Supplier<br />invoice</div><div style={{ marginTop: v(4), height: 1, background: '#dce3d5' }} /><div style={{ marginTop: v(4), fontFamily: mono, fontSize: v(1.7), color: MUTED }}>REVIEW COPY</div></div>
      </motion.div>
      <Reveal delay={0.25} style={{ left: '7%', top: '20%' }}><div style={{ fontSize: v(2), letterSpacing: '.18em', color: GOLD, fontWeight: 700 }}>BILLGUARD / GUIDED DEMO</div></Reveal>
      <Reveal delay={0.18} style={{ left: '7%', top: '34%' }}><Title color="#f7f2e7" size={10}>Submit. Fix.<br />Approve.</Title></Reveal>
      <Reveal delay={1.5} style={{ left: '7%', top: '67%' }}><div style={{ color: '#a7bbb2', fontSize: v(2.4) }}>The invoice actions, step by step.</div></Reveal>
      <motion.div initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ delay: 2.3, duration: 0.7 }} style={{ position: 'absolute', left: '7%', top: '62%', width: '27%', height: 2, background: GOLD, transformOrigin: 'left' }} />
    </Stage>
  );
}

export function OutroScene() {
  return (
    <Stage bg={GD}>
      <motion.div initial={{ opacity: 0, scale: 0.72 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.65, ease }}
        style={{ position: 'absolute', left: '50%', top: '28%', transform: 'translateX(-50%)', display: 'flex', alignItems: 'center', gap: v(2.4) }}>
        <div style={{ width: v(8), height: v(8), border: `2px solid ${GOLD}`, borderRadius: `${v(2.5)} ${v(2.5)} ${v(2.5)} ${v(0.8)}`, transform: 'rotate(-4deg)', display: 'grid', placeItems: 'center', color: GOLD, fontSize: v(5.2), fontWeight: 800 }}>B</div>
        <div style={{ fontSize: v(10), fontWeight: 800, color: '#f7f2e7', letterSpacing: '-.06em' }}>bill<span style={{ color: GOLD, fontWeight: 600, marginLeft: v(0.8) }}>guard</span></div>
      </motion.div>
      <Reveal delay={0.8} style={{ left: 0, right: 0, top: '51%', textAlign: 'center' }}><div style={{ color: GOLD, fontSize: v(3.4), fontWeight: 700 }}>Upload. Review. Correct. Approve.</div></Reveal>
      <Reveal delay={1.45} style={{ left: '12%', right: '12%', top: '67%', textAlign: 'center' }}>
        <div style={{ color: '#a7bbb2', fontSize: v(1.65), lineHeight: 1.65 }}>Synthetic data only. TIN checks are demo format and supplier matching—not government verification.<br />Not production-ready. Extraction can err; human review remains required.</div>
      </Reveal>
      <motion.div initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ delay: 2.2, duration: 0.6 }} style={{ position: 'absolute', left: '42%', top: '88%', width: '16%', height: 1, background: GOLD, transformOrigin: 'center' }} />
    </Stage>
  );
}
