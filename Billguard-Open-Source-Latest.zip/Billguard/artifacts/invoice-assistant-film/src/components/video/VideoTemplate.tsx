import { useEffect, useRef } from 'react';
import { VideoCanvas, type VideoAspectRatio, useVideoPlayer, VideoPausedContext } from '@/lib/video';
import { AnimatePresence, motion } from 'framer-motion';
import { HookScene, UploadScene, IssuesScene, FixScene, RolesScene, OutroScene } from './scenes/Scenes';

export const SCENE_DURATIONS = { hook: 4200, upload: 13800, issues: 14400, fix: 12600, roles: 9000, outro: 6000 };
const SCENES: Record<string, React.ComponentType> = { hook: HookScene, upload: UploadScene, issues: IssuesScene, fix: FixScene, roles: RolesScene, outro: OutroScene };
const VIDEO_ASPECT_RATIO: VideoAspectRatio = '16:9';
const START: Record<string, number> = (() => { const o: Record<string, number> = {}; let t = 0; for (const [k, ms] of Object.entries(SCENE_DURATIONS)) { o[k] = t / 1000; t += ms; } return o; })();

export default function VideoTemplate({ durations = SCENE_DURATIONS, loop = true, paused = false, muted = false, onSceneChange }: {
  durations?: Record<string, number>; loop?: boolean; paused?: boolean; muted?: boolean; onSceneChange?: (k: string) => void;
} = {}) {
  const { currentSceneKey } = useVideoPlayer({ durations, loop, paused });
  useEffect(() => { onSceneChange?.(currentSceneKey); }, [currentSceneKey, onSceneChange]);
  const base = currentSceneKey.replace(/_r[12]$/, '');
  const idx = Object.keys(SCENE_DURATIONS).indexOf(base);
  const Scene = SCENES[base];
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const last = useRef<string | null>(null);
  useEffect(() => {
    const a = audioRef.current; if (!a) return;
    a.volume = 0.5;
    if (paused) { a.pause(); return; }
    if (last.current !== currentSceneKey) {
      last.current = currentSceneKey;
      const t = START[base] ?? 0;
      if (Math.abs(a.currentTime - t) > 0.18) a.currentTime = t;
    }
    a.play().catch(() => {});
  }, [currentSceneKey, base, muted, paused]);
  return (
    <VideoPausedContext.Provider value={paused}>
      <VideoCanvas aspectRatio={VIDEO_ASPECT_RATIO} style={{ backgroundColor: '#f6f4ed' }}>
        <motion.div className="absolute inset-0" animate={{ scale: 1 + idx * 0.01 }} transition={{ duration: 1 }}>
          <AnimatePresence mode="sync">{Scene && <Scene key={currentSceneKey} />}</AnimatePresence>
        </motion.div>
        <audio ref={audioRef} src={`${import.meta.env.BASE_URL}audio/bg_music.mp3`} preload="auto" autoPlay muted={muted} />
      </VideoCanvas>
    </VideoPausedContext.Provider>
  );
}
