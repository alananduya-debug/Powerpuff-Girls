# Billguard — Submit, Fix, Approve (action walkthrough)

16:9, 60.0s. Evergreen/cream/sage, Manrope + IBM Plex Mono. No sign-in, role-switching or role-explanation content. All app screens are labelled reconstructions with synthetic data. Step tracker (1 SUBMIT / 2 FIX / 3 APPROVE) top-right in shots 2-4.

| Shot | Time | Action shown |
|---|---|---|
| 1 | 0-4.2 | Title "Submit. Fix. Approve." ; invoice sheet |
| 2 | 4.2-18 | SUBMIT: Draft invoice with missing-date warning; "Submit for review" pulses (~5s), pressed (~6.4s); status becomes In review, toast "Invoice updated." Warnings do not block submission. |
| 3 | 18-32.4 | FIX: blocking error, Approve disabled/blocked; date typed "14 Mar 2025" (~2.8-5s); Save corrections pressed (~6.4s); validation re-runs; error clears, Approve activates (~8s). Accountant or Owner can correct and approve. TIN note: format/supplier matching only. |
| 4 | 32.4-45 | APPROVE: Awaiting approval, submitter cannot self-approve; Approve pressed (~2.6s); status Approved, fields locked/read-only; Records list (~6.6s) with the invoice, Export CSV / JSON. |
| 5 | 45-54 | Checks: warnings may pass; every correction re-runs rules; different approver and no errors; unresolved error blocks approval; submitter is not approver; AI extraction can err. |
| 6 | 54-60 | billguard lockup; "Upload. Review. Correct. Approve."; synthetic-only and not-production disclosures. |

Audio: unchanged existing 60s instrumental bed (public/audio/bg_music.mp3). Durations 4.2/13.8/14.4/12.6/9.0/6.0 unchanged.
