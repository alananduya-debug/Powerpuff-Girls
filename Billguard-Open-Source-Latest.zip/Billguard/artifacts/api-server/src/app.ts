import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";
import { getCurrentUser } from "../../../server/hub-mock/index";
import { clerkMiddleware } from "@clerk/express";
import { publishableKeyFromHost } from "@clerk/shared/keys";
import { CLERK_PROXY_PATH, clerkProxyMiddleware, getClerkProxyHost } from "./middlewares/clerkProxyMiddleware";
import { requireAccount } from "./lib/auth";
import { workspaceContext } from "./lib/database";
import teamAccessRouter from "./routes/team-access";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors({ origin: false }));
app.use(CLERK_PROXY_PATH, clerkProxyMiddleware());
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true, limit: "1mb" }));
app.use(clerkMiddleware((req) => ({
  publishableKey: publishableKeyFromHost(
    getClerkProxyHost(req) ?? "", process.env.CLERK_PUBLISHABLE_KEY,
  ),
})));

app.use("/api", (_req, res, next) => {
  res.setHeader("Cache-Control", "no-store");
  res.setHeader("X-Content-Type-Options", "nosniff");
  next();
});
app.use("/api", (req, res, next) => {
  if (!["GET", "HEAD", "OPTIONS"].includes(req.method) && req.headers.origin) {
    const host = getClerkProxyHost(req);
    try {
      if (new URL(req.headers.origin).host !== host) {
        res.status(403).json({ error: "Cross-site changes are not allowed." });
        return;
      }
    } catch {
      res.status(403).json({ error: "Invalid request origin." });
      return;
    }
  }
  next();
});
app.use(
  "/api/team-access",
  requireAccount,
  (req, res, next) => {
    if (res.locals.invoiceUser?.role !== "Owner") {
      res.status(403).json({ error: "Only workspace owners can manage team access." });
      return;
    }
    workspaceContext.run("account", next);
  },
  teamAccessRouter,
);
app.use("/api/demo-workspace", (req, res, next) => {
  try { getCurrentUser(req.header("x-demo-user-id")); }
  catch { res.status(401).json({ error: "Choose a recognised demo user." }); return; }
  workspaceContext.run("demo", next);
}, router);
app.get("/api/healthz", (_req, res) => res.json({ status: "ok" }));
app.use("/api", requireAccount, (req, res, next) => {
  if (req.path.startsWith("/demo/") || req.path === "/demo") {
    res.status(404).json({ error: "Synthetic samples are only available in the demo workspace." });
    return;
  }
  workspaceContext.run("account", next);
}, router);

app.use(
  (
    error: unknown,
    req: express.Request,
    res: express.Response,
    _next: express.NextFunction,
  ) => {
    if (
      error &&
      typeof error === "object" &&
      "code" in error &&
      error.code === "LIMIT_FILE_SIZE"
    ) {
      res.status(413).json({ error: "Invoice files must be 15 MB or smaller." });
      return;
    }
    req.log.error({ statusCode: 500 }, "Request failed");
    res.status(500).json({
      error: "The request could not be completed securely. Please try again.",
    });
  },
);

export default app;
