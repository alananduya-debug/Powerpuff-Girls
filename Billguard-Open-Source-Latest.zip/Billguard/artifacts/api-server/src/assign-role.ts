/**
 * Trusted operator command. No HTTP endpoint can assign roles.
 * pnpm --filter @workspace/api-server assign-role verified@example.com Owner
 * Run in the target environment: development users are not production users.
 */
import { clerkClient } from "@clerk/express";
import { assignedRole } from "./lib/auth";
import { updateMemberRole } from "./lib/team-access";
import { workspaceContext } from "./lib/database";
import { logger } from "./lib/logger";

const [email, requestedRole] = process.argv.slice(2);
const role = assignedRole(requestedRole);
if (!email || (!role && requestedRole !== "revoke")) {
  throw new Error("Usage: assign-role <verified-email> <Staff|Accountant|Owner|revoke>");
}
const users = await clerkClient.users.getUserList({ emailAddress: [email], limit: 2 });
const user = users.data.length === 1 ? users.data[0] : undefined;
if (!user || !user.emailAddresses.some((address) =>
  address.emailAddress.toLowerCase() === email.toLowerCase() && address.verification?.status === "verified")) {
  throw new Error("Exactly one existing account with this verified email is required. Ask the user to sign up and verify their email first.");
}
await workspaceContext.run("account", async () => {
  const updated = await updateMemberRole({
    actorId: "trusted-operator-command",
    actorName: "Trusted operator command",
    targetId: user.id,
    role: role ?? null,
  });
  logger.info({ role: updated.role ?? "revoked" }, "Workspace role updated in the configured Clerk environment");
});
