import { randomUUID } from "node:crypto";
import { createReadStream } from "node:fs";
import { readFile } from "node:fs/promises";
import { Router, type IRouter, type Request, type Response } from "express";
import multer from "multer";
import {
  ApproveInvoiceParams,
  ApproveInvoiceResponse,
  GetActivityResponse,
  GetApprovedRecordsResponse,
  GetInvoiceActivityParams,
  GetInvoiceActivityResponse,
  GetInvoiceParams,
  GetInvoiceResponse,
  GetOcrSettingsResponse,
  GetSummaryResponse,
  ListInvoicesResponse,
  ListUsersResponse,
  PassInvoiceToOwnerBody,
  PassInvoiceToOwnerParams,
  PassInvoiceToOwnerResponse,
  RejectInvoiceBody,
  RejectInvoiceParams,
  RejectInvoiceResponse,
  RevealInvoiceFieldBody,
  RevealInvoiceFieldParams,
  RevealInvoiceFieldResponse,
  SendBackInvoiceBody,
  SendBackInvoiceParams,
  SendBackInvoiceResponse,
  SubmitInvoiceParams,
  SubmitInvoiceResponse,
  UpdateInvoiceBody,
  UpdateInvoiceParams,
  UpdateInvoiceResponse,
  UpdateOcrSettingsBody,
  UpdateOcrSettingsResponse,
  UploadInvoiceResponse,
} from "@workspace/api-zod";
import { getCurrentUser } from "../../../../server/hub-mock/index";
import { InvoiceError } from "../../../../server/rules/workflow";
import { canAccessInvoice } from "../lib/invoice-access";
import {
  addActivityEntry,
  applyInvoiceAction,
  getActivity,
  getApprovedRecords,
  getAuthorizedInvoiceFile,
  getInvoiceDetail,
  getInvoices,
  getOcrSettings,
  getSummary,
  getUsers,
  revealInvoiceField,
  uploadInvoice,
  updateInvoice,
  getExportRows,
  setOcrMode,
  listDemoSamples,
  getDemoSampleFile,
  loadDemoSample,
} from "../lib/invoice-service";

const router: IRouter = Router();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 15 * 1024 * 1024, files: 1 },
});

const safeServiceMessages = new Set([
  "We couldn't read this invoice. Check the file or try again later.",
  "Staff may only edit fields flagged for correction.",
  "Only accountants can change the supplier.",
  "Supplier record was not found.",
  "Each line item needs a description and amount.",
  "Only staff and accountants can edit invoices.",
  "Only staff can submit invoices for review.",
  "Fix or have an accountant review the blocking warnings before submitting.",
  "Only an accountant can send an invoice back.",
  "This invoice is not awaiting accountant review.",
  "Only an accountant can pass an invoice to the owner.",
  "Only the owner can approve.",
  "The person who submitted this invoice cannot give final approval.",
  "Only invoices awaiting approval can be approved.",
  "Only the owner can reject.",
  "This invoice has already received a final decision.",
]);

function currentUser(req: Request) {
  if (req.res?.locals.invoiceUser) return req.res.locals.invoiceUser as ReturnType<typeof getCurrentUser>;
  return getCurrentUser(req.header("x-demo-user-id") ?? undefined);
}

function sendSafeError(res: Response, error: unknown): void {
  if (error instanceof InvoiceError) {
    res.status(error.status).json({ error: error.message });
    return;
  }
  const message =
    error instanceof Error && safeServiceMessages.has(error.message)
      ? error.message
      : "The request could not be completed. Check the invoice and try again.";
  res.status(message.startsWith("Only ") ? 403 : 400).json({ error: message });
}

function getStringParam(
  params: Record<string, string | string[] | undefined>,
  key: string,
): string | undefined {
  const value = params[key];
  return Array.isArray(value) ? value[0] : value;
}

router.get("/users", (req, res) => {
  res.json(ListUsersResponse.parse(res.locals.invoiceUser ? [currentUser(req)] : getUsers()));
});

router.get("/summary", (req, res) => {
  const user = currentUser(req);
  res.json(GetSummaryResponse.parse(getSummary(user.role)));
});

router.get("/settings/ocr", (_req, res) => {
  res.json(GetOcrSettingsResponse.parse(getOcrSettings()));
});

router.put("/settings/ocr", (req, res) => {
  const body = UpdateOcrSettingsBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: "Choose live or cached invoice reading." });
    return;
  }
  const user = currentUser(req);
  if (user.role !== "Owner") {
    res.status(403).json({ error: "Only the owner can change OCR settings." });
    return;
  }
  try {
    res.json(
      UpdateOcrSettingsResponse.parse(setOcrMode(body.data.mode, user.id)),
    );
  } catch (error) {
    sendSafeError(res, error);
  }
});

router.get("/invoices", (req, res) => {
  res.json(ListInvoicesResponse.parse(getInvoices(currentUser(req).role)));
});

router.post("/invoices/upload", upload.single("file"), async (req, res): Promise<void> => {
  const user = currentUser(req);
  const file = req.file;
  if (!file) {
    res.status(400).json({ error: "Choose an invoice image or PDF to upload." });
    return;
  }
  const allowedTypes = new Set([
    "application/pdf",
    "image/jpeg",
    "image/png",
    "image/webp",
    "image/svg+xml",
  ]);
  if (!allowedTypes.has(file.mimetype)) {
    res.status(415).json({ error: "Upload a PDF, JPG, PNG, or WebP invoice." });
    return;
  }
  if (
    file.mimetype === "image/webp" &&
    !(file.buffer.subarray(0, 4).toString("ascii") === "RIFF" && file.buffer.subarray(8, 12).toString("ascii") === "WEBP")
  ) {
    res.status(415).json({ error: "The uploaded file is not a valid WebP image." });
    return;
  }
  if (
    file.mimetype === "application/pdf" &&
    !file.buffer.subarray(0, 5).equals(Buffer.from("%PDF-"))
  ) {
    res.status(415).json({ error: "The uploaded file is not a valid PDF." });
    return;
  }
  if (
    file.mimetype === "image/png" &&
    !file.buffer.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))
  ) {
    res.status(415).json({ error: "The uploaded file is not a valid PNG image." });
    return;
  }
  if (
    file.mimetype === "image/jpeg" &&
    !(file.buffer[0] === 0xff && file.buffer[1] === 0xd8)
  ) {
    res.status(415).json({ error: "The uploaded file is not a valid JPEG image." });
    return;
  }
  if (
    file.mimetype === "image/svg+xml" &&
    (/<script\b|on\w+\s*=|(?:href|src)\s*=\s*["'](?:https?:|javascript:|data:)/i.test(
      file.buffer.toString("utf8"),
    ) ||
      !file.buffer.toString("utf8").trimStart().startsWith("<svg"))
  ) {
    res.status(415).json({ error: "This SVG image cannot be safely previewed." });
    return;
  }
  if (file.mimetype === "image/svg+xml") {
    const sample = getDemoSampleFile(file.originalname);
    if (!sample || !sample.equals(file.buffer)) {
      res.status(415).json({ error: "SVG uploads are limited to the exact downloaded demo samples. Use PDF, PNG, JPEG or WebP for other invoices." });
      return;
    }
  }
  try {
    if (!res.locals.invoiceUser && getOcrSettings().mode === "live" &&
        req.header("x-live-ai-consent") !== "yes") {
      res.status(400).json({ error: "Confirm that this is non-sensitive test data and may be sent to Runpod before uploading." });
      return;
    }
    const result = await uploadInvoice(
      file.originalname,
      file.mimetype,
      file.buffer,
      user.id,
    );
    if (user.role === "Accountant") {
      const submitted = applyInvoiceAction(result.invoice.id, user.id, user.role, "submit");
      const visible = submitted && getInvoices(user.role).find((invoice) => invoice.id === submitted.id);
      if (visible) result.invoice = visible;
    }
    res.status(201).json(UploadInvoiceResponse.parse(result));
  } catch (error) {
    if (
      error instanceof Error &&
      error.message === "We couldn't read this invoice. Check the file or try again later."
    ) {
      res.status(422).json({ error: error.message });
    } else {
      sendSafeError(res, error);
    }
  }
});

// All invoice-specific routes, including files, audit and writes, use this gate.
router.use("/invoices/:invoiceId", (req, res, next) => {
  const id = getStringParam(req.params, "invoiceId");
  const invoice = id ? getInvoiceDetail(id) : undefined;
  if (!invoice) {
    res.status(404).json({ error: "Invoice not found." });
    return;
  }
  if (!canAccessInvoice(currentUser(req).role, invoice.status)) {
    res.status(403).json({ error: "Your role cannot access invoices with this status. Return to your inbox to see available invoices." });
    return;
  }
  next();
});

router.get("/invoices/:invoiceId", (req, res) => {
  const params = GetInvoiceParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid invoice reference." });
    return;
  }
  const invoice = getInvoiceDetail(params.data.invoiceId);
  if (!invoice) {
    res.status(404).json({ error: "Invoice not found." });
    return;
  }
  const user = currentUser(req);
  res.json(GetInvoiceResponse.parse(invoice));
});

router.patch("/invoices/:invoiceId", (req, res) => {
  const params = UpdateInvoiceParams.safeParse(req.params);
  const body = UpdateInvoiceBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Check the invoice fields and try again." });
    return;
  }
  const user = currentUser(req);
  try {
    const invoice = updateInvoice(
      params.data.invoiceId,
      user.id,
      user.role,
      body.data as Record<string, unknown>,
    );
    if (!invoice) {
      res.status(404).json({ error: "Invoice not found." });
      return;
    }
    res.json(UpdateInvoiceResponse.parse(invoice));
  } catch (error) {
    sendSafeError(res, error);
  }
});

router.post("/invoices/:invoiceId/reveal", (req, res) => {
  const params = RevealInvoiceFieldParams.safeParse(req.params);
  const body = RevealInvoiceFieldBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Choose a valid invoice field to reveal." });
    return;
  }
  const user = currentUser(req);
  if (user.role !== "Accountant" && user.role !== "Owner") {
    res.status(403).json({ error: "Only accountants and owners can reveal protected fields." });
    return;
  }
  const value = revealInvoiceField(params.data.invoiceId, body.data.field, user.id);
  if (value === undefined) {
    res.status(404).json({ error: "Invoice or protected field not found." });
    return;
  }
  res.json(RevealInvoiceFieldResponse.parse({ field: body.data.field, value }));
});

router.get("/invoices/:invoiceId/file", async (req, res): Promise<void> => {
  const invoiceId = getStringParam(req.params, "invoiceId");
  if (!invoiceId) {
    res.status(400).json({ error: "Invalid invoice reference." });
    return;
  }
  const user = currentUser(req);
  try {
    const file = await getAuthorizedInvoiceFile(invoiceId, user.id, user.role);
    if (!file) {
      res.status(404).json({ error: "Invoice file not found or access is not allowed." });
      return;
    }
    res.setHeader("Content-Type", file.mimeType);
    res.setHeader("Content-Disposition", `inline; filename="invoice-preview"`);
    res.setHeader("Cache-Control", "no-store");
    res.setHeader("X-Content-Type-Options", "nosniff");
    if (file.mimeType === "image/svg+xml") {
      res.setHeader(
        "Content-Security-Policy",
        "sandbox; default-src 'none'; style-src 'unsafe-inline';",
      );
    }
    res.send(file.bytes);
  } catch {
    res.status(500).json({ error: "The protected invoice file could not be opened." });
  }
});

router.post("/invoices/:invoiceId/submit", (req, res) => {
  const params = SubmitInvoiceParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid invoice reference." });
    return;
  }
  const user = currentUser(req);
  try {
    const invoice = applyInvoiceAction(
      params.data.invoiceId,
      user.id,
      user.role,
      "submit",
    );
    if (!invoice) {
      res.status(404).json({ error: "Invoice not found." });
      return;
    }
    res.json(SubmitInvoiceResponse.parse(invoice));
  } catch (error) {
    sendSafeError(res, error);
  }
});

router.post("/invoices/:invoiceId/send-back", (req, res) => {
  const params = SendBackInvoiceParams.safeParse(req.params);
  const body = SendBackInvoiceBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Check the review comment and try again." });
    return;
  }
  const user = currentUser(req);
  try {
    const invoice = applyInvoiceAction(
      params.data.invoiceId,
      user.id,
      user.role,
      "send-back",
      body.data.comment,
    );
    if (!invoice) {
      res.status(404).json({ error: "Invoice not found." });
      return;
    }
    res.json(SendBackInvoiceResponse.parse(invoice));
  } catch (error) {
    sendSafeError(res, error);
  }
});

router.post("/invoices/:invoiceId/pass-to-owner", (req, res) => {
  const params = PassInvoiceToOwnerParams.safeParse(req.params);
  const body = PassInvoiceToOwnerBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Check the review comment and try again." });
    return;
  }
  const user = currentUser(req);
  try {
    const invoice = applyInvoiceAction(
      params.data.invoiceId,
      user.id,
      user.role,
      "pass-to-owner",
      body.data.comment,
    );
    if (!invoice) {
      res.status(404).json({ error: "Invoice not found." });
      return;
    }
    res.json(PassInvoiceToOwnerResponse.parse(invoice));
  } catch (error) {
    sendSafeError(res, error);
  }
});

router.post("/invoices/:invoiceId/approve", (req, res) => {
  const params = ApproveInvoiceParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid invoice reference." });
    return;
  }
  const user = currentUser(req);
  try {
    const invoice = applyInvoiceAction(
      params.data.invoiceId,
      user.id,
      user.role,
      "approve",
    );
    if (!invoice) {
      res.status(404).json({ error: "Invoice not found." });
      return;
    }
    res.json(ApproveInvoiceResponse.parse(invoice));
  } catch (error) {
    sendSafeError(res, error);
  }
});

router.post("/invoices/:invoiceId/reject", (req, res) => {
  const params = RejectInvoiceParams.safeParse(req.params);
  const body = RejectInvoiceBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Check the rejection note and try again." });
    return;
  }
  const user = currentUser(req);
  try {
    const invoice = applyInvoiceAction(
      params.data.invoiceId,
      user.id,
      user.role,
      "reject",
      body.data.comment,
    );
    if (!invoice) {
      res.status(404).json({ error: "Invoice not found." });
      return;
    }
    res.json(RejectInvoiceResponse.parse(invoice));
  } catch (error) {
    sendSafeError(res, error);
  }
});

router.get("/invoices/:invoiceId/activity", (req, res) => {
  const params = GetInvoiceActivityParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid invoice reference." });
    return;
  }
  res.json(GetInvoiceActivityResponse.parse(getActivity(params.data.invoiceId, currentUser(req).role)));
});

router.get("/activity", (req, res) => {
  res.json(GetActivityResponse.parse(getActivity(undefined, currentUser(req).role)));
});

router.get("/records", (req, res) => {
  res.json(GetApprovedRecordsResponse.parse(getApprovedRecords(currentUser(req).role)));
});

router.get("/exports/:format", async (req, res): Promise<void> => {
  const user = currentUser(req);
  if (user.role !== "Owner") {
    res.status(403).json({ error: "Only the owner can export records." });
    return;
  }
  const format = getStringParam(req.params, "format");
  if (format !== "csv" && format !== "json") {
    res.status(400).json({ error: "Choose CSV or JSON export." });
    return;
  }
  try {
    const data = getExportRows();
    addActivityEntry(null, user.id, `exported ${format.toUpperCase()}`);
    if (format === "json") {
      res
        .status(200)
        .type("application/json")
        .setHeader("Content-Disposition", 'attachment; filename="approved-invoices.json"')
        .send(JSON.stringify(data, null, 2));
      return;
    }
    const columns = [
      "supplier",
      "supplierTin",
      "invoiceNumber",
      "date",
      "currency",
      "subtotal",
      "tax",
      "total",
      "lineItems",
    ];
    const escape = (value: unknown) => {
      const text =
        typeof value === "string" ? value : JSON.stringify(value ?? "");
      const safeText = /^[\s]*[=+\-@\t\r]/.test(text) ? `'${text}` : text;
      return `"${safeText.replaceAll('"', '""')}"`;
    };
    const csv = [
      columns.map(escape).join(","),
      ...data.map((row) => columns.map((column) => escape(row[column])).join(",")),
    ].join("\r\n");
    res
      .status(200)
      .type("text/csv")
      .setHeader("Content-Disposition", 'attachment; filename="approved-invoices.csv"')
      .send(csv);
  } catch {
    res.status(500).json({ error: "The export could not be created securely." });
  }
});

router.get("/demo/info", (_req, res) => res.json({
  demo: true, liveAiConfigured: getOcrSettings().liveConfigured, tinVerification: "format-and-supplier-match",
}));
router.get("/demo/samples", (_req, res) => res.json(listDemoSamples()));
router.get("/demo/samples/:fileName", (req, res) => {
  const sample = getDemoSampleFile(String(req.params.fileName));
  if (!sample) { res.status(404).json({ error: "Demo sample not found." }); return; }
  res.type("image/svg+xml").setHeader("Content-Disposition", `attachment; filename="${String(req.params.fileName)}"`);
  res.setHeader("Content-Security-Policy", "sandbox; default-src 'none'; style-src 'unsafe-inline'");
  res.send(sample);
});
router.post("/demo/load/:fileName", async (req, res) => {
  try {
    const user = currentUser(req);
    let invoice = await loadDemoSample(String(req.params.fileName), user.id);
    if (!invoice) { res.status(404).json({ error: "Demo sample not found." }); return; }
    if (user.role === "Accountant") invoice = applyInvoiceAction(invoice.id, user.id, user.role, "submit") ?? invoice;
    res.status(201).json(GetInvoiceResponse.parse(invoice));
  } catch (error) { sendSafeError(res, error); }
});

export default router;
