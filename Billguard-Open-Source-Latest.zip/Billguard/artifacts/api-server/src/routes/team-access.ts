import { Router, type IRouter, type Request, type Response } from "express";
import {
  GetTeamAccessAuditResponse,
  SearchTeamMembersQueryParams,
  SearchTeamMembersResponse,
  UpdateTeamMemberRoleBody,
  UpdateTeamMemberRoleParams,
  UpdateTeamMemberRoleResponse,
} from "@workspace/api-zod";
import { assignedRole } from "../lib/auth";
import { listTeamAccessAudit, searchVerifiedMembers, TeamAccessError, updateMemberRole } from "../lib/team-access";

const router: IRouter = Router();

function requireOwner(_req: Request, res: Response): boolean {
  const user = res.locals.invoiceUser as { role?: string } | undefined;
  if (user?.role === "Owner") return true;
  res.status(403).json({ error: "Only workspace owners can manage team access." });
  return false;
}

router.get("/members", async (req, res): Promise<void> => {
  if (!requireOwner(req, res)) return;
  const params = SearchTeamMembersQueryParams.safeParse(req.query);
  if (!params.success) {
    res.status(400).json({ error: "Enter at least two characters to search verified members." });
    return;
  }
  try {
    res.json(SearchTeamMembersResponse.parse(await searchVerifiedMembers(params.data.query)));
  } catch (error) {
    req.log.error({ err: error }, "Unable to search verified workspace members");
    res.status(503).json({ error: "Verified members could not be loaded. Please try again." });
  }
});

router.get("/audit", (req, res): void => {
  if (!requireOwner(req, res)) return;
  res.json(GetTeamAccessAuditResponse.parse(listTeamAccessAudit()));
});

router.patch("/members/:userId", async (req, res): Promise<void> => {
  if (!requireOwner(req, res)) return;
  const params = UpdateTeamMemberRoleParams.safeParse(req.params);
  const body = UpdateTeamMemberRoleBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Choose Staff, Accountant, Owner, or remove workspace access." });
    return;
  }
  const actor = res.locals.invoiceUser as { id: string; name: string };
  try {
    const member = await updateMemberRole({
      actorId: actor.id,
      actorName: actor.name,
      targetId: params.data.userId,
      role: body.data.role === null ? null : assignedRole(body.data.role) ?? null,
    });
    res.json(UpdateTeamMemberRoleResponse.parse(member));
  } catch (error) {
    if (error instanceof TeamAccessError) {
      res.status(error.status).json({ error: error.message });
      return;
    }
    req.log.error({ err: error, targetId: params.data.userId }, "Unable to update workspace member role");
    res.status(503).json({ error: "Workspace access could not be updated. Please try again." });
  }
});

export default router;
