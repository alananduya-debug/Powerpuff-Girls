import Database from "better-sqlite3";
import { randomUUID } from "node:crypto";
import { copyFile, mkdir, mkdtemp, readFile, rename, rm, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { decryptBytes, encryptBytes } from "./lib/security";
import { readPrivateObject, storePrivateObject } from "./lib/private-file-storage";

const dataDirectory = path.resolve(
  process.env.INVOICE_DATA_DIR ??
    path.join(process.cwd(), path.basename(process.cwd()) === "api-server" ? "data" : "artifacts/api-server/data"),
);
const fileNames = ["invoice-assistant.sqlite", "accounts.sqlite"] as const;
const backupIdPattern = /^\d{8}T\d{6}Z-[0-9a-f]{8}$/i;
const privateBackupKey = (backupId: string, name: string) =>
  `invoice-backups/${backupId}/${name}`;

function requireBackupId(value: string | undefined): string {
  if (!value || !backupIdPattern.test(value)) {
    throw new Error("Provide a backup ID in YYYYMMDDTHHMMSSZ-xxxxxxxx format.");
  }
  return value;
}

async function createBackup(): Promise<void> {
  const backupId = `${new Date().toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "")}-${randomUUID().slice(0, 8)}`;
  const tempDirectory = await mkdtemp(path.join(os.tmpdir(), "billguard-backup-"));
  const { backupDatabases, closeDatabases } = await import("./lib/database");
  try {
    await backupDatabases(tempDirectory);
    for (const name of fileNames) {
      const snapshot = await readFile(path.join(tempDirectory, name));
      await storePrivateObject(privateBackupKey(backupId, `${name}.enc`), encryptBytes(snapshot));
    }
    const manifest = Buffer.from(JSON.stringify({
      version: 1,
      backupId,
      createdAt: new Date().toISOString(),
      databases: fileNames,
      encryption: "AES-256-GCM",
    }));
    await storePrivateObject(privateBackupKey(backupId, "manifest.json"), manifest);
    console.log(`Encrypted invoice database backup saved: ${backupId}`);
  } finally {
    closeDatabases();
    await rm(tempDirectory, { recursive: true, force: true });
  }
}

function verifySnapshot(filePath: string): void {
  const database = new Database(filePath, { readonly: true, fileMustExist: true });
  try {
    const result = database.pragma("integrity_check") as Array<{ integrity_check: string }>;
    if (result.length !== 1 || result[0]?.integrity_check !== "ok") {
      throw new Error(`SQLite integrity check failed for ${path.basename(filePath)}.`);
    }
    const foreignKeyErrors = database.pragma("foreign_key_check") as unknown[];
    if (foreignKeyErrors.length > 0) {
      throw new Error(`SQLite foreign-key check failed for ${path.basename(filePath)}.`);
    }
  } finally {
    database.close();
  }
}

async function restoreBackup(backupId: string): Promise<void> {
  const manifest = JSON.parse(
    (await readPrivateObject(privateBackupKey(backupId, "manifest.json"))).toString("utf8"),
  ) as { version?: number; backupId?: string; databases?: unknown };
  if (manifest.version !== 1 || manifest.backupId !== backupId ||
    JSON.stringify(manifest.databases) !== JSON.stringify(fileNames)) {
    throw new Error("The selected backup manifest is invalid or unsupported.");
  }

  const stagingDirectory = await mkdtemp(path.join(os.tmpdir(), "billguard-restore-"));
  const safetyDirectory = path.join(dataDirectory, `pre-restore-${backupId}`);
  try {
    await mkdir(dataDirectory, { recursive: true });
    await mkdir(safetyDirectory, { recursive: true });
    for (const name of fileNames) {
      const encrypted = await readPrivateObject(privateBackupKey(backupId, `${name}.enc`));
      const snapshotPath = path.join(stagingDirectory, name);
      await writeFile(snapshotPath, decryptBytes(encrypted), { mode: 0o600 });
      verifySnapshot(snapshotPath);
    }

    // Preserve the current local databases before replacing either file.
    for (const name of fileNames) {
      const currentPath = path.join(dataDirectory, name);
      try {
        await copyFile(currentPath, path.join(safetyDirectory, name));
      } catch (error) {
        if (!(typeof error === "object" && error !== null && "code" in error && error.code === "ENOENT")) {
          throw error;
        }
      }
    }
    for (const name of fileNames) {
      await rename(path.join(stagingDirectory, name), path.join(dataDirectory, name));
    }
    console.log(`Restored encrypted invoice database backup: ${backupId}`);
    console.log(`Previous local database copies, when present, are in ${safetyDirectory}`);
  } finally {
    await rm(stagingDirectory, { recursive: true, force: true });
  }
}

const [command, requestedBackupId] = process.argv.slice(2).filter((argument) => argument !== "--");
try {
  if (command === "backup") {
    await createBackup();
  } else if (command === "restore") {
    await restoreBackup(requireBackupId(requestedBackupId));
  } else {
    throw new Error("Use the backup or restore command.");
  }
} catch (error) {
  console.error(error instanceof Error ? error.message : "Database backup operation failed.");
  process.exitCode = 1;
}
