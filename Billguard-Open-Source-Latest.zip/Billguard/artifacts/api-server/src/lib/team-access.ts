import { randomUUID } from "node:crypto";
import Database from "better-sqlite3";
import { clerkClient } from "@clerk/express";
import type { HubUser } from "../../../../server/hub-mock/index";
import { assignedRole } from "./auth";
import { dataDirectory, database } from "./database";

type ClerkUser = Awaited<ReturnType<typeof clerkClient.users.getUser>>;
const roleLockDatabase = new Database(`${dataDirectory}/team-access-lock.sqlite`);
roleLockDatabase.pragma("busy_timeout = 30000");
roleLockDatabase.exec("CREATE TABLE IF NOT EXISTS lock_marker (id INTEGER PRIMARY KEY CHECK (id = 1))");

let pendingLock = Promise.resolve();

/** Serialize access changes locally and across API-server processes. */
function withTeamAccessLock<T>(operation: () => Promise<T>): Promise<T> {
  const result = pendingLock.then(async () => {
    roleLockDatabase.exec("BEGIN IMMEDIATE");
    try {
      const value = await operation();
      roleLockDatabase.exec("COMMIT");
      return value;
    } catch (error) {
      roleLockDatabase.exec("ROLLBACK");
      throw error;
    }
  });
  pendingLock = result.then(() => undefined, () => undefined);
  return result;
}

export class TeamAccessError extends Error {
  constructor(message: string, readonly status: number) {
    super(message);
  }
}

export function verifiedEmail(user: ClerkUser): string | undefined {
  const email = user.emailAddresses.find((item) =>
    item.id === user.primaryEmailAddressId && item.verification?.status === "verified",
  ) ?? user.emailAddresses.find((item) => item.verification?.status === "verified");
  return email?.emailAddress;
}

function memberFromUser(user: ClerkUser) {
  const email = verifiedEmail(user);
  if (!email) return undefined;
  return {
    id: user.id,
    name: user.fullName || user.username || email,
    email,
    role: assignedRole(user.publicMetadata.role) ?? null,
  };
}

export async function searchVerifiedMembers(query: string) {
  const users = await clerkClient.users.getUserList({ query, limit: 50 });
  return users.data.map(memberFromUser).filter((user): user is NonNullable<typeof user> => !!user);
}

async function countOwners(): Promise<number> {
  let offset = 0;
  let count = 0;
  for (;;) {
    const page = await clerkClient.users.getUserList({ limit: 100, offset });
    count += page.data.filter((user) => assignedRole(user.publicMetadata.role) === "Owner").length;
    offset += page.data.length;
    if (!page.data.length || offset >= page.totalCount) return count;
  }
}

type AccessChange = {
  actorId: string;
  actorName: string;
  targetId: string;
  role: HubUser["role"] | null;
};

export async function updateMemberRole({ actorId, actorName, targetId, role }: AccessChange) {
  return withTeamAccessLock(async () => {
    if (actorId === targetId) {
      throw new TeamAccessError("You cannot change your own workspace role.", 403);
    }

    let target: ClerkUser;
    try {
      target = await clerkClient.users.getUser(targetId);
    } catch {
      throw new TeamAccessError("The workspace member could not be found.", 404);
    }
    const email = verifiedEmail(target);
    if (!email) {
      throw new TeamAccessError("Only accounts with a verified email can receive workspace access.", 400);
    }
    const previousRole = assignedRole(target.publicMetadata.role) ?? null;
    if (previousRole === role) {
      const unchanged = memberFromUser(target);
      if (!unchanged) throw new TeamAccessError("The workspace member could not be verified.", 400);
      return unchanged;
    }

    if (previousRole === "Owner" && role !== "Owner" && await countOwners() <= 1) {
      throw new TeamAccessError("The workspace must keep at least one owner. Assign another owner before changing this role.", 409);
    }

    const auditId = randomUUID();
    const now = new Date().toISOString();
    database.prepare(`
      INSERT INTO team_access_audit
        (id, actor_user_id, actor_name, target_user_id, target_email, from_role, to_role, outcome, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?)
    `).run(auditId, actorId, actorName, target.id, email, previousRole, role, now, now);

    try {
      await clerkClient.users.updateUserMetadata(target.id, {
        publicMetadata: { ...target.publicMetadata, role },
      });
    } catch (error) {
      database.prepare("UPDATE team_access_audit SET outcome = 'failed', updated_at = ? WHERE id = ?")
        .run(new Date().toISOString(), auditId);
      throw error;
    }
    database.prepare("UPDATE team_access_audit SET outcome = 'success', updated_at = ? WHERE id = ?")
      .run(new Date().toISOString(), auditId);

    return {
      id: target.id,
      name: target.fullName || target.username || email,
      email,
      role,
    };
  });
}

export function listTeamAccessAudit() {
  return database.prepare(`
    SELECT id, actor_user_id AS actorId, actor_name AS actorName,
      target_user_id AS targetId, target_email AS targetEmail,
      from_role AS fromRole, to_role AS toRole, outcome,
      created_at AS createdAt, updated_at AS updatedAt
    FROM team_access_audit
    ORDER BY created_at DESC
    LIMIT 100
  `).all();
}
