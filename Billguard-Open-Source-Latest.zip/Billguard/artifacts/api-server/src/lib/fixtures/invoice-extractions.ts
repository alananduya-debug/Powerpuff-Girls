// Synthetic data only. These fixtures cross the OCR boundary before validation.
export const syntheticSupplier = {
  id: "bumi-office", name: "Bumi Office Supply Sdn Bhd", tin: "IG10000000010",
};
export const cleanExtraction = {
  supplier_name: syntheticSupplier.name,
  supplier_tin: syntheticSupplier.tin,
  invoice_number: "SYNTHETIC-ONLY",
  date: "2020-01-01",
  currency: "MYR",
  line_items: [{ description: "Synthetic paper", quantity: 1, unit_price: 100, amount: 100 }],
  subtotal: 100, tax_amount: 8, total: 108,
};

export const extractionMistakes: Array<{
  name: string;
  raw: Record<string, unknown>;
  code: string;
  field: string;
  recommendation: RegExp;
}> = [
  { name: "missing date", raw: { date: null }, code: "invalid_date", field: "date", recommendation: /Enter a real calendar date.*original invoice/ },
  { name: "impossible date", raw: { date: "2026-02-30" }, code: "invalid_date", field: "date", recommendation: /YYYY-MM-DD/ },
  { name: "ambiguous date", raw: { date: "01/02/2020" }, code: "invalid_date", field: "date", recommendation: /original invoice/ },
  { name: "future date", raw: { date: "2999-01-01" }, code: "future_date", field: "date", recommendation: /Confirm.*supplier.*correct/ },
  { name: "missing TIN", raw: { supplier_tin: null }, code: "missing_tin", field: "supplierTin", recommendation: /Ask the supplier.*exactly/ },
  { name: "malformed TIN", raw: { supplier_tin: "IG12O00O00010" }, code: "invalid_tin", field: "supplierTin", recommendation: /Check the prefix and digits.*do not guess/ },
  { name: "mismatched TIN", raw: { supplier_tin: "IG10000000011" }, code: "tin_mismatch", field: "supplierTin", recommendation: /correct the TIN or supplier selection.*not government verification/ },
  { name: "repeated-digit TIN", raw: { supplier_tin: "IG99999999999" }, code: "tin_mismatch", field: "supplierTin", recommendation: /Confirm the supplier.*not government verification/ },
  { name: "wrong subtotal", raw: { subtotal: "90.00" }, code: "subtotal_mismatch", field: "subtotal", recommendation: /Compare every item amount.*correct/ },
  { name: "wrong total", raw: { total: "120.00" }, code: "total_mismatch", field: "total", recommendation: /Correct the total or its components/ },
  { name: "uncertain total", raw: { total: "108 or 180" }, code: "missing_total", field: "total", recommendation: /Enter the correct non-negative amount.*original invoice/ },
  { name: "unreadable line amount", raw: { line_items: [{ description: "Synthetic paper", amount: null }] }, code: "missing_line_amount", field: "lineItems", recommendation: /Enter the correct non-negative amount/ },
  { name: "no line items", raw: { line_items: [] }, code: "missing_line_items", field: "lineItems", recommendation: /Re-upload a readable invoice/ },
];
