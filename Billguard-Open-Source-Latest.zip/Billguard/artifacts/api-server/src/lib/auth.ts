import { clerkClient, getAuth } from "@clerk/express";
import type { RequestHandler } from "express";
import type { HubUser } from "../../../../server/hub-mock/index";

export function assignedRole(value: unknown): HubUser["role"] | undefined {
  return value === "Staff" || value === "Accountant" || value === "Owner" ? value : undefined;
}

export const requireAccount: RequestHandler = async (req, res, next) => {
  const { userId } = getAuth(req);
  if (!userId) {
    res.status(401).json({ error: "Sign in to access your invoice workspace." });
    return;
  }
  // Browser role headers, request bodies and editable unsafeMetadata are never
  // trusted. Fetch current admin-controlled metadata so revocations apply now.
  try {
    const user = await clerkClient.users.getUser(userId);
    const role = assignedRole(user.publicMetadata.role);
    if (!role) {
      res.status(403).json({ error: "Your account is awaiting a workspace role. Contact your administrator." });
      return;
    }
    res.locals.invoiceUser = {
      id: user.id,
      name: user.fullName || user.username || "Workspace member",
      role,
    } satisfies HubUser;
    next();
  } catch {
    res.status(503).json({ error: "Your account permissions could not be verified. Please try again." });
  }
};
