import assert from "node:assert/strict";
import test, { after, mock } from "node:test";
import { generateKeyPairSync, sign } from "node:crypto";
import { mkdtempSync, rmSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import type { AddressInfo } from "node:net";

const directory = mkdtempSync(path.join(os.tmpdir(), "billguard-auth-"));
process.env.INVOICE_DATA_DIR = directory;
process.env.PRIVATE_UPLOAD_DIR = path.join(directory, "uploads");
process.env.INVOICE_FILE_STORAGE = "local";
// Match the synthetic JWT issuer so Clerk selects this fixture's cookie jar,
// rather than a different instance's suffixed cookies.
process.env.CLERK_PUBLISHABLE_KEY = `pk_test_${Buffer.from("test.clerk.accounts.dev$").toString("base64")}`;
const { privateKey, publicKey } = generateKeyPairSync("rsa", { modulusLength: 2048 });
process.env.CLERK_JWT_KEY = publicKey.export({ type: "spki", format: "pem" }).toString();
const { clerkClient } = await import("@clerk/express");
const roles: Record<string, unknown> = { user_staff: "Staff", user_accountant: "Accountant", user_owner: "Owner" };
const memberEmails: Record<string, { email: string; verified: boolean; name: string }> = {
  user_staff: { email: "staff@example.test", verified: true, name: "Staff Member" },
  user_accountant: { email: "accountant@example.test", verified: true, name: "Accountant Member" },
  user_owner: { email: "owner@example.test", verified: true, name: "Workspace Owner" },
  user_new: { email: "new.member@example.test", verified: true, name: "New Member" },
  user_unverified: { email: "unverified@example.test", verified: false, name: "Unverified Member" },
};
function clerkUser(id: string) {
  const identity = memberEmails[id];
  const email = identity ? {
    id: `email_${id}`,
    emailAddress: identity.email,
    verification: { status: identity.verified ? "verified" : "unverified" },
  } : undefined;
  return {
    id,
    firstName: identity?.name ?? id,
    fullName: identity?.name ?? id,
    username: null,
    primaryEmailAddressId: email?.id ?? null,
    emailAddresses: email ? [email] : [],
    publicMetadata: { role: roles[id] },
    unsafeMetadata: { role: "Owner" },
  };
}
// Only the remote user lookup is stubbed. Actual Clerk middleware verifies the
// session signature; the production role resolver and every HTTP gate run.
mock.method(clerkClient.users, "getUser", async (id: string) => clerkUser(id));
mock.method(clerkClient.users, "getUserList", async (params: { query?: string; limit?: number; offset?: number }) => {
  const allUsers = Object.keys(memberEmails).map(clerkUser);
  const matching = params.query
    ? allUsers.filter((user) => `${user.fullName} ${memberEmails[user.id]!.email}`.toLowerCase().includes(params.query!.toLowerCase()))
    : allUsers;
  const offset = params.offset ?? 0;
  const data = matching.slice(offset, offset + (params.limit ?? 10));
  return { data, totalCount: matching.length };
});
mock.method(clerkClient.users, "updateUserMetadata", async (id: string, metadata: { publicMetadata: { role: unknown } }) => {
  roles[id] = metadata.publicMetadata.role;
  return clerkUser(id);
});
const service = await import("./invoice-service");
const { database, workspaceContext, closeDatabases } = await import("./database");
await service.initializeInvoiceData();
const demoId = service.getInvoices("Owner")[0]!.id;
let draftId: string;
let reviewId: string;
let approvedId: string;
await workspaceContext.run("account", async () => {
  // Synthetic fixtures are created only in this disposable test account DB.
  draftId = (await service.loadDemoSample("demo-clean-invoice.svg", "user_staff"))!.id;
  reviewId = (await service.loadDemoSample("demo-missing-date.svg", "user_staff"))!.id;
  service.applyInvoiceAction(reviewId, "user_staff", "Staff", "submit");
  approvedId = (await service.loadDemoSample("demo-wrong-tin.svg", "user_staff"))!.id;
  database.prepare("UPDATE invoices SET status = 'Approved' WHERE id = ?").run(approvedId);
});
const { default: app } = await import("../app");
const server = app.listen(0, "127.0.0.1");
await new Promise<void>((resolve) => server.once("listening", resolve));
const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}/api`;
after(async () => {
  await new Promise<void>((resolve) => server.close(() => resolve()));
  closeDatabases(); mock.restoreAll(); rmSync(directory, { recursive: true, force: true });
});
function token(user: string, expirationOffset = 300) {
  const now = Math.floor(Date.now() / 1000);
  const encode = (value: unknown) => Buffer.from(JSON.stringify(value)).toString("base64url");
  const unsigned = `${encode({ alg: "RS256", typ: "JWT", kid: "test-key" })}.${encode({
    iss: "https://test.clerk.accounts.dev", sub: user, sid: "sess_test",
    iat: now, nbf: now - 5, exp: now + expirationOffset,
  })}`;
  return `${unsigned}.${sign("RSA-SHA256", Buffer.from(unsigned), privateKey).toString("base64url")}`;
}
async function request(route: string, user?: string, method = "GET", body?: unknown, extra: Record<string, string> = {}) {
  return fetch(`${base}${route}`, {
    method, headers: { ...(user ? { Authorization: `Bearer ${token(user)}` } : {}),
      ...extra, ...(body ? { "Content-Type": "application/json" } : {}) },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
}
test("unsigned and forged sessions cannot access any account surface", async () => {
  for (const route of ["/users", "/invoices", "/summary", "/activity", "/records", "/settings/ocr", `/invoices/${draftId!}`, `/invoices/${draftId!}/file`, "/records/export"]) {
    assert.equal((await request(route, undefined, "GET", undefined, { "X-Demo-User-Id": "ms-lim" })).status, 401, route);
    assert.equal((await request(route, undefined, "GET", undefined, { Authorization: "Bearer forged" })).status, 401, route);
  }
});
test("real identity ignores demo header, body role and unsafe metadata", async () => {
  const users = await request("/users", "user_staff", "GET", undefined, { "X-Demo-User-Id": "ms-lim", "X-Role": "Owner" });
  assert.equal(users.status, 200);
  assert.deepEqual(await users.json(), [{ id: "user_staff", name: "Staff Member", role: "Staff" }]);
  assert.equal((await request("/settings/ocr", "user_staff", "PUT", { mode: "live", role: "Owner" })).status, 403);
  assert.equal((await request("/invoices", "user_pending")).status, 403);
});
test("browser session cookies are verified and altered or expired sessions are rejected", async () => {
  const session = token("user_staff");
  const browserCookies = `__client_uat=1; __clerk_db_jwt=synthetic-development-browser`;
  const valid = await request("/users", undefined, "GET", undefined, { Cookie: `__session=${session}; ${browserCookies}` });
  assert.equal(valid.status, 200, JSON.stringify(Object.fromEntries(valid.headers)));
  assert.equal(((await valid.json()) as Array<{ role: string }>)[0]!.role, "Staff");
  const parts = session.split(".");
  parts[1] = Buffer.from(JSON.stringify({ sub: "user_owner", exp: Math.floor(Date.now() / 1000) + 300 })).toString("base64url");
  assert.equal((await request("/users", undefined, "GET", undefined, { Cookie: `__session=${parts.join(".")}; ${browserCookies}` })).status, 401);
  assert.equal((await request("/users", undefined, "GET", undefined, { Authorization: `Bearer ${token("user_owner", -300)}` })).status, 401);
});
test("cross-site changes are denied before reaching invoice handlers", async () => {
  assert.equal((await request(`/invoices/${draftId!}/submit`, "user_staff", "POST", undefined, { Origin: "https://attacker.example" })).status, 403);
});
test("all account invoice surfaces enforce the role status matrix", async () => {
  for (const [user, allowed, forbidden] of [
    ["user_staff", draftId!, reviewId!],
    ["user_accountant", reviewId!, draftId!],
  ]) {
    const list = await request("/invoices", user);
    assert.equal(list.status, 200);
    const rows = await list.json() as Array<{ id: string }>;
    assert.ok(rows.some((row) => row.id === allowed));
    assert.ok(!rows.some((row) => row.id === forbidden || row.id === approvedId));
    for (const suffix of ["", "/file", "/activity"]) {
      assert.equal((await request(`/invoices/${allowed}${suffix}`, user)).status, 200, `${user} ${suffix}`);
      assert.equal((await request(`/invoices/${forbidden}${suffix}`, user)).status, 403);
    }
    for (const action of ["submit", "approve", "reject", "send-back", "pass-to-owner", "reveal"]) {
      assert.equal((await request(`/invoices/${forbidden}/${action}`, user, "POST", { role: "Owner", field: "total", comment: "test" })).status, 403);
    }
    assert.equal((await request(`/invoices/${forbidden}`, user, "PATCH", { total: 99, role: "Owner" })).status, 403);
    const activity = await (await request("/activity", user)).json() as Array<{ invoiceId: string }>;
    assert.ok(activity.every((entry) => entry.invoiceId === allowed));
  }
  assert.equal((await request(`/invoices/${approvedId!}`, "user_owner")).status, 200);
});
test("exports stay owner-only and other roles receive no approved records", async () => {
  for (const user of ["user_staff", "user_accountant"]) {
    assert.deepEqual(await (await request("/records", user)).json(), []);
  }
  for (const route of ["/exports/json", "/exports/csv"]) {
    assert.equal((await request(route, "user_staff")).status, 403, route);
    assert.equal((await request(route, "user_accountant")).status, 403, route);
    assert.equal((await request(route, "user_owner")).status, 200, route);
  }
});
test("role revocations apply on the next request without signing out", async () => {
  roles.user_owner = null;
  assert.equal((await request("/invoices", "user_owner")).status, 403);
  roles.user_owner = "Owner";
});
test("team access search and changes are owner-only and only return verified users", async () => {
  const query = encodeURIComponent("new");
  assert.equal((await request(`/team-access/members?query=${query}`, "user_staff")).status, 403);
  assert.equal((await request("/team-access/audit", "user_accountant")).status, 403);
  assert.equal((await request("/team-access/members/user_new", "user_staff", "PATCH", { role: "Owner" })).status, 403);
  const response = await request(`/team-access/members?query=${query}`, "user_owner");
  assert.equal(response.status, 200);
  assert.deepEqual(await response.json(), [{
    id: "user_new", name: "New Member", email: "new.member@example.test", role: null,
  }]);
  assert.equal((await request("/team-access/members?query=x", "user_owner")).status, 400);
});
test("team access rejects self changes and unverified members, and grants take effect immediately", async () => {
  roles.user_owner = "Owner";
  roles.user_new = null;
  assert.equal((await request("/team-access/members/user_owner", "user_owner", "PATCH", { role: "Owner" })).status, 403);
  assert.equal((await request("/team-access/members/user_unverified", "user_owner", "PATCH", { role: "Staff" })).status, 400);
  const grant = await request("/team-access/members/user_new", "user_owner", "PATCH", { role: "Staff" });
  assert.equal(grant.status, 200);
  assert.equal((await grant.json() as { role: string }).role, "Staff");
  assert.equal((await request("/invoices", "user_new")).status, 200);
  const accountant = await request("/team-access/members/user_new", "user_owner", "PATCH", { role: "Accountant" });
  assert.equal(accountant.status, 200);
  assert.equal((await accountant.json() as { role: string }).role, "Accountant");
  assert.equal((await request("/invoices", "user_new")).status, 200);
  const promoteOwner = await request("/team-access/members/user_new", "user_owner", "PATCH", { role: "Owner" });
  assert.equal(promoteOwner.status, 200);
  assert.equal((await promoteOwner.json() as { role: string }).role, "Owner");
  const revoke = await request("/team-access/members/user_new", "user_owner", "PATCH", { role: null });
  assert.equal(revoke.status, 200);
  assert.equal((await revoke.json() as { role: null }).role, null);
  assert.equal((await request("/invoices", "user_new")).status, 403);
  const audit = await request("/team-access/audit", "user_owner");
  assert.equal(audit.status, 200);
  const events = await audit.json() as Array<{ targetEmail: string; fromRole: string | null; toRole: string | null; outcome: string }>;
  assert.equal(events.length, 4);
  assert.deepEqual(events.map((event) => `${event.targetEmail}|${event.fromRole ?? "none"}|${event.toRole ?? "none"}|${event.outcome}`).sort(), [
    "new.member@example.test|Accountant|Owner|success",
    "new.member@example.test|Owner|none|success",
    "new.member@example.test|Staff|Accountant|success",
    "new.member@example.test|none|Staff|success",
  ].sort());
});
test("the trusted bootstrap path cannot revoke the final owner", async () => {
  roles.user_owner = "Owner";
  roles.user_new = null;
  const { TeamAccessError, updateMemberRole } = await import("./team-access");
  await assert.rejects(
    updateMemberRole({
      actorId: "trusted-operator-command",
      actorName: "Trusted operator command",
      targetId: "user_owner",
      role: null,
    }),
    (error: unknown) => error instanceof TeamAccessError && error.status === 409,
  );
  assert.equal(roles.user_owner, "Owner");
});
test("team access management is not exposed through the synthetic demo route", async () => {
  assert.equal((await request("/demo-workspace/team-access/members?query=new", undefined, "GET", undefined, { "X-Demo-User-Id": "ms-lim" })).status, 401);
});
test("demo and accounts cannot retrieve each other's records or use sample loading", async () => {
  assert.equal((await request(`/invoices/${demoId}`, "user_owner")).status, 404);
  assert.equal((await request(`/demo-workspace/invoices/${draftId!}`, undefined, "GET", undefined, { "X-Demo-User-Id": "ms-lim" })).status, 404);
  assert.equal((await request("/demo/load/demo-clean-invoice.svg", "user_owner", "POST")).status, 404);
});
