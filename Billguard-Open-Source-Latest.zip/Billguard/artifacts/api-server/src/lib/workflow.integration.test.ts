import assert from "node:assert/strict";
import test, { after, mock } from "node:test";
import { mkdtempSync, readdirSync, rmSync } from "node:fs";
import { mkdir, rename } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import type { AddressInfo } from "node:net";
import { __private__ } from "../../../../server/ocr/extract.js";
import { cleanExtraction, extractionMistakes, syntheticSupplier } from "./fixtures/invoice-extractions";

// All integration tests use a disposable SQLite database, never the preview data.
const directory = mkdtempSync(path.join(os.tmpdir(), "invoice-tests-"));
process.env.INVOICE_DATA_DIR = directory;
process.env.PRIVATE_UPLOAD_DIR = path.join(directory, "uploads");
process.env.INVOICE_FILE_STORAGE = "local";
// Ordinary workflow tests must never contact a real provider, even when the
// project has working production/test Runpod credentials.
delete process.env.RUNPOD_API_KEY;
const service = await import("./invoice-service");
const { database, workspaceContext, closeDatabases, backupDatabases } = await import("./database");
await service.initializeInvoiceData();
const { default: app } = await import("../app");
const server = app.listen(0, "127.0.0.1");
await new Promise<void>((resolve) => server.once("listening", resolve));
const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}/api/demo-workspace`;
after(async () => {
  await new Promise<void>((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
  closeDatabases();
  rmSync(directory, { recursive: true, force: true });
});

async function request(route: string, user = "siti", method = "GET", body?: unknown) {
  const response = await fetch(`${base}${route}`, {
    method, headers: { "X-Demo-User-Id": user, ...(body === undefined ? {} : { "Content-Type": "application/json" }) },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
  // Raw HTTP payloads are intentionally inspected below, including error envelopes.
  return { status: response.status, headers: response.headers, data: await response.json() as any };
}
async function sample(fileName = "demo-clean-invoice.svg", user = "siti") {
  const result = await request(`/demo/load/${fileName}`, user, "POST");
  assert.equal(result.status, 201, JSON.stringify(result.data));
  return result.data as NonNullable<ReturnType<typeof service.getInvoiceDetail>>;
}

for (const fixture of extractionMistakes.filter((entry) => entry.code !== "missing_line_items")) {
  test(`HTTP approval blocks ${fixture.name} until corrected for both reviewers`, async () => {
    const invoice = await sample();
    const originalLines = invoice.lineItems.map((line, index) => ({
      id: line.id, amount: Number(service.revealInvoiceField(invoice.id, `lineItems.${index}.amount`, "ms-lim")),
    }));
    const parsed = __private__.normalizeExtraction({ ...cleanExtraction, ...fixture.raw }, [syntheticSupplier], "synthetic.png")!;
    const patch: Record<string, unknown> = {};
    const normalizedFields = {
      date: parsed.date ?? "", supplier_tin: parsed.supplier_tin ?? "",
      subtotal: parsed.subtotal, tax_amount: parsed.tax_amount, total: parsed.total,
    };
    for (const [rawField, apiField] of [
      ["date", "date"], ["supplier_tin", "supplierTin"], ["subtotal", "subtotal"],
      ["tax_amount", "tax"], ["total", "total"],
    ] as const) {
      if (rawField in fixture.raw) patch[apiField] = normalizedFields[rawField];
    }
    if ("line_items" in fixture.raw) {
      patch.lineItems = [{ id: invoice.lineItems[0]!.id, amount: parsed.line_items[0]!.amount }];
    }
    const changed = await request(`/invoices/${invoice.id}`, "ms-lim", "PATCH", patch);
    assert.equal(changed.status, 200);
    const warning = changed.data.warnings.find((entry: { code: string }) => entry.code === fixture.code);
    assert.ok(warning);
    assert.equal(warning.severity, "error");
    assert.equal(warning.field, fixture.field);
    assert.match(warning.message, fixture.recommendation);
    assert.equal((await request(`/invoices/${invoice.id}/submit`, "siti", "POST")).status, 200);
    for (const pendingStatus of ["In review", "Awaiting approval"]) {
      if (pendingStatus === "Awaiting approval") {
        assert.equal((await request(`/invoices/${invoice.id}/pass-to-owner`, "mr-tan", "POST", {})).status, 200);
      }
      for (const reviewer of ["mr-tan", "ms-lim"]) {
        const result = await request(`/invoices/${invoice.id}/approve`, reviewer, "POST");
        assert.equal(result.status, 400);
        assert.match(result.data.error, /Correct all blocking invoice issues/);
        assert.equal(service.getInvoiceDetail(invoice.id)!.status, pendingStatus);
      }
    }
    const corrected = await request(`/invoices/${invoice.id}`, "mr-tan", "PATCH", {
      date: cleanExtraction.date, supplierTin: syntheticSupplier.tin, subtotal: 100, tax: 8, total: 108,
      lineItems: originalLines,
    });
    assert.equal(corrected.status, 200);
    assert.deepEqual(corrected.data.warnings, []);
    assert.equal((await request(`/invoices/${invoice.id}/approve`, "ms-lim", "POST")).status, 200);
  });
}

test("approval recomputes blocking issues even if saved warnings are empty", async () => {
  const invoice = await sample("demo-missing-date.svg");
  await request(`/invoices/${invoice.id}/submit`, "siti", "POST");
  database.prepare("UPDATE invoices SET warnings_json = '[]' WHERE id = ?").run(invoice.id);
  const result = await request(`/invoices/${invoice.id}/approve`, "mr-tan", "POST");
  assert.equal(result.status, 400);
  assert.match(result.data.error, /blocking/);
  assert.equal(service.getInvoiceDetail(invoice.id)!.status, "In review");
});

test("a duplicate introduced after submission is rechecked before approval", async () => {
  const first = await sample();
  await request(`/invoices/${first.id}/submit`, "siti", "POST");
  const number = service.revealInvoiceField(first.id, "invoiceNumber", "mr-tan");
  assert.ok(number);
  const second = await sample();
  const changed = await request(`/invoices/${second.id}`, "ms-lim", "PATCH", { invoiceNumber: number });
  assert.equal(changed.status, 200);
  const duplicate = changed.data.warnings.find((entry: { code: string }) => entry.code === "duplicate");
  assert.ok(duplicate);
  assert.match(duplicate.message, /Compare the original records.*Do not invent/);
  // The first invoice's saved warnings predate the duplicate.
  assert.deepEqual(service.getInvoiceDetail(first.id)!.warnings, []);
  for (const reviewer of ["mr-tan", "ms-lim"]) {
    assert.equal((await request(`/invoices/${first.id}/approve`, reviewer, "POST")).status, 400);
  }
  await request(`/invoices/${second.id}/submit`, "siti", "POST");
  assert.equal((await request(`/invoices/${second.id}/approve`, "mr-tan", "POST")).status, 400);
});

test("nonblocking tax warnings remain review advice, not invented liabilities", async () => {
  const invoice = await sample();
  const changed = await request(`/invoices/${invoice.id}`, "ms-lim", "PATCH", { tax: 0, total: 100 });
  assert.deepEqual(changed.data.warnings.map((entry: { code: string; severity: string }) => [entry.code, entry.severity]), [["tax_mismatch", "warning"]]);
  assert.match(changed.data.warnings[0].message, /Ask the accountant.*do not change tax just to match/);
  await request(`/invoices/${invoice.id}/submit`, "siti", "POST");
  assert.equal((await request(`/invoices/${invoice.id}/approve`, "mr-tan", "POST")).status, 200);
});

test("failed account extraction leaves no invoice, activity, or encrypted upload behind", async () => {
  await workspaceContext.run("account", async () => {
    const beforeInvoices = service.getInvoices("Owner");
    const beforeActivity = service.getActivity();
    const beforeFiles = readdirSync(path.join(directory, "uploads")).sort();
    await assert.rejects(
      () => service.uploadInvoice("bumi-clean-invoice.svg", "application/pdf", Buffer.from("invalid synthetic PDF"), "synthetic-user"),
      (error: unknown) => {
        assert.ok(error instanceof Error);
        assert.match(error.message, /couldn't read this invoice.*try again later/);
        assert.equal((error as Error & { status: number }).status, 422);
        return true;
      },
    );
    assert.deepEqual(service.getInvoices("Owner"), beforeInvoices);
    assert.deepEqual(service.getActivity(), beforeActivity);
    assert.deepEqual(readdirSync(path.join(directory, "uploads")).sort(), beforeFiles);
  });
});

test("demo exposes six labelled synthetic cases", async () => {
  const result = await request("/demo/samples");
  assert.equal(result.status, 200);
  assert.equal(result.data.length, 6);
  assert.ok(result.data.some((entry: { label: string }) => entry.label === "Missing date"));
});
test("unknown demo identity is rejected rather than silently becoming staff", async () => {
  assert.equal((await request("/invoices", "unknown-user")).status, 401);
});
test("invoice API responses are not cached", async () => {
  assert.equal((await request("/invoices")).headers.get("cache-control"), "no-store");
});
for (const [user, role] of [["siti", "Staff"], ["mr-tan", "Accountant"], ["ms-lim", "Owner"]]) {
  test(`${role} uploads an exact downloaded sample and submits it`, async () => {
    const bytes = service.getDemoSampleFile("demo-missing-date.svg")!;
    const form = new FormData();
    form.append("file", new Blob([new Uint8Array(bytes)], { type: "image/svg+xml" }), "demo-missing-date.svg");
    const response = await fetch(`${base}/invoices/upload`, { method: "POST", headers: { "X-Demo-User-Id": user! }, body: form });
    assert.equal(response.status, 201, await response.clone().text());
    const { invoice } = await response.json() as { invoice: { id: string } };
    const submitted = role === "Accountant"
      ? await request(`/invoices/${invoice.id}`, user!)
      : await request(`/invoices/${invoice.id}/submit`, user!, "POST");
    assert.equal(submitted.status, 200);
    assert.equal(submitted.data.status, "In review");
    assert.ok(submitted.data.warnings.some((warning: { code: string }) => warning.code === "invalid_date"));
  });
}
test("owner fixes wrong TIN and accountant can approve directly", async () => {
  const invoice = await sample("demo-wrong-tin.svg");
  assert.ok(invoice.warnings.some((warning) => warning.code === "tin_mismatch"));
  await request(`/invoices/${invoice.id}/submit`, "siti", "POST");
  assert.equal((await request(`/invoices/${invoice.id}/approve`, "mr-tan", "POST")).status, 400);
  const corrected = await request(`/invoices/${invoice.id}`, "ms-lim", "PATCH", { supplierTin: "IG10000000010" });
  assert.equal(corrected.status, 200);
  assert.equal(corrected.data.warnings.length, 0);
  const approved = await request(`/invoices/${invoice.id}/approve`, "mr-tan", "POST");
  assert.equal(approved.status, 200);
  assert.equal(approved.data.status, "Approved");
});
test("recalculating totals both removes fixed warnings and finds new errors", async () => {
  const invoice = await sample("demo-wrong-total.svg");
  const corrected = await request(`/invoices/${invoice.id}`, "ms-lim", "PATCH", { total: 108 });
  assert.equal(corrected.data.warnings.length, 0);
  assert.equal(corrected.data.status, "Draft");
  const broken = await request(`/invoices/${invoice.id}`, "ms-lim", "PATCH", { subtotal: 90 });
  assert.deepEqual(broken.data.warnings.filter((warning: { severity: string }) => warning.severity === "error").map((warning: { code: string }) => warning.code).sort(),
    ["subtotal_mismatch", "total_mismatch"]);
});
test("blank date corrections create a new error rather than being ignored", async () => {
  const invoice = await sample();
  const result = await request(`/invoices/${invoice.id}`, "ms-lim", "PATCH", { date: "" });
  assert.equal(result.status, 200);
  assert.ok(result.data.warnings.some((warning: { code: string }) => warning.code === "invalid_date"));
});
test("cleared numeric fields stay missing, not silently zero or unchanged", async () => {
  const invoice = await sample();
  const result = await request(`/invoices/${invoice.id}`, "ms-lim", "PATCH", { total: null });
  assert.equal(result.status, 200);
  assert.ok(result.data.warnings.some((warning: { code: string }) => warning.code === "missing_total"));
});
test("cleared line amounts are revalidated", async () => {
  const invoice = await sample();
  await request(`/invoices/${invoice.id}/submit`, "siti", "POST");
  const result = await request(`/invoices/${invoice.id}`, "mr-tan", "PATCH", { lineItems: [{ id: invoice.lineItems[0]!.id, amount: null }] });
  assert.equal(result.status, 200);
  assert.ok(result.data.warnings.some((warning: { code: string }) => warning.code === "missing_line_amount"));
});
test("staff cannot alter unflagged fields", async () => {
  const invoice = await sample();
  assert.equal((await request(`/invoices/${invoice.id}`, "siti", "PATCH", { total: 10 })).status, 403);
});
test("staff can correct a flagged field before submission", async () => {
  const invoice = await sample("demo-missing-tin.svg");
  const result = await request(`/invoices/${invoice.id}`, "siti", "PATCH", { supplierTin: "IG10000000010" });
  assert.equal(result.status, 200);
  assert.equal(result.data.warnings.length, 0);
});
test("an invalid line item rolls back all corrections", async () => {
  const invoice = await sample();
  const description = service.revealInvoiceField(invoice.id, "lineItems.0.description", "ms-lim");
  await request(`/invoices/${invoice.id}/submit`, "siti", "POST");
  const result = await request(`/invoices/${invoice.id}`, "mr-tan", "PATCH", {
    invoiceNumber: "PARTIAL-UPDATE", lineItems: [
      { id: invoice.lineItems[0]!.id, description: "Must roll back" },
      { id: "not-a-real-line", amount: 99 },
    ],
  });
  assert.equal(result.status, 400);
  const stored = service.getInvoiceDetail(invoice.id)!;
  assert.equal(stored.invoiceNumberMasked, invoice.invoiceNumberMasked);
  assert.equal(service.revealInvoiceField(invoice.id, "lineItems.0.description", "mr-tan"), description);
});
test("accountants cannot dismiss blocking warnings", async () => {
  const invoice = await sample("demo-missing-tin.svg");
  await request(`/invoices/${invoice.id}/submit`, "siti", "POST");
  assert.equal((await request(`/invoices/${invoice.id}`, "mr-tan", "PATCH", { reviewedWarningCodes: ["missing_tin"] })).status, 400);
  assert.ok(service.getInvoiceDetail(invoice.id)!.warnings.some((warning) => warning.code === "missing_tin" && warning.severity === "error"));
});
test("owner cannot approve their own submitted invoice", async () => {
  const invoice = await sample("demo-clean-invoice.svg", "ms-lim");
  await request(`/invoices/${invoice.id}/submit`, "ms-lim", "POST");
  const result = await request(`/invoices/${invoice.id}/approve`, "ms-lim", "POST");
  assert.equal(result.status, 403);
  assert.match(result.data.error, /other reviewer/);
});
test("approved invoices cannot be edited or re-submitted", async () => {
  const invoice = await sample();
  await request(`/invoices/${invoice.id}/submit`, "siti", "POST");
  assert.equal((await request(`/invoices/${invoice.id}/approve`, "ms-lim", "POST")).status, 200);
  assert.equal((await request(`/invoices/${invoice.id}`, "mr-tan", "PATCH", { total: 1 })).status, 403);
  assert.equal((await request(`/invoices/${invoice.id}/submit`, "siti", "POST")).status, 403);
  assert.equal((await request(`/invoices/${invoice.id}`, "ms-lim", "PATCH", { total: 1 })).status, 409);
});
test("send back requires a reason and supports correction then resubmission", async () => {
  const invoice = await sample("demo-missing-date.svg");
  await request(`/invoices/${invoice.id}/submit`, "siti", "POST");
  assert.equal((await request(`/invoices/${invoice.id}/send-back`, "ms-lim", "POST", { comment: " " })).status, 400);
  const returned = await request(`/invoices/${invoice.id}/send-back`, "ms-lim", "POST", { comment: "Confirm the issue date" });
  assert.equal(returned.data.status, "Needs fixes");
  assert.equal(returned.data.comment, "Confirm the issue date");
  assert.equal((await request(`/invoices/${invoice.id}`, "siti", "PATCH", { date: "2020-01-01" })).status, 200);
  assert.equal((await request(`/invoices/${invoice.id}/submit`, "siti", "POST")).status, 200);
  assert.equal((await request(`/invoices/${invoice.id}/approve`, "mr-tan", "POST")).status, 200);
});
test("supplier changes do not require retyping the protected invoice number", async () => {
  const invoice = await sample();
  await request(`/invoices/${invoice.id}/submit`, "siti", "POST");
  const result = await request(`/invoices/${invoice.id}`, "mr-tan", "PATCH", { supplierId: "sinar-print" });
  assert.equal(result.status, 200);
  assert.equal(result.data.supplier, "Sinar Printworks");
  assert.ok(result.data.warnings.some((warning: { code: string }) => warning.code === "tin_mismatch"));
});
test("rejecting a duplicate preserves the reason and locks the record", async () => {
  const invoice = await sample("demo-duplicate.svg");
  assert.ok(invoice.warnings.some((warning) => warning.code === "duplicate"));
  await request(`/invoices/${invoice.id}/submit`, "siti", "POST");
  const result = await request(`/invoices/${invoice.id}/reject`, "mr-tan", "POST", { comment: "Already recorded" });
  assert.equal(result.status, 200);
  assert.equal(result.data.status, "Rejected");
  assert.equal((await request(`/invoices/${invoice.id}`, "ms-lim", "PATCH", { total: 108 })).status, 409);
});
test("staff cannot reveal protected values or approve", async () => {
  const invoice = await sample();
  assert.equal((await request(`/invoices/${invoice.id}/reveal`, "siti", "POST", { field: "supplierTin" })).status, 403);
  await request(`/invoices/${invoice.id}/submit`, "siti", "POST");
  assert.equal((await request(`/invoices/${invoice.id}/approve`, "siti", "POST")).status, 403);
});
test("masked invoice responses never return full sensitive values", async () => {
  const invoice = await sample();
  const result = await request(`/invoices/${invoice.id}`);
  const serialized = JSON.stringify(result.data);
  assert.equal(serialized.includes("IG10000000010"), false);
  assert.equal(result.data.totalMasked, "••••");
});
test("cached extraction cannot be spoofed by filename", async () => {
  await assert.rejects(() => service.uploadInvoice("demo-clean-invoice.svg", "image/svg+xml", Buffer.from("<svg />"), "siti"), /exact downloaded/);
});
test("authorized invoice file reads return not found when its encrypted file is missing", async () => {
  const invoice = await sample();
  const row = database.prepare("SELECT private_file_path FROM invoices WHERE id = ?").get(invoice.id) as {
    private_file_path: string;
  };
  const fileResponse = await fetch(`${base}/invoices/${invoice.id}/file`, {
    headers: { "X-Demo-User-Id": "ms-lim" },
  });
  assert.equal(fileResponse.status, 200);
  assert.match(Buffer.from(await fileResponse.arrayBuffer()).toString("utf8"), /^<svg\b/);
  await rmSync(row.private_file_path, { force: true });
  const missingResponse = await fetch(`${base}/invoices/${invoice.id}/file`, {
    headers: { "X-Demo-User-Id": "ms-lim" },
  });
  assert.equal(missingResponse.status, 404);
});
test("startup migration moves legacy local invoice files into the new private layout", async () => {
  const invoice = await sample();
  const original = database.prepare("SELECT private_file_path FROM invoices WHERE id = ?").get(invoice.id) as {
    private_file_path: string;
  };
  const legacyPath = path.join(directory, "legacy", `${invoice.id}.enc`);
  await mkdir(path.dirname(legacyPath), { recursive: true });
  await rename(original.private_file_path, legacyPath);
  database.prepare("UPDATE invoices SET private_file_path = ? WHERE id = ?").run(legacyPath, invoice.id);

  await service.migrateLegacyInvoiceFilesToPrivateStorage();
  const migrated = database.prepare("SELECT private_file_path FROM invoices WHERE id = ?").get(invoice.id) as {
    private_file_path: string;
  };
  assert.equal(migrated.private_file_path, original.private_file_path);
  const file = await service.getAuthorizedInvoiceFile(invoice.id, "owner", "Owner");
  assert.ok(file?.bytes.byteLength);
});
test("SQLite backups preserve both separated databases as valid snapshots", async () => {
  const backupDirectory = path.join(directory, "verified-backup");
  await backupDatabases(backupDirectory);
  for (const name of ["invoice-assistant.sqlite", "accounts.sqlite"]) {
    const Database = (await import("better-sqlite3")).default;
    const snapshot = new Database(path.join(backupDirectory, name), { readonly: true, fileMustExist: true });
    assert.deepEqual(snapshot.pragma("integrity_check"), [{ integrity_check: "ok" }]);
    assert.equal(snapshot.prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'invoices'").get() !== undefined, true);
    snapshot.close();
  }
});
test("unconfigured Runpod cannot enable live reading or silently fall back on uploads", async () => {
  const before = service.getInvoices("Owner").length;
  assert.equal((await request("/settings/ocr", "ms-lim", "PUT", { mode: "live" })).status, 503);
  database.prepare("INSERT OR REPLACE INTO app_settings (key, value) VALUES ('ocr_mode', 'live')").run();
  const previousMode = process.env.OCR_MODE;
  process.env.OCR_MODE = "live";
  try {
    assert.equal((await request("/settings/ocr", "ms-lim")).data.mode, "live");
    for (const [fileName, mimeType, bytes] of [
      ["arbitrary.pdf", "application/pdf", Buffer.from("%PDF-1.7\nSynthetic arbitrary invoice, not a fixture")],
      ["demo-clean-invoice.svg", "application/pdf", Buffer.from("%PDF-1.7\nRenaming must not grant access")],
      ["arbitrary.png", "image/png", Buffer.from([137, 80, 78, 71, 13, 10, 26, 10, 1, 2, 3])],
    ] as const) {
      const form = new FormData();
      form.append("file", new Blob([new Uint8Array(bytes)], { type: mimeType }), fileName);
      const response = await fetch(`${base}/invoices/upload`, {
        method: "POST", headers: { "X-Demo-User-Id": "ms-lim", "X-Live-AI-Consent": "yes" }, body: form,
      });
      assert.equal(response.status, 503, await response.clone().text());
      assert.match((await response.json() as { error: string }).error, /not configured/);
    }
    assert.equal(service.getInvoices("Owner").length, before);
  } finally {
    if (previousMode === undefined) delete process.env.OCR_MODE;
    else process.env.OCR_MODE = previousMode;
    database.prepare("DELETE FROM app_settings WHERE key = 'ocr_mode'").run();
  }
});
test("unsupported and spoofed upload file types fail explicitly", async () => {
  const form = new FormData();
  form.append("file", new Blob(["not a webp"], { type: "image/webp" }), "fake.webp");
  const response = await fetch(`${base}/invoices/upload`, { method: "POST", headers: { "X-Demo-User-Id": "siti" }, body: form });
  assert.equal(response.status, 415);
});
test("unknown demo samples return 404", async () => assert.equal((await request("/demo/load/not-real.svg", "siti", "POST")).status, 404));
test("records and activity reflect completed decisions", async () => {
  const invoice = await sample();
  await request(`/invoices/${invoice.id}/submit`, "siti", "POST");
  await request(`/invoices/${invoice.id}/approve`, "mr-tan", "POST");
  const records = await request("/records", "ms-lim");
  assert.ok(records.data.some((row: { id: string }) => row.id === invoice.id));
  const activity = await request(`/invoices/${invoice.id}/activity`, "ms-lim");
  assert.ok(activity.data.some((entry: { action: string }) => entry.action === "approved invoice"));
});

const permissions = [
  ["siti", ["Draft", "Needs fixes", "Rejected"]],
  ["mr-tan", ["In review", "Awaiting approval"]],
  ["ms-lim", ["Draft", "Needs fixes", "Rejected", "In review", "Awaiting approval", "Approved"]],
] as const;
for (const [user, allowed] of permissions) {
  for (const status of ["Draft", "Needs fixes", "Rejected", "In review", "Awaiting approval", "Approved"]) {
    test(`${user} status access: ${status}, including direct URLs and writes`, async () => {
      const invoice = await sample();
      database.prepare("UPDATE invoices SET status = ? WHERE id = ?").run(status, invoice.id);
      const permitted = (allowed as readonly string[]).includes(status);
      const listed = await request("/invoices", user);
      assert.equal(listed.data.some((row: { id: string }) => row.id === invoice.id), permitted);
      for (const suffix of ["", "/file", "/activity"]) {
        const response = await fetch(`${base}/invoices/${invoice.id}${suffix}`, { headers: { "X-Demo-User-Id": user } });
        assert.equal(response.status, permitted ? 200 : 403, `${status} ${suffix}`);
        await response.arrayBuffer();
      }
      const revealed = await request(`/invoices/${invoice.id}/reveal`, user, "POST", { field: "supplierTin" });
      assert.equal(revealed.status, permitted && user !== "siti" ? 200 : 403);
      if (!permitted) {
        assert.equal((await request(`/invoices/${invoice.id}`, user, "PATCH", { date: "2020-01-01" })).status, 403);
        for (const action of ["submit", "approve", "reject", "send-back", "pass-to-owner"]) {
          assert.equal((await request(`/invoices/${invoice.id}/${action}`, user, "POST", { comment: "Unauthorized test" })).status, 403);
        }
      }
    });
  }
  test(`${user} counts, records, exports and timeline cannot leak hidden invoices`, async () => {
    const invoices = (await request("/invoices", user)).data as Array<{ id: string; status: string }>;
    const ids = new Set(invoices.map((row) => row.id));
    const summary = (await request("/summary", user)).data;
    assert.equal(summary.total, invoices.length);
    for (const [field, status] of [["inReview", "In review"], ["awaitingApproval", "Awaiting approval"], ["approved", "Approved"], ["needsFixes", "Needs fixes"], ["readyRecords", "Approved"]]) {
      assert.equal(summary[field!], invoices.filter((row) => row.status === status).length);
    }
    const activity = (await request("/activity", user)).data as Array<{ invoiceId: string | null }>;
    assert.ok(activity.every((entry) => user === "ms-lim" || (entry.invoiceId !== null && ids.has(entry.invoiceId))));
    const records = (await request("/records", user)).data as Array<{ id: string; status: string }>;
    assert.ok(records.every((row) => ids.has(row.id) && row.status === "Approved"));
    if (user !== "ms-lim") {
      assert.equal(records.length, 0);
      assert.equal((await request("/exports/json", user)).status, 403);
    }
  });
}
test("submission, return, approval and rejection immediately transfer role visibility", async () => {
  const invoice = await sample("demo-missing-date.svg");
  assert.equal((await request(`/invoices/${invoice.id}`, "mr-tan")).status, 403);
  assert.equal((await request(`/invoices/${invoice.id}/submit`, "siti", "POST")).status, 200);
  assert.equal((await request(`/invoices/${invoice.id}`, "siti")).status, 403);
  assert.equal((await request(`/invoices/${invoice.id}`, "mr-tan")).status, 200);
  assert.equal((await request(`/invoices/${invoice.id}/send-back`, "mr-tan", "POST", { comment: "Please add the date" })).status, 200);
  assert.equal((await request(`/invoices/${invoice.id}`, "mr-tan")).status, 403);
  assert.equal((await request(`/invoices/${invoice.id}`, "siti", "PATCH", { date: "2020-01-01" })).status, 200);
  await request(`/invoices/${invoice.id}/submit`, "siti", "POST");
  assert.equal((await request(`/invoices/${invoice.id}/approve`, "mr-tan", "POST")).status, 200);
  for (const user of ["siti", "mr-tan"]) assert.equal((await request(`/invoices/${invoice.id}`, user)).status, 403);
  assert.equal((await request(`/invoices/${invoice.id}`, "ms-lim")).status, 200);
  const rejected = await sample();
  await request(`/invoices/${rejected.id}/submit`, "siti", "POST");
  await request(`/invoices/${rejected.id}/reject`, "mr-tan", "POST", { comment: "Not payable" });
  assert.equal((await request(`/invoices/${rejected.id}`, "siti")).status, 200);
  assert.equal((await request(`/invoices/${rejected.id}`, "mr-tan")).status, 403);
});
test("accountant sample loads go directly to review without granting draft access", async () => {
  const invoice = await sample("demo-missing-tin.svg", "mr-tan");
  assert.equal(invoice.status, "In review");
  assert.equal((await request(`/invoices/${invoice.id}`, "mr-tan")).status, 200);
  assert.equal((await request(`/invoices/${invoice.id}`, "siti")).status, 403);
});
