const visibleStatuses: Record<string, readonly string[]> = {
  Staff: ["Draft", "Needs fixes", "Rejected"],
  Accountant: ["In review", "Awaiting approval"],
};

/** Status access is shared by list, count, audit and document endpoints. */
export function canAccessInvoice(role: string, status: string): boolean {
  return role === "Owner" || (visibleStatuses[role]?.includes(status) ?? false);
}
