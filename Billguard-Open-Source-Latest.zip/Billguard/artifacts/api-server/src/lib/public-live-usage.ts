import { database } from "./database";
import { InvoiceError } from "../../../../server/rules/workflow";

let activeReads = 0;

/** Counts attempted public reads, including failed provider requests. */
export function reservePublicLiveRead(): () => void {
  if (activeReads >= 2) throw new InvoiceError("Live AI is busy. Try again in a moment.", 429);
  const now = new Date().toISOString();
  const configured = Number(process.env.RUNPOD_DAILY_LIMIT ?? 30);
  const dailyLimit = Number.isInteger(configured) && configured >= 0 ? Math.min(configured, 500) : 30;
  database.transaction(() => {
    for (const [key, limit] of [
      [`live_reads_day_${now.slice(0, 10)}`, dailyLimit],
      ["live_reads_minute", 5],
    ] as const) {
      const row = database.prepare("SELECT value FROM app_settings WHERE key = ?").get(key) as { value: string } | undefined;
      const saved = row ? JSON.parse(row.value) as { minute: string; count: number } : undefined;
      const minute = now.slice(0, 16);
      const count = key === "live_reads_minute" && saved?.minute !== minute ? 0 : saved?.count ?? 0;
      if (count >= limit) throw new InvoiceError(key === "live_reads_minute"
        ? "Public Live AI limit reached. Try again next minute."
        : "The public Live AI daily test limit has been reached.", 429);
      database.prepare("INSERT INTO app_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value")
        .run(key, JSON.stringify({ minute, count: count + 1 }));
    }
  })();
  activeReads += 1;
  let released = false;
  return () => { if (!released) { released = true; activeReads -= 1; } };
}
