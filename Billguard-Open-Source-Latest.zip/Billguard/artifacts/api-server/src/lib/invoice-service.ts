import { randomUUID } from "node:crypto";
import path from "node:path";
import { listSuppliers, listUsers, getSupplier, publishEvent } from "../../../../server/hub-mock/index";
import { logger } from "./logger";
import { extractInvoice, type OcrMode } from "../../../../server/ocr/extract.js";
import { getRunpodConfiguration } from "../../../../server/ocr/runpod.js";
import { reservePublicLiveRead } from "./public-live-usage";
import extractions from "../../../../server/data/extractions.json" with { type: "json" };
import { evaluateInvoiceRules, type RuleWarning } from "../../../../server/rules/engine";
import { InvoiceError, nextInvoiceStatus } from "../../../../server/rules/workflow";
import { database, isAccountWorkspace, workspaceContext } from "./database";
import { canAccessInvoice } from "./invoice-access";
import {
  isPrivateObjectReference,
  MissingPrivateFileError,
  readInvoiceFile,
  removeInvoiceFile,
  storeInvoiceFile,
} from "./private-file-storage";
import {
  createBlindIndex,
  decryptBytes,
  decryptValue,
  encryptBytes,
  encryptValue,
  maskLastFour,
} from "./security";

export type InvoiceStatus =
  | "Draft"
  | "Needs fixes"
  | "In review"
  | "Awaiting approval"
  | "Approved"
  | "Rejected";

export type Extraction = (typeof extractions)[number];

type InvoiceRow = {
  id: string;
  supplier_id: string;
  supplier_name: string;
  supplier_tin_cipher: string;
  supplier_tin_masked: string;
  invoice_number_cipher: string;
  invoice_number_masked: string;
  blind_index: string;
  invoice_date: string;
  currency: string;
  subtotal_cipher: string;
  tax_cipher: string;
  total_cipher: string;
  status: InvoiceStatus;
  warnings_json: string;
  comment: string | null;
  submitted_by_user_id: string | null;
  created_by_user_id: string;
  file_name: string;
  mime_type: string;
  private_file_path: string;
  confidence_json: string;
  created_at: string;
  updated_at: string;
};

type LineItemRow = {
  id: string;
  description_cipher: string;
  amount_cipher: string;
  confidence: "High" | "Medium" | "Low";
  position: number;
};

type ActivityRow = {
  id: string;
  invoice_id: string | null;
  actor_user_id: string;
  action: string;
  field: string | null;
  created_at: string;
};

type InvoiceListItem = {
  id: string;
  supplier: string;
  supplierTinMasked: string;
  invoiceNumberMasked: string;
  date: string;
  currency: string;
  totalMasked: string;
  status: InvoiceStatus;
  warnings: number;
  fileName: string;
};

type InvoiceDetail = Omit<InvoiceListItem, "warnings"> & {
  subtotalMasked: string;
  taxMasked: string;
  lineItems: Array<{
    id: string;
    descriptionMasked: string;
    amountMasked: string;
    confidence: "High" | "Medium" | "Low";
  }>;
  warnings: RuleWarning[];
  comment: string | null;
  submittedBy: string | null;
  mimeType: string;
};

type PersistExtraction = {
  fileName: string;
  supplierId: string;
  supplierName: string;
  supplierTin: string | null;
  invoiceNumber: string | null;
  date: string;
  currency: string;
  lineItems: Array<{
    description: string | null;
    amount: number | null;
    confidence: "High" | "Medium" | "Low";
  }>;
  subtotal: number | null;
  tax: number | null;
  total: number | null;
  status?: InvoiceStatus;
  confidence: Record<string, unknown>;
};

const seedRows = extractions as Array<{
  fileName: string;
  supplierId: string;
  supplierTin: string;
  invoiceNumber: string;
  date: string;
  currency: string;
  lineItems: Array<{
    description: string;
    amount: number;
    confidence: "High" | "Medium" | "Low";
  }>;
  subtotal: number;
  tax: number;
  total: number;
  status: InvoiceStatus;
  confidence: Record<string, "High" | "Medium" | "Low">;
}>;

function timestamp(): string {
  return new Date().toISOString();
}

function listBlindIndexes(excludeInvoiceId?: string): Set<string> {
  const rows = database
    .prepare("SELECT id, blind_index FROM invoices")
    .all() as Array<{ id: string; blind_index: string }>;
  return new Set(
    rows
      .filter((row) => row.id !== excludeInvoiceId)
      .map((row) => row.blind_index),
  );
}

function addActivity(
  invoiceId: string | null,
  actorUserId: string,
  action: string,
  field: string | null = null,
): void {
  database
    .prepare(
      `INSERT INTO activity_entries (id, invoice_id, actor_user_id, action, field, created_at)
       VALUES (?, ?, ?, ?, ?, ?)`,
    )
    .run(randomUUID(), invoiceId, actorUserId, action, field, timestamp());
}

function getInvoiceRow(invoiceId: string): InvoiceRow | undefined {
  return database
    .prepare("SELECT * FROM invoices WHERE id = ?")
    .get(invoiceId) as InvoiceRow | undefined;
}

function getLineItemRows(invoiceId: string): LineItemRow[] {
  return database
    .prepare(
      "SELECT id, description_cipher, amount_cipher, confidence, position FROM line_items WHERE invoice_id = ? ORDER BY position",
    )
    .all(invoiceId) as LineItemRow[];
}

function warningsFor(row: InvoiceRow): RuleWarning[] {
  return JSON.parse(row.warnings_json) as RuleWarning[];
}

function getStatusFromWarnings(warnings: RuleWarning[]): InvoiceStatus {
  return warnings.some((warning) => warning.severity === "error")
    ? "Needs fixes"
    : "Draft";
}

function toListItem(row: InvoiceRow): InvoiceListItem {
  return {
    id: row.id,
    supplier: row.supplier_name,
    supplierTinMasked: row.supplier_tin_masked,
    invoiceNumberMasked: row.invoice_number_masked,
    date: row.invoice_date,
    currency: row.currency,
    totalMasked: "••••",
    status: row.status,
    warnings: warningsFor(row).filter((warning) => warning.severity === "error")
      .length,
    fileName: row.file_name,
  };
}

function toDetail(row: InvoiceRow): InvoiceDetail {
  return {
    ...toListItem(row),
    subtotalMasked: "••••",
    taxMasked: "••••",
    lineItems: getLineItemRows(row.id).map((line) => ({
      id: line.id,
      descriptionMasked: "••••",
      amountMasked: "••••",
      confidence: line.confidence,
    })),
    warnings: warningsFor(row),
    comment: row.comment,
    submittedBy: row.submitted_by_user_id,
    mimeType: row.mime_type,
  };
}

function renderSyntheticInvoiceSvg(extraction: (typeof seedRows)[number]): Buffer {
  const supplier = getSupplier(extraction.supplierId);
  if (!supplier) {
    throw new Error("Synthetic supplier is not available.");
  }
  const escape = (value: string) =>
    value
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;");
  const lines = extraction.lineItems
    .map(
      (item, index) =>
        `<text x="64" y="${294 + index * 34}" class="small">${escape(item.description)}</text><text x="720" y="${294 + index * 34}" class="small" text-anchor="end">${extraction.currency} ${item.amount.toFixed(2)}</text>`,
    )
    .join("");
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="820" height="640" viewBox="0 0 820 640"><rect width="820" height="640" fill="#fbfaf6"/><rect x="32" y="32" width="756" height="576" rx="6" fill="white" stroke="#d8d7cf"/><text x="64" y="94" class="brand">${escape(supplier.name)}</text><text x="64" y="128" class="small">TAX INVOICE</text><text x="64" y="190" class="small">Invoice no.</text><text x="210" y="190" class="body">${escape(extraction.invoiceNumber)}</text><text x="64" y="224" class="small">Date</text><text x="210" y="224" class="body">${escape(extraction.date)}</text><line x1="64" y1="250" x2="756" y2="250" stroke="#d8d7cf"/><text x="64" y="276" class="small">Description</text><text x="720" y="276" class="small" text-anchor="end">Amount</text>${lines}<line x1="64" y1="390" x2="756" y2="390" stroke="#d8d7cf"/><text x="580" y="432" class="small">Subtotal</text><text x="756" y="432" class="body" text-anchor="end">${extraction.currency} ${extraction.subtotal.toFixed(2)}</text><text x="580" y="464" class="small">Tax</text><text x="756" y="464" class="body" text-anchor="end">${extraction.currency} ${extraction.tax.toFixed(2)}</text><text x="580" y="506" class="brand">Total</text><text x="756" y="506" class="brand" text-anchor="end">${extraction.currency} ${extraction.total.toFixed(2)}</text><text x="64" y="560" class="small">Synthetic sample for Invoice Assistant</text><style>.brand{font:600 22px Arial,sans-serif;fill:#1d3a34}.body{font:16px Arial,sans-serif;fill:#232723}.small{font:13px Arial,sans-serif;fill:#6e736c}</style></svg>`;
  const withTin = svg.replace('<text x="64" y="190"', `<text x="64" y="154" class="small">Supplier TIN: ${escape(extraction.supplierTin || "Not provided")}</text><text x="64" y="190"`);
  return Buffer.from(withTin, "utf8");
}

async function persistInvoice(
  extraction: PersistExtraction,
  fileBuffer: Buffer,
  actorUserId: string,
  mimeType: string,
  seed = false,
  extractionSource: string = "cached",
): Promise<InvoiceRow> {
  const id = randomUUID();
  const now = timestamp();
  const blindIndex = createBlindIndex(
    extraction.supplierId,
    extraction.invoiceNumber ?? "",
  );
  const warnings = evaluateInvoiceRules(
    {
      supplier: extraction.supplierName,
      invoiceNumber: extraction.invoiceNumber ?? "",
      date: extraction.date,
      supplierTin: extraction.supplierTin ?? "",
      expectedSupplierTin: getSupplier(extraction.supplierId)?.tin,
      currency: extraction.currency,
      lineItems: extraction.lineItems.map((line) => ({
        description: line.description ?? "",
        amount: line.amount,
      })),
      subtotal: extraction.subtotal,
      tax: extraction.tax,
      total: extraction.total,
      blindIndex,
    },
    listBlindIndexes(),
  );
  const status = seed
    ? extraction.status ?? "Draft"
    : getStatusFromWarnings(warnings);
  const workspace = isAccountWorkspace() ? "account" : "demo";
  const filePath = await storeInvoiceFile(workspace, id, encryptBytes(fileBuffer));

  try {
    const insertInvoice = database.prepare(`
      INSERT INTO invoices (
        id, supplier_id, supplier_name, supplier_tin_cipher, supplier_tin_masked,
        invoice_number_cipher, invoice_number_masked, blind_index, invoice_date,
        currency, subtotal_cipher, tax_cipher, total_cipher, status, warnings_json,
        comment, submitted_by_user_id, created_by_user_id, file_name, mime_type,
        private_file_path, confidence_json, created_at, updated_at
      ) VALUES (
        @id, @supplier_id, @supplier_name, @supplier_tin_cipher, @supplier_tin_masked,
        @invoice_number_cipher, @invoice_number_masked, @blind_index, @invoice_date,
        @currency, @subtotal_cipher, @tax_cipher, @total_cipher, @status, @warnings_json,
        @comment, @submitted_by_user_id, @created_by_user_id, @file_name, @mime_type,
        @private_file_path, @confidence_json, @created_at, @updated_at
      )
    `);
    const insertLine = database.prepare(`
      INSERT INTO line_items (id, invoice_id, description_cipher, amount_cipher, confidence, position)
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    const save = database.transaction(() => {
      insertInvoice.run({
        id,
        supplier_id: extraction.supplierId,
        supplier_name: extraction.supplierName,
        supplier_tin_cipher: encryptValue(extraction.supplierTin ?? ""),
        supplier_tin_masked: maskLastFour(extraction.supplierTin ?? ""),
        invoice_number_cipher: encryptValue(extraction.invoiceNumber ?? ""),
        invoice_number_masked: maskLastFour(extraction.invoiceNumber ?? ""),
        blind_index: blindIndex,
        invoice_date: extraction.date,
        currency: extraction.currency,
        subtotal_cipher: encryptValue(extraction.subtotal === null ? "" : String(extraction.subtotal)),
        tax_cipher: encryptValue(extraction.tax === null ? "" : String(extraction.tax)),
        total_cipher: encryptValue(extraction.total === null ? "" : String(extraction.total)),
        status,
        warnings_json: JSON.stringify(warnings),
        comment: null,
        submitted_by_user_id: status === "Approved" ? "siti" : null,
        created_by_user_id: actorUserId,
        file_name: path.basename(extraction.fileName),
        mime_type: mimeType,
        private_file_path: filePath,
        confidence_json: JSON.stringify(extraction.confidence),
        created_at: now,
        updated_at: now,
      });
      extraction.lineItems.forEach((line, position) => {
        insertLine.run(
          randomUUID(),
          id,
          encryptValue(line.description ?? ""),
          encryptValue(line.amount === null ? "" : String(line.amount)),
          line.confidence,
          position,
        );
      });
      addActivity(id, actorUserId, `extracted invoice using ${extractionSource}`);
      if (status === "Approved") {
        addActivity(id, "ms-lim", "approved");
      } else if (status === "Awaiting approval") {
        addActivity(id, "mr-tan", "passed invoice to owner");
      }
      publishEvent("invoice.extracted", { invoiceId: id, actorUserId });
      if (status === "Approved") {
        publishEvent("invoice.approved", { invoiceId: id, actorUserId: "ms-lim" });
      }
    });
    save();
  } catch (error) {
    await removeInvoiceFile(filePath).catch(() => undefined);
    throw error;
  }
  const saved = getInvoiceRow(id);
  if (!saved) {
    throw new Error("Invoice could not be stored.");
  }
  return saved;
}

export async function initializeInvoiceData(): Promise<void> {
  if (isAccountWorkspace()) throw new Error("Synthetic seeding is forbidden in account workspaces.");
  const count = database.prepare("SELECT COUNT(*) AS count FROM invoices").get() as {
    count: number;
  };
  if (count.count > 0) {
    return;
  }
  for (const extraction of seedRows) {
    const supplier = getSupplier(extraction.supplierId);
    if (!supplier) {
      throw new Error("A synthetic supplier record is unavailable.");
    }
    await persistInvoice(
      {
        fileName: extraction.fileName,
        supplierId: extraction.supplierId,
        supplierName: supplier.name,
        supplierTin: extraction.supplierTin,
        invoiceNumber: extraction.invoiceNumber,
        date: extraction.date,
        currency: extraction.currency,
        lineItems: extraction.lineItems.map((line) => ({
          description: line.description,
          amount: line.amount,
          confidence: line.confidence,
        })),
        subtotal: extraction.subtotal,
        tax: extraction.tax,
        total: extraction.total,
        status: extraction.status,
        confidence: extraction.confidence,
      },
      renderSyntheticInvoiceSvg(extraction),
      "siti",
      "image/svg+xml",
      true,
      "cached sample",
    );
  }
}

export async function migrateLegacyInvoiceFilesToPrivateStorage(): Promise<void> {
  let migrated = 0;
  for (const workspace of ["demo", "account"] as const) {
    await workspaceContext.run(workspace, async () => {
      const rows = database.prepare(
        "SELECT id, private_file_path FROM invoices",
      ).all() as Array<{ id: string; private_file_path: string }>;
      for (const row of rows) {
        if (isPrivateObjectReference(row.private_file_path)) continue;
        let encryptedBytes: Buffer;
        try {
          encryptedBytes = await readInvoiceFile(row.private_file_path, workspace);
        } catch (error) {
          if (error instanceof MissingPrivateFileError) {
            logger.warn({ workspace, invoiceId: row.id }, "Legacy invoice file is missing during storage migration");
            continue;
          }
          throw error;
        }
        const durableReference = await storeInvoiceFile(workspace, row.id, encryptedBytes);
        database.prepare("UPDATE invoices SET private_file_path = ? WHERE id = ?")
          .run(durableReference, row.id);
        migrated++;
      }
    });
  }
  if (migrated > 0) {
    logger.info({ migrated }, "Migrated legacy invoice files to private storage");
  }
}

export function getUsers() {
  return listUsers();
}

export function getSuppliers() {
  return listSuppliers();
}

export function getOcrSettings(): { mode: OcrMode; liveConfigured: boolean } {
  const saved = database.prepare("SELECT value FROM app_settings WHERE key = 'ocr_mode'").get() as { value: string } | undefined;
  const liveConfigured = isAccountWorkspace()
    ? Boolean(process.env.AI_INTEGRATIONS_OPENAI_BASE_URL && process.env.AI_INTEGRATIONS_OPENAI_API_KEY)
    : Boolean(getRunpodConfiguration());
  return {
    mode: isAccountWorkspace() ? "live" : saved?.value === "live" ? "live" :
      saved?.value === "cached" ? "cached" : liveConfigured ? "live" : "cached",
    liveConfigured,
  };
}

export function setOcrMode(mode: OcrMode, actorUserId: string) {
  if (isAccountWorkspace() && mode !== "live") throw new InvoiceError("Account workspaces require live invoice reading.", 400);
  if (mode === "live" && !getOcrSettings().liveConfigured) {
    throw new InvoiceError("Runpod Live AI is not configured on the server yet.", 503);
  }
  database
    .prepare(
      `INSERT INTO app_settings (key, value) VALUES ('ocr_mode', ?)
       ON CONFLICT(key) DO UPDATE SET value = excluded.value`,
    )
    .run(mode);
  addActivity(null, actorUserId, "changed OCR mode", mode);
  return getOcrSettings();
}

export function getInvoices(role = "Owner"): InvoiceListItem[] {
  const rows = database
    .prepare("SELECT * FROM invoices ORDER BY created_at DESC")
    .all() as InvoiceRow[];
  return rows.filter((row) => canAccessInvoice(role, row.status)).map(toListItem);
}

export function getApprovedRecords(role = "Owner"): InvoiceListItem[] {
  const rows = database
    .prepare("SELECT * FROM invoices WHERE status = 'Approved' ORDER BY invoice_date DESC")
    .all() as InvoiceRow[];
  return rows.filter((row) => canAccessInvoice(role, row.status)).map(toListItem);
}

export function getInvoiceDetail(invoiceId: string): InvoiceDetail | undefined {
  const row = getInvoiceRow(invoiceId);
  return row ? toDetail(row) : undefined;
}

export function getSummary(role: string): {
  total: number;
  inReview: number;
  awaitingApproval: number;
  approved: number;
  needsFixes: number;
  readyRecords: number;
  pendingForRole: number;
} {
  const allRows = database
    .prepare("SELECT status FROM invoices")
    .all() as Array<{ status: InvoiceStatus }>;
  const rows = allRows.filter((row) => canAccessInvoice(role, row.status));
  return {
    total: rows.length,
    inReview: rows.filter((row) => row.status === "In review").length,
    awaitingApproval: rows.filter((row) => row.status === "Awaiting approval").length,
    approved: rows.filter((row) => row.status === "Approved").length,
    needsFixes: rows.filter((row) => row.status === "Needs fixes").length,
    readyRecords: rows.filter((row) => row.status === "Approved").length,
    pendingForRole:
      role === "Accountant" || role === "Owner"
        ? rows.filter((row) => row.status === "In review" || row.status === "Awaiting approval").length
          : rows.filter((row) => row.status === "Needs fixes" || row.status === "Draft")
              .length,
  };
}

export async function uploadInvoice(
  fileName: string,
  mimeType: string,
  fileBuffer: Buffer,
  actorUserId: string,
): Promise<{
  invoice: InvoiceListItem;
  source: "live" | "cached" | "cached-fallback";
}> {
  const settings = getOcrSettings();
  if (!isAccountWorkspace() && settings.mode === "cached") {
    const sample = getDemoSampleFile(fileName) ?? await readDemoExtractionFile(fileName);
    if (!sample || !sample.equals(fileBuffer)) {
      throw new InvoiceError("This demo reads only the exact downloaded synthetic sample files.", 422);
    }
    const demo = await loadDemoSample(fileName, actorUserId, false);
    if (demo) return { invoice: toListItem(getInvoiceRow(demo.id)!), source: "cached" };
  }
  if (settings.mode === "live" && !settings.liveConfigured) {
    throw new InvoiceError("Live AI is not configured. Ask the app owner to connect Runpod.", 503);
  }
  const suppliers = listSuppliers();
  const release = !isAccountWorkspace() && settings.mode === "live" ? reservePublicLiveRead() : () => {};
  const result = await (async () => {
    try {
      return await extractInvoice(
        { fileName, mimeType, buffer: fileBuffer },
        { mode: settings.mode, knownSuppliers: suppliers, provider: isAccountWorkspace() ? "replit" : "runpod" },
      );
    } finally { release(); }
  })();
  if ("error" in result) {
    throw new InvoiceError(!isAccountWorkspace() && settings.mode === "live"
      ? result.error
      : "We couldn't read this invoice. Check the file or try again later.", 422);
  }
  const supplierName = result.supplier_name ?? "";
  const knownSupplier = suppliers.find(
    (supplier) =>
      supplier.name.trim().toLocaleLowerCase() ===
      supplierName.trim().toLocaleLowerCase(),
  );
  const lineConfidence = Array.isArray(result.confidence?.line_items)
    ? (result.confidence.line_items as Array<Record<string, unknown>>)
    : [];
  const extraction: PersistExtraction = {
    fileName: path.basename(fileName),
    supplierId:
      knownSupplier?.id ??
      (supplierName ? createBlindIndex(supplierName, "") : `unknown-${randomUUID()}`),
    supplierName,
    supplierTin: result.supplier_tin,
    invoiceNumber: result.invoice_number,
    date: result.date ?? "",
    currency: result.currency ?? "",
    lineItems: result.line_items.map((line, index) => ({
      description: line.description,
      amount: line.amount,
      confidence:
        lineConfidence[index]?.description === "High" &&
        lineConfidence[index]?.amount === "High"
          ? "High"
          : lineConfidence[index]?.description === "Medium" ||
              lineConfidence[index]?.amount === "Medium"
            ? "Medium"
            : "Low",
    })),
    subtotal: result.subtotal,
    tax: result.tax_amount,
    total: result.total,
    confidence: result.confidence ?? {},
  };
  const sourceLabel =
    result.source === "live"
      ? "live OCR"
      : result.source === "cached-fallback"
        ? "cached fallback"
        : "cached extraction";
  const source =
    result.source === "live" || result.source === "cached-fallback"
      ? result.source
      : "cached";
  const row = await persistInvoice(
    extraction,
    fileBuffer,
    actorUserId,
    mimeType,
    false,
    sourceLabel,
  );
  return { invoice: toListItem(row), source };
}

export function revealInvoiceField(
  invoiceId: string,
  field: string,
  actorUserId: string,
): string | undefined {
  const row = getInvoiceRow(invoiceId);
  if (!row) {
    return undefined;
  }
  let value: string | undefined;
  if (field === "supplierTin") {
    value = decryptValue(row.supplier_tin_cipher);
  } else if (field === "invoiceNumber") {
    value = decryptValue(row.invoice_number_cipher);
  } else if (field === "subtotal") {
    value = decryptValue(row.subtotal_cipher);
  } else if (field === "tax") {
    value = decryptValue(row.tax_cipher);
  } else if (field === "total") {
    value = decryptValue(row.total_cipher);
  } else {
    const match = /^lineItems\.(\d+)\.(description|amount)$/.exec(field);
    if (match) {
      const line = getLineItemRows(invoiceId)[Number(match[1])];
      if (line) {
        value =
          match[2] === "description"
            ? decryptValue(line.description_cipher)
            : decryptValue(line.amount_cipher);
      }
    }
  }
  if (value !== undefined) {
    addActivity(invoiceId, actorUserId, "revealed sensitive field", field);
  }
  return value;
}

export async function getAuthorizedInvoiceFile(
  invoiceId: string,
  actorUserId: string,
  actorRole: string,
): Promise<{ bytes: Buffer; mimeType: string; fileName: string } | undefined> {
  const row = getInvoiceRow(invoiceId);
  if (!row) {
    return undefined;
  }
  if (!canAccessInvoice(actorRole, row.status)) {
    return undefined;
  }
  const workspace = isAccountWorkspace() ? "account" : "demo";
  let encryptedFile: Buffer;
  try {
    encryptedFile = await readInvoiceFile(row.private_file_path, workspace);
  } catch (error) {
    if (error instanceof MissingPrivateFileError) return undefined;
    throw error;
  }
  if (!isPrivateObjectReference(row.private_file_path)) {
    const durableReference = await storeInvoiceFile(workspace, invoiceId, encryptedFile);
    database.prepare("UPDATE invoices SET private_file_path = ? WHERE id = ?")
      .run(durableReference, invoiceId);
  }
  return {
    bytes: decryptBytes(encryptedFile),
    mimeType: row.mime_type,
    fileName: row.file_name,
  };
}

export function addActivityEntry(
  invoiceId: string | null,
  actorUserId: string,
  action: string,
  field: string | null = null,
): void {
  addActivity(invoiceId, actorUserId, action, field);
}

export function getActivity(invoiceId?: string, role = "Owner"): Array<{
  id: string;
  invoiceId: string | null;
  actor: string;
  action: string;
  field: string | null;
  createdAt: string;
}> {
  const permittedIds = new Set(getInvoices(role).map((invoice) => invoice.id));
  const rows = (
    invoiceId
      ? database
          .prepare(
            "SELECT * FROM activity_entries WHERE invoice_id = ? ORDER BY created_at DESC",
          )
          .all(invoiceId)
      : database
          .prepare("SELECT * FROM activity_entries ORDER BY created_at DESC")
          .all()
  ) as ActivityRow[];
  const users = listUsers();
  return rows.filter((row) => role === "Owner" || (row.invoice_id !== null && permittedIds.has(row.invoice_id))).slice(0, 100).map((row) => ({
    id: row.id,
    invoiceId: row.invoice_id,
    actor: users.find((user) => user.id === row.actor_user_id)?.name ?? "Hub user",
    action: row.action,
    field: row.field,
    createdAt: row.created_at,
  }));
}

export function updateInvoice(
  invoiceId: string,
  actorUserId: string,
  actorRole: string,
  input: Record<string, unknown>,
): InvoiceDetail | undefined {
  const row = getInvoiceRow(invoiceId);
  if (!row) {
    return undefined;
  }
  const reviewer = actorRole === "Accountant" || actorRole === "Owner";
  if (!reviewer && actorRole !== "Staff") throw new InvoiceError("Unknown workspace role.", 403);
  if (["Approved", "Rejected"].includes(row.status)) throw new InvoiceError("Final invoices cannot be edited.", 409);
  if (!reviewer && !["Draft", "Needs fixes"].includes(row.status)) throw new InvoiceError("Staff can edit only draft or returned invoices.", 403);
  if (input.reviewedWarningCodes !== undefined) throw new InvoiceError("Blocking issues must be corrected; they cannot be dismissed.");
  const changedFields = Object.keys(input);
  if (!changedFields.length) throw new InvoiceError("Enter a corrected value first.");
  const allowedFields = new Set(["supplierId", "supplierTin", "invoiceNumber", "date", "currency", "subtotal", "tax", "total", "lineItems"]);
  if (changedFields.some((field) => !allowedFields.has(field))) throw new InvoiceError("Choose a supplier record rather than changing its name.");
  if (!reviewer) {
    const editable = new Set(warningsFor(row).map((warning) => warning.field));
    if (changedFields.some((field) => !editable.has(field === "supplierId" ? "supplier" : field) &&
      !(field === "lineItems" && editable.has("subtotal")))) {
      throw new InvoiceError("Staff may only edit fields flagged for correction.", 403);
    }
  }
  const next = { ...row, updated_at: timestamp() };
  const oldLines = getLineItemRows(invoiceId);
  const lines = oldLines.map((line) => ({ ...line }));
  if (typeof input.supplierId === "string") {
    const supplier = getSupplier(input.supplierId);
    if (!supplier) throw new InvoiceError("Supplier record was not found.");
    next.supplier_id = supplier.id;
    next.supplier_name = supplier.name;
  }
  if (typeof input.invoiceNumber === "string") {
    next.invoice_number_cipher = encryptValue(input.invoiceNumber.trim());
    next.invoice_number_masked = maskLastFour(input.invoiceNumber.trim());
  }
  next.blind_index = createBlindIndex(next.supplier_id, decryptValue(next.invoice_number_cipher));
  if (typeof input.supplierTin === "string") {
    const tin = input.supplierTin.trim().toUpperCase();
    next.supplier_tin_cipher = encryptValue(tin);
    next.supplier_tin_masked = maskLastFour(tin);
  }
  for (const [field, column] of [["subtotal", "subtotal_cipher"], ["tax", "tax_cipher"], ["total", "total_cipher"]] as const) {
    if (input[field] !== undefined) {
      if (input[field] === null) {
        next[column] = encryptValue("");
        continue;
      }
      if (typeof input[field] !== "number" || !Number.isFinite(input[field])) throw new InvoiceError(`Enter a valid number for ${field}.`);
      next[column] = encryptValue(String(input[field]));
    }
  }
  if (typeof input.date === "string") next.invoice_date = input.date.trim();
  if (typeof input.currency === "string") next.currency = input.currency.trim().toUpperCase();
  if (Array.isArray(input.lineItems)) {
    const seen = new Set<string>();
    for (const raw of input.lineItems) {
      const line = raw as { id?: string; description?: string; amount?: number | null };
      const current = lines.find((entry) => entry.id === line.id);
      if (!current || seen.has(current.id) || (line.description === undefined && line.amount === undefined)) {
        throw new InvoiceError("Each corrected line item must reference a unique existing field.");
      }
      seen.add(current.id);
      if (line.description !== undefined) {
        if (typeof line.description !== "string") throw new InvoiceError("Enter a valid line description.");
        current.description_cipher = encryptValue(line.description.trim());
      }
      if (line.amount !== undefined) {
        if (line.amount !== null && (typeof line.amount !== "number" || !Number.isFinite(line.amount))) throw new InvoiceError("Enter a valid line amount.");
        current.amount_cipher = encryptValue(line.amount === null ? "" : String(line.amount));
      }
    }
  }
  next.warnings_json = JSON.stringify(validateStoredInvoice(next, lines));
  if (["Draft", "Needs fixes"].includes(next.status)) next.status = getStatusFromWarnings(warningsFor(next));
  // Validate everything before writing, then commit fields, lines and audit atomically.
  database.transaction(() => {
    const columns = ["supplier_id", "supplier_name", "supplier_tin_cipher", "supplier_tin_masked", "invoice_number_cipher",
      "invoice_number_masked", "blind_index", "invoice_date", "currency", "subtotal_cipher", "tax_cipher",
      "total_cipher", "status", "warnings_json", "updated_at"] as const;
    database.prepare(`UPDATE invoices SET ${columns.map((column) => `${column} = @${column}`).join(", ")} WHERE id = @id`).run(next);
    for (const line of lines) database.prepare("UPDATE line_items SET description_cipher = ?, amount_cipher = ? WHERE id = ?")
      .run(line.description_cipher, line.amount_cipher, line.id);
    for (const field of changedFields) addActivity(invoiceId, actorUserId, "edited protected invoice field", field);
    publishEvent("invoice.edited", { invoiceId, actorUserId });
  })();
  return getInvoiceDetail(invoiceId);
}

function validateStoredInvoice(row: InvoiceRow, lines = getLineItemRows(row.id)): RuleWarning[] {
  const amount = (cipher: string): number | null => {
    const value = decryptValue(cipher);
    return value.trim() === "" ? null : Number(value);
  };
  return evaluateInvoiceRules({
    supplier: row.supplier_name,
    expectedSupplierTin: getSupplier(row.supplier_id)?.tin,
    supplierTin: decryptValue(row.supplier_tin_cipher),
    invoiceNumber: decryptValue(row.invoice_number_cipher),
    date: row.invoice_date,
    currency: row.currency,
    subtotal: amount(row.subtotal_cipher),
    tax: amount(row.tax_cipher),
    total: amount(row.total_cipher),
    lineItems: lines.map((line) => ({ description: decryptValue(line.description_cipher), amount: amount(line.amount_cipher) })),
    blindIndex: row.blind_index,
  }, listBlindIndexes(row.id));
}

export function applyInvoiceAction(
  invoiceId: string,
  actorUserId: string,
  actorRole: string,
  action: "submit" | "send-back" | "pass-to-owner" | "approve" | "reject",
  comment?: string,
): InvoiceDetail | undefined {
  const row = getInvoiceRow(invoiceId);
  if (!row) {
    return undefined;
  }
  const warnings = validateStoredInvoice(row);
  const status = nextInvoiceStatus(action, {
    status: row.status, submittedBy: row.submitted_by_user_id, actorId: actorUserId,
    role: actorRole, warnings, comment,
  });
  const activity = { submit: "submitted for review", "send-back": "sent back for correction",
    "pass-to-owner": "passed invoice to owner", approve: "approved invoice", reject: "rejected invoice" }[action];
  database.transaction(() => {
    database.prepare(`UPDATE invoices SET status = ?, warnings_json = ?, submitted_by_user_id = ?,
      comment = ?, updated_at = ? WHERE id = ?`).run(status, JSON.stringify(warnings),
      action === "submit" ? actorUserId : row.submitted_by_user_id,
      comment?.trim() || (action === "submit" ? null : row.comment), timestamp(), invoiceId);
    addActivity(invoiceId, actorUserId, activity);
    publishEvent(`invoice.${action}`, { invoiceId, actorUserId });
  })();
  return getInvoiceDetail(invoiceId);
}

export function getExportRows(): Array<Record<string, unknown>> {
  const rows = database
    .prepare("SELECT * FROM invoices WHERE status = 'Approved' ORDER BY invoice_date DESC")
    .all() as InvoiceRow[];
  return rows.map((row) => ({
    supplier: row.supplier_name,
    supplierTin: decryptValue(row.supplier_tin_cipher),
    invoiceNumber: decryptValue(row.invoice_number_cipher),
    date: row.invoice_date,
    currency: row.currency,
    lineItems: getLineItemRows(row.id).map((line) => ({
      description: decryptValue(line.description_cipher),
      amount: Number(decryptValue(line.amount_cipher)),
    })),
    subtotal: Number(decryptValue(row.subtotal_cipher)),
    tax: Number(decryptValue(row.tax_cipher)),
    total: Number(decryptValue(row.total_cipher)),
    status: row.status,
  }));
}

export async function readDemoExtractionFile(fileName: string): Promise<Buffer | undefined> {
  const extraction = seedRows.find((candidate) => candidate.fileName === fileName);
  return extraction ? renderSyntheticInvoiceSvg(extraction) : undefined;
}

const DEMO_SAMPLES = [
  { fileName: "demo-missing-date.svg", label: "Missing date", description: "Detect a blank issue date, then correct it during review.", date: "" },
  { fileName: "demo-wrong-tin.svg", label: "Wrong TIN", description: "Detect a TIN belonging to a different synthetic supplier.", supplierTin: "IG99999999999" },
  { fileName: "demo-missing-tin.svg", label: "Missing TIN", description: "Ask for the supplier TIN before approving.", supplierTin: "" },
  { fileName: "demo-wrong-total.svg", label: "Wrong total", description: "Subtotal 100 + tax 8 should total 108, not 120.", total: 120 },
  { fileName: "demo-clean-invoice.svg", label: "Clean invoice", description: "Submit and approve a complete invoice with no blocking issues." },
  { fileName: "demo-duplicate.svg", label: "Duplicate invoice", description: "Compare with the existing Bumi approved record; reject the duplicate.", invoiceNumber: "BO-2026-1042" },
];

export function listDemoSamples() {
  return DEMO_SAMPLES.map(({ fileName, label, description }) => ({ fileName, label, description }));
}
function demoExtraction(fileName: string, unique = false): (typeof seedRows)[number] | undefined {
  const sample = DEMO_SAMPLES.find((entry) => entry.fileName === fileName);
  if (!sample) return undefined;
  return {
    ...structuredClone(seedRows[0]!),
    ...sample,
    invoiceNumber: sample.invoiceNumber ?? `DEMO-${sample.fileName.replace("demo-", "").replace(".svg", "")}${unique ? `-${randomUUID().slice(0, 8)}` : ""}`,
    status: "Draft",
  };
}
export function getDemoSampleFile(fileName: string): Buffer | undefined {
  const sample = demoExtraction(fileName);
  return sample ? renderSyntheticInvoiceSvg(sample) : undefined;
}
export async function loadDemoSample(fileName: string, actorUserId: string, unique = true): Promise<InvoiceDetail | undefined> {
  const sample = demoExtraction(fileName, unique);
  if (!sample) return undefined;
  const row = await persistInvoice({
    ...sample, supplierName: getSupplier(sample.supplierId)!.name,
  }, renderSyntheticInvoiceSvg(sample), actorUserId, "image/svg+xml");
  return toDetail(row);
}
