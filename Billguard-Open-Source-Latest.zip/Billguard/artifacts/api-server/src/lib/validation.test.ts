import test from "node:test";
import assert from "node:assert/strict";
import { evaluateInvoiceRules, isCalendarDate, type RuleInput } from "../../../../server/rules/engine";
import { nextInvoiceStatus } from "../../../../server/rules/workflow";

const valid: RuleInput = {
  supplier: "Bumi Office Supply Sdn Bhd", invoiceNumber: "INV-123",
  supplierTin: "IG10000000010", expectedSupplierTin: "IG10000000010",
  date: "2020-01-01", currency: "MYR", blindIndex: "index-123",
  lineItems: [{ description: "Paper", amount: 100 }], subtotal: 100, tax: 8, total: 108,
};
const cases: Array<[string, Partial<RuleInput>, string]> = [
  ["missing date", { date: "" }, "invalid_date"],
  ["impossible calendar date", { date: "2026-02-30" }, "invalid_date"],
  ["non-ISO ambiguous date", { date: "01/02/2020" }, "invalid_date"],
  ["future date", { date: "2999-12-01" }, "future_date"],
  ["missing TIN", { supplierTin: "" }, "missing_tin"],
  ["malformed TIN", { supplierTin: "not-a-tin" }, "invalid_tin"],
  ["supplier TIN mismatch", { supplierTin: "IG99999999999" }, "tin_mismatch"],
  ["missing invoice number", { invoiceNumber: "" }, "required_invoice_number"],
  ["missing supplier", { supplier: "" }, "required_supplier"],
  ["incorrect subtotal", { subtotal: 90 }, "subtotal_mismatch"],
  ["incorrect total", { total: 120 }, "total_mismatch"],
  ["null total", { total: null }, "missing_total"],
  ["missing subtotal", { subtotal: null }, "missing_subtotal"],
  ["missing tax", { tax: null }, "missing_tax"],
  ["negative total", { total: -1 }, "missing_total"],
  ["not-finite subtotal", { subtotal: Number.NaN }, "missing_subtotal"],
  ["missing currency", { currency: "" }, "invalid_currency"],
  ["missing line items", { lineItems: [] }, "missing_line_items"],
  ["missing description", { lineItems: [{ description: "", amount: 100 }] }, "missing_line_description"],
  ["missing line amount", { lineItems: [{ description: "Paper", amount: null }] }, "missing_line_amount"],
  ["negative line amount", { lineItems: [{ description: "Paper", amount: -100 }] }, "missing_line_amount"],
];
for (const [name, patch, expected] of cases) {
  test(`validation detects ${name} and recommends a correction`, () => {
    const warning = evaluateInvoiceRules({ ...valid, ...patch }, new Set()).find((entry) => entry.code === expected);
    assert.ok(warning, `Expected ${expected}`);
    assert.equal(warning.severity, "error");
    assert.ok(warning.message.length > 30);
    assert.ok(warning.field);
  });
}
test("clean invoice has no warnings", () => assert.deepEqual(evaluateInvoiceRules(valid, new Set()), []));
test("duplicate number is blocking", () => assert.ok(evaluateInvoiceRules(valid, new Set(["index-123"])).some((entry) => entry.code === "duplicate")));
test("zero tax is a review warning, not an invented tax liability", () => {
  const warnings = evaluateInvoiceRules({ ...valid, tax: 0, total: 100 }, new Set());
  assert.deepEqual(warnings.map((warning) => [warning.code, warning.severity]), [["tax_mismatch", "warning"]]);
});
test("leap years and impossible dates are validated strictly", () => {
  assert.equal(isCalendarDate("2024-02-29"), true);
  assert.equal(isCalendarDate("2023-02-29"), false);
  assert.equal(isCalendarDate("2020-13-01"), false);
});
test("cent rounding avoids false arithmetic errors", () => {
  const warnings = evaluateInvoiceRules({
    ...valid, lineItems: [{ description: "A", amount: 0.1 }, { description: "B", amount: 0.2 }],
    subtotal: 0.3, tax: 0.02, total: 0.32,
  }, new Set());
  assert.equal(warnings.some((warning) => warning.severity === "error"), false);
});

const context = { status: "In review", submittedBy: "siti", actorId: "mr-tan", role: "Accountant", warnings: [] };
for (const role of ["Staff", "Accountant", "Owner"]) {
  test(`${role} can submit a problem invoice for human review`, () => {
    assert.equal(nextInvoiceStatus("submit", {
      ...context, role, status: "Needs fixes",
      warnings: evaluateInvoiceRules({ ...valid, date: "" }, new Set()),
    }), "In review");
  });
}
for (const role of ["Owner", "Accountant"]) {
  for (const status of ["In review", "Awaiting approval"]) {
    test(`${role} can approve a clean invoice in ${status}`, () => assert.equal(nextInvoiceStatus("approve", { ...context, role, status }), "Approved"));
  }
  test(`${role} cannot approve unresolved errors`, () => {
    assert.throws(() => nextInvoiceStatus("approve", { ...context, role, warnings: evaluateInvoiceRules({ ...valid, total: 120 }, new Set()) }), /blocking/);
  });
  test(`${role} cannot approve its own submission`, () => assert.throws(() => nextInvoiceStatus("approve", { ...context, role, submittedBy: context.actorId }), /submitted/));
}
test("staff cannot approve", () => assert.throws(() => nextInvoiceStatus("approve", { ...context, role: "Staff" }), /Only an owner/));
test("drafts cannot skip submission", () => assert.throws(() => nextInvoiceStatus("approve", { ...context, status: "Draft" }), /Submit this invoice/));
test("in-review invoices cannot be resubmitted", () => assert.throws(() => nextInvoiceStatus("submit", context), /Only draft/));
test("send back requires a meaningful reason", () => assert.throws(() => nextInvoiceStatus("send-back", { ...context, comment: "   " }), /reason/));
test("reject requires a meaningful reason", () => assert.throws(() => nextInvoiceStatus("reject", context), /reason/));
test("return with reason enters correction state", () => assert.equal(nextInvoiceStatus("send-back", { ...context, comment: "Confirm date with supplier" }), "Needs fixes"));
for (const status of ["Approved", "Rejected"]) {
  test(`${status} invoices cannot be re-opened by workflow actions`, () => assert.throws(() => nextInvoiceStatus("submit", { ...context, status }), /final decision/));
}
