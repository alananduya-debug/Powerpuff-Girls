import Database from "better-sqlite3";
import { randomUUID } from "node:crypto";
import { mkdirSync } from "node:fs";
import path from "node:path";
import { AsyncLocalStorage } from "node:async_hooks";
import { setEventPublisher } from "../../../../server/hub-mock/index";

export const dataDirectory = path.resolve(process.env.INVOICE_DATA_DIR ??
  path.join(process.cwd(), path.basename(process.cwd()) === "api-server" ? "data" : "artifacts/api-server/data"));
mkdirSync(dataDirectory, { recursive: true });

export const databasePath = path.join(dataDirectory, "invoice-assistant.sqlite");
const demoDatabase = new Database(databasePath);
const accountDatabase = new Database(path.join(dataDirectory, "accounts.sqlite"));
export const workspaceContext = new AsyncLocalStorage<"demo" | "account">();
export const isAccountWorkspace = () => workspaceContext.getStore() === "account";
// Existing data belongs exclusively to the synthetic workspace. Never migrate it
// into the authenticated store. Async context also covers uploads after awaits.
export const database = new Proxy(demoDatabase, {
  get(_target, key) {
    const target = isAccountWorkspace() ? accountDatabase : demoDatabase;
    const value = Reflect.get(target, key);
    return typeof value === "function" ? value.bind(target) : value;
  },
});
export function closeDatabases() { demoDatabase.close(); accountDatabase.close(); }
export async function backupDatabases(destinationDirectory: string): Promise<void> {
  mkdirSync(destinationDirectory, { recursive: true });
  await demoDatabase.backup(path.join(destinationDirectory, "invoice-assistant.sqlite"));
  await accountDatabase.backup(path.join(destinationDirectory, "accounts.sqlite"));
}
function initializeSchema() {
database.pragma("journal_mode = WAL");
database.pragma("foreign_keys = ON");

database.exec(`
  CREATE TABLE IF NOT EXISTS invoices (
    id TEXT PRIMARY KEY,
    supplier_id TEXT NOT NULL,
    supplier_name TEXT NOT NULL,
    supplier_tin_cipher TEXT NOT NULL,
    supplier_tin_masked TEXT NOT NULL,
    invoice_number_cipher TEXT NOT NULL,
    invoice_number_masked TEXT NOT NULL,
    blind_index TEXT NOT NULL,
    invoice_date TEXT NOT NULL,
    currency TEXT NOT NULL,
    subtotal_cipher TEXT NOT NULL,
    tax_cipher TEXT NOT NULL,
    total_cipher TEXT NOT NULL,
    status TEXT NOT NULL,
    warnings_json TEXT NOT NULL,
    comment TEXT,
    submitted_by_user_id TEXT,
    created_by_user_id TEXT NOT NULL,
    file_name TEXT NOT NULL,
    mime_type TEXT NOT NULL,
    private_file_path TEXT NOT NULL,
    confidence_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS line_items (
    id TEXT PRIMARY KEY,
    invoice_id TEXT NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
    description_cipher TEXT NOT NULL,
    amount_cipher TEXT NOT NULL,
    confidence TEXT NOT NULL,
    position INTEGER NOT NULL
  );

  CREATE INDEX IF NOT EXISTS invoices_blind_index_idx ON invoices(blind_index);
  CREATE INDEX IF NOT EXISTS invoices_status_idx ON invoices(status);
  CREATE INDEX IF NOT EXISTS line_items_invoice_idx ON line_items(invoice_id, position);

  CREATE TABLE IF NOT EXISTS activity_entries (
    id TEXT PRIMARY KEY,
    invoice_id TEXT,
    actor_user_id TEXT NOT NULL,
    action TEXT NOT NULL,
    field TEXT,
    created_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS activity_invoice_idx ON activity_entries(invoice_id, created_at);

  CREATE TABLE IF NOT EXISTS team_access_audit (
    id TEXT PRIMARY KEY,
    actor_user_id TEXT NOT NULL,
    actor_name TEXT NOT NULL,
    target_user_id TEXT NOT NULL,
    target_email TEXT NOT NULL,
    from_role TEXT,
    to_role TEXT,
    outcome TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS team_access_audit_created_idx ON team_access_audit(created_at DESC);

  CREATE TABLE IF NOT EXISTS events (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS app_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );
`);
}
initializeSchema();
workspaceContext.run("account", initializeSchema);

setEventPublisher((name, payload) => {
  database
    .prepare(
      "INSERT INTO events (id, name, payload_json, created_at) VALUES (?, ?, ?, ?)",
    )
    .run(
      randomUUID(),
      name,
      JSON.stringify(payload),
      new Date().toISOString(),
    );
});
