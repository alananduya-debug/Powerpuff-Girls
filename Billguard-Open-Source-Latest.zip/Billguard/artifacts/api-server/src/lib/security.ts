import {
  createCipheriv,
  createDecipheriv,
  createHmac,
  hkdfSync,
  randomBytes,
  timingSafeEqual,
} from "node:crypto";

const ALGORITHM = "aes-256-gcm";
const IV_LENGTH = 12;
const TAG_LENGTH = 16;
const FILE_HEADER_LENGTH = IV_LENGTH + TAG_LENGTH;

function configuredKey(name: "ENCRYPTION_KEY" | "HMAC_KEY"): string | undefined {
  // Production-prefixed Secrets can be collected without changing the keys
  // used to encrypt existing development/demo invoices.
  return process.env.NODE_ENV === "production"
    ? process.env[`PRODUCTION_${name}`] ?? process.env[name]
    : process.env[name];
}

function getEncryptionKey(): Buffer {
  const encoded = configuredKey("ENCRYPTION_KEY");
  if (!encoded) {
    if (process.env.SESSION_SECRET) {
      return Buffer.from(hkdfSync("sha256", process.env.SESSION_SECRET, "invoice-assistant-demo", "encryption", 32));
    }
    throw new Error(
      "ENCRYPTION_KEY is required. Add a 64-character hexadecimal key in Replit Secrets before starting the API server.",
    );
  }
  if (!/^[0-9a-fA-F]{64}$/.test(encoded)) {
    throw new Error(
      "ENCRYPTION_KEY must be a 64-character hexadecimal value representing 32 bytes.",
    );
  }
  return Buffer.from(encoded, "hex");
}

function getHmacKey(): Buffer {
  const encoded = configuredKey("HMAC_KEY");
  if (!encoded) {
    if (process.env.SESSION_SECRET) {
      return Buffer.from(hkdfSync("sha256", process.env.SESSION_SECRET, "invoice-assistant-demo", "blind-index", 32));
    }
    throw new Error(
      "HMAC_KEY is required. Add a separate random secret of at least 32 bytes in Replit Secrets before starting the API server.",
    );
  }
  const key = Buffer.from(encoded, "utf8");
  if (key.byteLength < 32) {
    throw new Error("HMAC_KEY must be at least 32 bytes.");
  }
  return key;
}

export function assertSecretConfiguration(): void {
  const encryption = configuredKey("ENCRYPTION_KEY");
  const hmac = configuredKey("HMAC_KEY");
  if (process.env.NODE_ENV === "production" &&
    (!encryption || !hmac)) {
    throw new Error(
      "Production requires explicit ENCRYPTION_KEY and HMAC_KEY secrets (or PRODUCTION_ENCRYPTION_KEY and PRODUCTION_HMAC_KEY); SESSION_SECRET fallback is demo/development only.",
    );
  }
  getEncryptionKey();
  getHmacKey();
  if (encryption && hmac && encryption === hmac) {
    throw new Error("ENCRYPTION_KEY and HMAC_KEY must be different secrets.");
  }
}

export function encryptValue(value: string, key = getEncryptionKey()): string {
  const iv = randomBytes(IV_LENGTH);
  const cipher = createCipheriv(ALGORITHM, key, iv);
  const ciphertext = Buffer.concat([
    cipher.update(value, "utf8"),
    cipher.final(),
  ]);
  const tag = cipher.getAuthTag();
  return [
    "gcm1",
    iv.toString("base64url"),
    tag.toString("base64url"),
    ciphertext.toString("base64url"),
  ].join(".");
}

export function decryptValue(envelope: string, key = getEncryptionKey()): string {
  try {
    const [version, encodedIv, encodedTag, encodedCiphertext] = envelope.split(".");
    if (
      version !== "gcm1" ||
      !encodedIv ||
      !encodedTag ||
      encodedCiphertext === undefined
    ) {
      throw new Error("invalid envelope");
    }
    const iv = Buffer.from(encodedIv, "base64url");
    const tag = Buffer.from(encodedTag, "base64url");
    const ciphertext = Buffer.from(encodedCiphertext, "base64url");
    if (iv.byteLength !== IV_LENGTH || tag.byteLength !== TAG_LENGTH) {
      throw new Error("invalid envelope");
    }
    const decipher = createDecipheriv(ALGORITHM, key, iv);
    decipher.setAuthTag(tag);
    return Buffer.concat([
      decipher.update(ciphertext),
      decipher.final(),
    ]).toString("utf8");
  } catch {
    throw new Error("Encrypted data could not be authenticated.");
  }
}

export function encryptBytes(value: Buffer, key = getEncryptionKey()): Buffer {
  const iv = randomBytes(IV_LENGTH);
  const cipher = createCipheriv(ALGORITHM, key, iv);
  const ciphertext = Buffer.concat([cipher.update(value), cipher.final()]);
  return Buffer.concat([iv, cipher.getAuthTag(), ciphertext]);
}

export function decryptBytes(value: Buffer, key = getEncryptionKey()): Buffer {
  try {
    if (value.byteLength < FILE_HEADER_LENGTH) {
      throw new Error("invalid envelope");
    }
    const iv = value.subarray(0, IV_LENGTH);
    const tag = value.subarray(IV_LENGTH, FILE_HEADER_LENGTH);
    const ciphertext = value.subarray(FILE_HEADER_LENGTH);
    const decipher = createDecipheriv(ALGORITHM, key, iv);
    decipher.setAuthTag(tag);
    return Buffer.concat([decipher.update(ciphertext), decipher.final()]);
  } catch {
    throw new Error("Encrypted file could not be authenticated.");
  }
}

export function createBlindIndex(
  supplierId: string,
  invoiceNumber: string,
  key = getHmacKey(),
): string {
  const normalizedSupplier = supplierId.normalize("NFKC").trim().toLowerCase();
  const normalizedNumber = invoiceNumber.normalize("NFKC").trim().toLowerCase();
  return createHmac("sha256", key)
    .update(`${normalizedSupplier}\u0000${normalizedNumber}`, "utf8")
    .digest("hex");
}

export function blindIndexesMatch(left: string, right: string): boolean {
  if (!/^[0-9a-f]{64}$/i.test(left) || !/^[0-9a-f]{64}$/i.test(right)) {
    return false;
  }
  return timingSafeEqual(Buffer.from(left, "hex"), Buffer.from(right, "hex"));
}

export function maskLastFour(value: string): string {
  return value ? `••••${value.slice(-4)}` : "Not provided";
}
