import assert from "node:assert/strict";
import test from "node:test";
import { __private__, extractInvoice } from "../../../../server/ocr/extract.js";
import { evaluateInvoiceRules, type RuleInput } from "../../../../server/rules/engine";
import { cleanExtraction, extractionMistakes, syntheticSupplier } from "./fixtures/invoice-extractions";

function rulesFor(raw: unknown, duplicates = new Set<string>()) {
  const result = __private__.normalizeExtraction(raw, [syntheticSupplier], "synthetic.png");
  assert.ok(result);
  const input: RuleInput = {
    supplier: result.supplier_name ?? "", supplierTin: result.supplier_tin ?? "",
    expectedSupplierTin: syntheticSupplier.tin, invoiceNumber: result.invoice_number ?? "",
    date: result.date ?? "", currency: result.currency ?? "",
    lineItems: result.line_items.map((line) => ({ description: line.description ?? "", amount: line.amount })),
    subtotal: result.subtotal, tax: result.tax_amount, total: result.total, blindIndex: "synthetic-index",
  };
  return evaluateInvoiceRules(input, duplicates);
}

for (const fixture of extractionMistakes) {
  test(`synthetic extraction: ${fixture.name} explains the problem and correction`, () => {
    const warnings = rulesFor({ ...cleanExtraction, ...fixture.raw });
    const warning = warnings.find((entry) => entry.code === fixture.code);
    assert.ok(warning);
    assert.equal(warning.field, fixture.field);
    assert.equal(warning.severity, "error");
    assert.match(warning.message, fixture.recommendation);
  });
}

test("repeated-digit TIN is a suspicion, not a claim of official invalidity", () => {
  const warnings = rulesFor({ ...cleanExtraction, supplier_tin: "IG99999999999" });
  const warning = warnings.find((entry) => entry.code === "suspicious_tin");
  assert.ok(warning);
  assert.equal(warning.severity, "warning");
  assert.match(warning.message, /Compare every digit.*ask the supplier.*not government verification/);
  assert.ok(warnings.some((entry) => entry.code === "tin_mismatch" && entry.severity === "error"));
  assert.ok(!rulesFor(cleanExtraction).some((entry) => entry.code === "suspicious_tin"));
  assert.ok(!rulesFor({ ...cleanExtraction, supplier_tin: "IG10000000000" }).some((entry) => entry.code === "suspicious_tin"));
});

test("numeric-string fixture reconciles without rewriting printed amounts", () => {
  assert.deepEqual(rulesFor({ ...cleanExtraction,
    line_items: [{ description: "Synthetic paper", amount: "1,200.50" }],
    subtotal: "1,200.50", tax_amount: "96.04", total: "1,296.54",
  }), []);
});

test("duplicate fixture explains comparison without encouraging invented numbers", () => {
  const warning = rulesFor(cleanExtraction, new Set(["synthetic-index"])).find((entry) => entry.code === "duplicate");
  assert.ok(warning);
  assert.equal(warning.severity, "error");
  assert.match(warning.message, /Compare the original records; reject the duplicate.*Do not invent/);
});

test("unreadable extraction remains missing and never becomes a clean zero invoice", () => {
  const result = __private__.normalizeExtraction({}, [syntheticSupplier], "unreadable.png")!;
  assert.equal(result.total, null);
  assert.equal(result.confidence?.total, "Low");
  const warnings = rulesFor({});
  for (const code of ["invalid_date", "missing_tin", "missing_line_items", "missing_subtotal", "missing_tax", "missing_total"]) {
    assert.ok(warnings.some((entry) => entry.code === code && entry.severity === "error"), code);
  }
});

for (const raw of [null, [], "not an extraction", 123]) {
  test(`invalid extraction shape ${JSON.stringify(raw)} fails normalization`, () => {
    assert.equal(__private__.normalizeExtraction(raw, [], "synthetic.png"), null);
  });
}

test("failed live PDF reading never falls back to a matching cached filename", async () => {
  const result = await extractInvoice({
    fileName: "bumi-clean-invoice.svg", mimeType: "application/pdf", buffer: Buffer.from("not a PDF"),
  }, { mode: "live", knownSuppliers: [syntheticSupplier] });
  assert.deepEqual(result, { error: "We couldn't read this invoice. Check the file or try again later.", source: "failed" });
});

const suppliers = [
  { id: "known-supplier", name: "Known Supplier Sdn Bhd", tin: "IG123" },
];

for (const [raw, expected] of [
  ["100.00", 100], ["1,200.50", 1200.5], [" 108.00 ", 108], ["0", 0], ["-1.50", -1.5],
  ["", null], [" ", null], ["100 or 200", null], ["1,20.50", null], ["1.200,50", null],
  ["RM 108", null], ["1e2", null], [true, null], [Number.NaN, null], [Number.POSITIVE_INFINITY, null],
] as const) {
  test(`OCR amount normalization handles ${JSON.stringify(raw)} without guessing`, () => {
    const result = __private__.normalizeExtraction({ subtotal: raw, total: raw, tax_amount: raw, line_items: [{ description: "Synthetic", amount: raw }] }, [], "synthetic.png");
    assert.equal(result?.subtotal, expected);
    assert.equal(result?.total, expected);
    assert.equal(result?.tax_amount, expected);
    assert.equal(result?.line_items[0]?.amount, expected);
  });
}

for (const content of ["not JSON", '{"total":', "```json\ninvalid\n```", ""]) {
  test(`malformed model JSON fails explicitly: ${JSON.stringify(content)}`, () => {
    assert.equal(__private__.parseModelJson(content), null);
  });
}

test("OCR parser accepts a fenced JSON response without using model confidence", () => {
  const parsed = __private__.parseModelJson(
    '```json\n{"supplier_name":"Known Supplier Sdn Bhd","confidence":0.01}\n```',
  );
  assert.equal(parsed?.supplier_name, "Known Supplier Sdn Bhd");
  assert.equal(parsed?.confidence, 0.01);
});

test("OCR field confidence is derived locally from nulls, supplier match, and arithmetic", () => {
  const parsed = __private__.normalizeExtraction(
    {
      supplier_name: "Unlisted Supplier",
      supplier_tin: null,
      invoice_number: "INV-2",
      date: "2026-10-10",
      currency: "RM",
      line_items: [
        { description: "Paper", quantity: 1, unit_price: 10, amount: 10 },
      ],
      subtotal: 10,
      tax_amount: 1,
      total: 11,
      confidence: { supplier_name: "High", total: "High" },
    },
    suppliers,
    "invoice.png",
  );
  assert.equal(parsed?.confidence?.supplier_name, "Medium");
  assert.equal(parsed?.confidence?.supplier_tin, "Low");
  assert.equal(parsed?.confidence?.total, "High");
  assert.deepEqual(parsed?.confidence?.line_items, [
    { description: "High", quantity: "High", unit_price: "High", amount: "High" },
  ]);

  const invalidMath = __private__.normalizeExtraction(
    {
      supplier_name: "Known Supplier Sdn Bhd",
      supplier_tin: "IG123",
      invoice_number: "INV-2",
      date: "2026-10-10",
      currency: "RM",
      line_items: [{ description: "Paper", amount: 9 }],
      subtotal: 10,
      tax_amount: 1,
      total: 11,
    },
    suppliers,
    "invoice.png",
  );
  assert.equal(invalidMath?.confidence?.subtotal, "Low");
  assert.equal(invalidMath?.confidence?.total, "Low");
  assert.equal(
    (invalidMath?.confidence?.line_items as Array<{ amount: string }>)[0]?.amount,
    "Low",
  );
});

test("cached OCR mode resolves fixture data by uploaded filename", async () => {
  const result = await extractInvoice(
    {
      fileName: "BUMI-CLEAN-INVOICE.SVG",
      mimeType: "image/svg+xml",
      buffer: Buffer.from("<svg />"),
    },
    { mode: "cached", knownSuppliers: [ { id: "bumi-office", name: "Bumi Office Supply Sdn Bhd", tin: "IG10000000010" } ] },
  );
  assert.equal("error" in result, false);
  if (!("error" in result)) {
    assert.equal(result.supplier_name, "Bumi Office Supply Sdn Bhd");
    assert.equal(result.source, "cached");
    assert.equal(result.total, 108);
  }
});
