import assert from "node:assert/strict";
import { randomBytes } from "node:crypto";
import test from "node:test";
import {
  assertSecretConfiguration,
  createBlindIndex,
  decryptBytes,
  decryptValue,
  encryptBytes,
  encryptValue,
} from "./security";
import { evaluateInvoiceRules } from "../../../../server/rules/engine";

test("AES-256-GCM string encryption round trips with a fresh IV", () => {
  const key = randomBytes(32);
  const first = encryptValue("Invoice 123", key);
  const second = encryptValue("Invoice 123", key);
  assert.equal(decryptValue(first, key), "Invoice 123");
  assert.notEqual(first, second);
});

test("tampered ciphertext fails authentication without returning plaintext", () => {
  const key = randomBytes(32);
  const envelope = encryptValue("Confidential amount", key);
  const segments = envelope.split(".");
  const ciphertext = Buffer.from(segments[3]!, "base64url");
  ciphertext[0] = ciphertext[0]! ^ 0xff;
  segments[3] = ciphertext.toString("base64url");
  assert.throws(
    () => decryptValue(segments.join("."), key),
    /Encrypted data could not be authenticated/,
  );
});

test("AES-256-GCM file encryption round trips and rejects tampering", () => {
  const key = randomBytes(32);
  const original = Buffer.from("synthetic invoice file");
  const encrypted = encryptBytes(original, key);
  assert.deepEqual(decryptBytes(encrypted, key), original);
  encrypted[encrypted.length - 1] = encrypted[encrypted.length - 1]! ^ 0xff;
  assert.throws(() => decryptBytes(encrypted, key), /could not be authenticated/);
});

test("production requires independently retained encryption and blind-index keys", () => {
  const productionEncryption = process.env.PRODUCTION_ENCRYPTION_KEY;
  const productionHmac = process.env.PRODUCTION_HMAC_KEY;
  delete process.env.PRODUCTION_ENCRYPTION_KEY;
  delete process.env.PRODUCTION_HMAC_KEY;
  const original = {
    nodeEnv: process.env.NODE_ENV,
    session: process.env.SESSION_SECRET,
    encryption: process.env.ENCRYPTION_KEY,
    hmac: process.env.HMAC_KEY,
  };
  try {
    process.env.NODE_ENV = "production";
    process.env.SESSION_SECRET = "development-session-secret";
    delete process.env.ENCRYPTION_KEY;
    delete process.env.HMAC_KEY;
    assert.throws(assertSecretConfiguration, /Production requires explicit/);

    process.env.ENCRYPTION_KEY = randomBytes(32).toString("hex");
    process.env.HMAC_KEY = randomBytes(32).toString("hex");
    assert.doesNotThrow(assertSecretConfiguration);
    process.env.HMAC_KEY = process.env.ENCRYPTION_KEY;
    assert.throws(assertSecretConfiguration, /must be different/);
  } finally {
    if (productionEncryption === undefined) delete process.env.PRODUCTION_ENCRYPTION_KEY;
    else process.env.PRODUCTION_ENCRYPTION_KEY = productionEncryption;
    if (productionHmac === undefined) delete process.env.PRODUCTION_HMAC_KEY;
    else process.env.PRODUCTION_HMAC_KEY = productionHmac;
    if (original.nodeEnv === undefined) delete process.env.NODE_ENV;
    else process.env.NODE_ENV = original.nodeEnv;
    if (original.session === undefined) delete process.env.SESSION_SECRET;
    else process.env.SESSION_SECRET = original.session;
    if (original.encryption === undefined) delete process.env.ENCRYPTION_KEY;
    else process.env.ENCRYPTION_KEY = original.encryption;
    if (original.hmac === undefined) delete process.env.HMAC_KEY;
    else process.env.HMAC_KEY = original.hmac;
  }
});

test("production-specific secrets preserve preview encryption and remain strictly validated", () => {
  const names = ["NODE_ENV", "SESSION_SECRET", "ENCRYPTION_KEY", "HMAC_KEY",
    "PRODUCTION_ENCRYPTION_KEY", "PRODUCTION_HMAC_KEY"] as const;
  const original = Object.fromEntries(names.map(name => [name, process.env[name]]));
  try {
    process.env.NODE_ENV = "development";
    process.env.SESSION_SECRET = "synthetic-test-preview-session";
    delete process.env.ENCRYPTION_KEY;
    delete process.env.HMAC_KEY;
    const previewCiphertext = encryptValue("saved synthetic correction");
    const previewIndex = createBlindIndex("supplier", "invoice");
    const productionKey = randomBytes(32);
    process.env.PRODUCTION_ENCRYPTION_KEY = productionKey.toString("hex");
    process.env.PRODUCTION_HMAC_KEY = randomBytes(32).toString("hex");
    assert.equal(decryptValue(previewCiphertext), "saved synthetic correction");
    assert.equal(createBlindIndex("supplier", "invoice"), previewIndex);

    process.env.NODE_ENV = "production";
    assert.doesNotThrow(assertSecretConfiguration);
    assert.equal(decryptValue(encryptValue("production test"), productionKey), "production test");
    assert.notEqual(createBlindIndex("supplier", "invoice"), previewIndex);
    process.env.PRODUCTION_HMAC_KEY = process.env.PRODUCTION_ENCRYPTION_KEY;
    assert.throws(assertSecretConfiguration, /must be different/);
    process.env.PRODUCTION_HMAC_KEY = "too-short";
    assert.throws(assertSecretConfiguration, /at least 32 bytes/);
    delete process.env.PRODUCTION_HMAC_KEY;
    assert.throws(assertSecretConfiguration, /Production requires explicit/);
    process.env.PRODUCTION_HMAC_KEY = randomBytes(32).toString("hex");
    process.env.PRODUCTION_ENCRYPTION_KEY = "invalid-key";
    assert.throws(assertSecretConfiguration, /64-character hexadecimal/);
  } finally {
    for (const name of names) {
      if (original[name] === undefined) delete process.env[name];
      else process.env[name] = original[name];
    }
  }
});

test("duplicate detection uses supplier and invoice blind indexes", () => {
  const key = randomBytes(32);
  const existing = createBlindIndex("supplier-a", "INV-01", key);
  const duplicate = createBlindIndex("supplier-a", "inv-01", key);
  const differentSupplier = createBlindIndex("supplier-b", "INV-01", key);
  assert.equal(existing, duplicate);
  assert.notEqual(existing, differentSupplier);

  const warnings = evaluateInvoiceRules(
    {
      supplier: "Supplier A",
      invoiceNumber: "INV-01",
      date: "2026-10-10",
      supplierTin: "IG00000000001",
      lineItems: [{ description: "test", amount: 100 }],
      subtotal: 100,
      tax: 8,
      total: 108,
      blindIndex: duplicate,
    },
    new Set([existing]),
  );
  assert.ok(warnings.some((warning) => warning.code === "duplicate"));
});
