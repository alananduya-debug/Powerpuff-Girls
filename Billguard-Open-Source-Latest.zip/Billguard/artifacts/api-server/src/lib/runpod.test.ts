import assert from "node:assert/strict";
import test, { after, mock } from "node:test";
import { mkdtempSync, rmSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import type { AddressInfo } from "node:net";
import { getRunpodConfiguration } from "../../../../server/ocr/runpod.js";

const directory = mkdtempSync(path.join(os.tmpdir(), "billguard-runpod-"));
process.env.INVOICE_DATA_DIR = directory;
process.env.PRIVATE_UPLOAD_DIR = path.join(directory, "uploads");
process.env.INVOICE_FILE_STORAGE = "local";
// Test-only credentials and endpoint. No provider is contacted.
process.env.RUNPOD_API_KEY = "test-only-runpod-key";
process.env.RUNPOD_ENDPOINT_ID = "test-endpoint";
process.env.RUNPOD_MODEL = "test-vision-model";
delete process.env.RUNPOD_SERVED_MODEL;
delete process.env.RUNPOD_BASE_URL;
const service = await import("./invoice-service");
const { closeDatabases } = await import("./database");
const { reservePublicLiveRead } = await import("./public-live-usage");
await service.initializeInvoiceData();
const { default: app } = await import("../app");
const server = app.listen(0, "127.0.0.1");
await new Promise<void>((resolve) => server.once("listening", resolve));
const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}/api/demo-workspace`;
after(async () => {
  await new Promise<void>((resolve) => server.close(() => resolve()));
  closeDatabases();
  rmSync(directory, { recursive: true, force: true });
});
const actualFetch = globalThis.fetch.bind(globalThis);
let providerCalls = 0;
let failProvider = false;
let captured: Record<string, any> = {};
mock.method(globalThis, "fetch", async (input: Parameters<typeof fetch>[0], init?: RequestInit) => {
  if (String(input).startsWith("https://api.runpod.ai/")) {
    providerCalls++;
    captured = JSON.parse(String(init?.body));
    assert.equal(new Headers(init?.headers).get("authorization"), "Bearer test-only-runpod-key");
    if (failProvider) return new Response("provider internal details", { status: 500 });
    return Response.json({ choices: [{ message: { content: JSON.stringify({
      supplier_name: "Bumi Office Supply Sdn Bhd", supplier_tin: "IG10000000010",
      invoice_number: `RUNPOD-TEST-${providerCalls}`, date: "2025-03-12", currency: "MYR",
      line_items: [{ description: "Paper", quantity: 1, unit_price: 100, amount: 100 }],
      subtotal: 100, tax_amount: 8, total: 108,
    }) } }] });
  }
  return actualFetch(input, init);
});
async function settings(mode: "live" | "cached", user = "ms-lim") {
  return actualFetch(`${base}/settings/ocr`, {
    method: "PUT", headers: { "X-Demo-User-Id": user, "Content-Type": "application/json" },
    body: JSON.stringify({ mode }),
  });
}
async function upload(consent = true, user = "siti") {
  const file = new FormData();
  file.append("file", new Blob([Buffer.from(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jTz0AAAAASUVORK5CYII=", "base64",
  )], { type: "image/png" }), "synthetic-runpod-test.png");
  return actualFetch(`${base}/invoices/upload`, {
    method: "POST", headers: { "X-Demo-User-Id": user, ...(consent ? { "X-Live-AI-Consent": "yes" } : {}) }, body: file,
  });
}
test("Runpod configuration accepts endpoint IDs and rejects credential-leaking redirects or external hosts", () => {
  assert.equal(getRunpodConfiguration()?.baseUrl, "https://api.runpod.ai/v2/test-endpoint/openai/v1");
  process.env.RUNPOD_BASE_URL = "https://untrusted.invalid/v1";
  assert.equal(getRunpodConfiguration(), null);
  process.env.RUNPOD_BASE_URL = "https://api.runpod.ai/v2/test/openai/v1?api_key=unsafe";
  assert.equal(getRunpodConfiguration(), null);
  delete process.env.RUNPOD_BASE_URL;
});
test("public users enable Runpod and upload images without signing in, with explicit consent", async () => {
  assert.equal((await settings("live", "siti")).status, 403);
  const enabled = await settings("live");
  assert.equal(enabled.status, 200);
  assert.deepEqual(await enabled.json(), { mode: "live", liveConfigured: true });
  assert.equal((await upload(false)).status, 400);
  assert.equal(providerCalls, 0);
  const response = await upload();
  assert.equal(response.status, 201, await response.clone().text());
  const result = await response.json() as { source: string; invoice: { id: string } };
  assert.equal(result.source, "live");
  assert.equal(providerCalls, 1);
  assert.equal(captured.model, "test-vision-model");
  assert.match(captured.messages[1].content[1].image_url.url, /^data:image\/png;base64,/);
  assert.equal(service.revealInvoiceField(result.invoice.id, "total", "ms-lim"), "108");
});
test("failed Runpod reads create no invoice and never substitute cached data", async () => {
  const count = service.getInvoices("Owner").length;
  failProvider = true;
  const result = await upload();
  failProvider = false;
  assert.equal(result.status, 422);
  const serialized = JSON.stringify(await result.json());
  assert.equal(serialized.includes("provider internal details"), false);
  assert.equal(serialized.includes("test-only-runpod-key"), false);
  assert.equal(service.getInvoices("Owner").length, count);
});
test("daily and concurrent public upload limits fail before contacting Runpod", async () => {
  const before = providerCalls;
  process.env.RUNPOD_DAILY_LIMIT = "0";
  assert.equal((await upload()).status, 429);
  delete process.env.RUNPOD_DAILY_LIMIT;
  const first = reservePublicLiveRead();
  const second = reservePublicLiveRead();
  assert.throws(() => reservePublicLiveRead(), /busy/);
  first(); second();
  assert.equal(providerCalls, before);
});
test("synthetic samples remain editable and saved corrections persist independently of cached originals", async () => {
  assert.equal((await settings("cached")).status, 200);
  const sample = await service.loadDemoSample("demo-missing-tin.svg", "siti");
  assert.ok(sample);
  service.updateInvoice(sample.id, "ms-lim", "Owner", { supplierTin: "IG10000000010", total: 108, currency: "MYR" });
  assert.equal(service.revealInvoiceField(sample.id, "supplierTin", "ms-lim"), "IG10000000010");
  assert.equal(service.revealInvoiceField(sample.id, "total", "ms-lim"), "108");
  const detail = await actualFetch(`${base}/invoices/${sample.id}`, { headers: { "X-Demo-User-Id": "ms-lim" } });
  assert.equal(detail.status, 200);
  assert.equal((await detail.json() as { currency: string }).currency, "MYR");
});
