import { mkdir, readFile, unlink, writeFile } from "node:fs/promises";
import path from "node:path";
import { objectStorageClient } from "./objectStorage";

const PRIVATE_UPLOAD_DIR = path.resolve(
  process.env.PRIVATE_UPLOAD_DIR ?? path.join(process.cwd(), "data", "private_uploads"),
);
const OBJECT_REFERENCE_PREFIX = "object://";

export class MissingPrivateFileError extends Error {
  constructor() {
    super("The protected invoice file is missing.");
    this.name = "MissingPrivateFileError";
  }
}

function storageMode(): "local" | "object" {
  if (process.env.INVOICE_FILE_STORAGE === "local") {
    if (process.env.NODE_ENV === "production") {
      throw new Error("Local invoice file storage is not allowed in production.");
    }
    return "local";
  }
  if (process.env.PRIVATE_OBJECT_DIR) return "object";
  throw new Error("PRIVATE_OBJECT_DIR is required for private invoice file storage.");
}

function privateObjectLocation(key: string) {
  if (
    !/^(?:invoice-files|invoice-backups)\/[a-zA-Z0-9._/-]+$/.test(key) ||
    key.split("/").some((part) => !part || part === "." || part === "..")
  ) {
    throw new Error("Invalid private object key.");
  }
  const configuredPath = process.env.PRIVATE_OBJECT_DIR;
  if (!configuredPath) throw new Error("PRIVATE_OBJECT_DIR is required for private object storage.");
  const parts = configuredPath.replace(/^\/+/, "").split("/");
  const bucketName = parts.shift();
  if (!bucketName || parts.length === 0) {
    throw new Error("PRIVATE_OBJECT_DIR must include a bucket and private directory.");
  }
  return {
    bucket: objectStorageClient.bucket(bucketName),
    objectName: `${parts.join("/")}/${key}`,
  };
}

export function isPrivateObjectReference(reference: string): boolean {
  return reference.startsWith(OBJECT_REFERENCE_PREFIX);
}

function invoiceObjectKey(workspace: "demo" | "account", invoiceId: string): string {
  if (!/^[0-9a-f-]{36}$/i.test(invoiceId)) throw new Error("Invalid invoice file reference.");
  return `invoice-files/${workspace}/${invoiceId}.enc`;
}

export async function storePrivateObject(key: string, bytes: Buffer): Promise<void> {
  if (storageMode() !== "object") {
    throw new Error("Encrypted database backups require App Storage.");
  }
  const location = privateObjectLocation(key);
  await location.bucket.file(location.objectName).save(bytes, {
    resumable: false,
    validation: "crc32c",
    metadata: {
      contentType: "application/octet-stream",
      cacheControl: "private, no-store",
    },
  });
}

export async function readPrivateObject(key: string): Promise<Buffer> {
  if (storageMode() !== "object") {
    throw new Error("Private object storage is not configured.");
  }
  const location = privateObjectLocation(key);
  try {
    const [bytes] = await location.bucket.file(location.objectName).download();
    return bytes;
  } catch (error) {
    if (typeof error === "object" && error !== null && "code" in error && error.code === 404) {
      throw new MissingPrivateFileError();
    }
    throw error;
  }
}

export async function deletePrivateObject(key: string): Promise<void> {
  if (storageMode() !== "object") return;
  const location = privateObjectLocation(key);
  await location.bucket.file(location.objectName).delete({ ignoreNotFound: true });
}

export async function storeInvoiceFile(
  workspace: "demo" | "account",
  invoiceId: string,
  encryptedBytes: Buffer,
): Promise<string> {
  const key = invoiceObjectKey(workspace, invoiceId);
  if (storageMode() === "local") {
    const filePath = path.join(PRIVATE_UPLOAD_DIR, workspace, `${invoiceId}.enc`);
    await mkdir(path.dirname(filePath), { recursive: true });
    await writeFile(filePath, encryptedBytes, { mode: 0o600 });
    return filePath;
  }
  await storePrivateObject(key, encryptedBytes);
  return `${OBJECT_REFERENCE_PREFIX}${key}`;
}

export async function readInvoiceFile(
  reference: string,
  workspace: "demo" | "account",
): Promise<Buffer> {
  if (isPrivateObjectReference(reference)) {
    const key = reference.slice(OBJECT_REFERENCE_PREFIX.length);
    if (!key.startsWith(`invoice-files/${workspace}/`) ||
      !new RegExp(`^invoice-files/${workspace}/[0-9a-f-]{36}\\.enc$`, "i").test(key)) {
      throw new Error("Invoice file belongs to a different workspace.");
    }
    return readPrivateObject(key);
  }
  try {
    return await readFile(reference);
  } catch (error) {
    if (typeof error === "object" && error !== null && "code" in error && error.code === "ENOENT") {
      throw new MissingPrivateFileError();
    }
    throw error;
  }
}

export async function removeInvoiceFile(reference: string): Promise<void> {
  if (isPrivateObjectReference(reference)) {
    await deletePrivateObject(reference.slice(OBJECT_REFERENCE_PREFIX.length));
    return;
  }
  await unlink(reference).catch((error: unknown) => {
    if (!(typeof error === "object" && error !== null && "code" in error && error.code === "ENOENT")) {
      throw error;
    }
  });
}
