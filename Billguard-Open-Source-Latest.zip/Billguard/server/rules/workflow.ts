import type { RuleWarning } from "./engine";

export class InvoiceError extends Error {
  constructor(message: string, public readonly status = 400) {
    super(message);
  }
}

export type WorkflowAction = "submit" | "send-back" | "pass-to-owner" | "approve" | "reject";
type Context = { status: string; submittedBy: string | null; actorId: string; role: string; warnings: RuleWarning[]; comment?: string };

export function nextInvoiceStatus(action: WorkflowAction, context: Context): string {
  const { status, submittedBy, actorId, role, warnings, comment } = context;
  if (!["Staff", "Owner", "Accountant"].includes(role)) throw new InvoiceError("Unknown workspace role.", 403);
  if (["Approved", "Rejected"].includes(status)) throw new InvoiceError("This invoice has already received a final decision.", 409);
  if (action === "submit") {
    if (!["Draft", "Needs fixes"].includes(status)) throw new InvoiceError("Only draft or returned invoices can be submitted for review.", 409);
    return "In review";
  }
  if (!["Owner", "Accountant"].includes(role)) throw new InvoiceError("Only an owner or accountant can review invoices.", 403);
  if (!["In review", "Awaiting approval"].includes(status)) throw new InvoiceError("Submit this invoice for review before making a review decision.", 409);
  if (action === "send-back" || action === "reject") {
    if (!comment?.trim()) throw new InvoiceError("Add a reason explaining what needs correction or why the invoice is rejected.");
    return action === "send-back" ? "Needs fixes" : "Rejected";
  }
  if (action === "pass-to-owner") return "Awaiting approval";
  if (submittedBy === actorId) throw new InvoiceError("The person who submitted this invoice cannot give final approval. Ask the other reviewer.", 403);
  if (warnings.some((warning) => warning.severity === "error")) throw new InvoiceError("Correct all blocking invoice issues before approving.");
  return "Approved";
}
