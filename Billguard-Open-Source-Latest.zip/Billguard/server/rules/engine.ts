import taxConfig from "./config.json" with { type: "json" };

export type RuleInput = {
  supplier: string;
  invoiceNumber: string;
  date: string;
  supplierTin: string;
  expectedSupplierTin?: string;
  currency?: string;
  lineItems: Array<{ description: string; amount: number | null }>;
  subtotal: number | null;
  tax: number | null;
  total: number | null;
  blindIndex: string;
};

export type RuleWarning = {
  code: string;
  severity: "error" | "warning";
  message: string;
  field: string;
};

// Date.parse alone accepts impossible dates such as 2026-02-30.
export function isCalendarDate(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const parsed = new Date(`${value}T00:00:00.000Z`);
  return !Number.isNaN(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
}

export function evaluateInvoiceRules(
  invoice: RuleInput,
  existingBlindIndexes: ReadonlySet<string>,
  referenceTaxRate = taxConfig.referenceTaxRate,
): RuleWarning[] {
  const warnings: RuleWarning[] = [];
  const add = (code: string, field: string, message: string, severity: "error" | "warning" = "error") =>
    warnings.push({ code, field, message, severity });
  if (!invoice.supplier.trim()) add("required_supplier", "supplier", "Supplier is missing. Select the supplier shown on the original invoice.");
  if (!invoice.invoiceNumber.trim()) add("required_invoice_number", "invoiceNumber", "Invoice number is missing. Enter the number printed on the original invoice.");
  if (!isCalendarDate(invoice.date)) {
    add("invalid_date", "date", "Invoice date is missing or invalid. Enter a real calendar date from the original invoice (YYYY-MM-DD).");
  } else if (invoice.date > new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Kuala_Lumpur" })) {
    add("future_date", "date", "Invoice date is in the future. Confirm the issue date with the supplier and correct it.");
  }
  const tin = invoice.supplierTin.trim().toUpperCase();
  if (!tin) {
    add("missing_tin", "supplierTin", "Supplier TIN is missing. Ask the supplier for its TIN and enter it exactly as provided.");
  } else if (!/^(?:C|CS|D|F|FA|IG|LE|PT|TA|TC|TN|TR|TP|J)\d{8,12}$/.test(tin)) {
    add("invalid_tin", "supplierTin", "TIN format is not recognised for this Malaysian demo. Check the prefix and digits against the supplier's tax record; do not guess.");
  } else {
    if (/^[A-Z]+(\d)\1{7,11}$/.test(tin)) {
      add("suspicious_tin", "supplierTin", "TIN contains only repeated digits and may be an extraction error or placeholder. Compare every digit with the original invoice and ask the supplier for its tax record; do not guess. This is not government verification.", "warning");
    }
    if (invoice.expectedSupplierTin && tin !== invoice.expectedSupplierTin.trim().toUpperCase()) {
      add("tin_mismatch", "supplierTin", "TIN does not match the selected supplier's demo record. Confirm the supplier and correct the TIN or supplier selection. This is not government verification.");
    }
  }
  if (invoice.currency !== undefined && !/^(?:RM|MYR|USD|SGD|EUR|GBP|CNY|JPY|AUD|THB|IDR)$/.test(invoice.currency)) {
    add("invalid_currency", "currency", "Currency is missing or unsupported. Enter the currency printed on the invoice, such as MYR.");
  }
  if (!invoice.lineItems.length) add("missing_line_items", "lineItems", "No line items were extracted. Re-upload a readable invoice containing its item descriptions and amounts.");
  if (invoice.lineItems.some((line) => !line.description.trim())) add("missing_line_description", "lineItems", "A line item description is missing. Copy the description from the original invoice.");
  const validAmount = (amount: number | null): amount is number => amount !== null && Number.isFinite(amount) && amount >= 0;
  if (invoice.lineItems.some((line) => !validAmount(line.amount))) add("missing_line_amount", "lineItems", "A line item amount is missing, negative or invalid. Enter the correct non-negative amount from the original invoice.");
  for (const field of ["subtotal", "tax", "total"] as const) {
    if (!validAmount(invoice[field])) add(`missing_${field}`, field, `The ${field} is missing, negative or invalid. Enter the correct non-negative amount from the original invoice.`);
  }
  // Compare integer cents so harmless IEEE-754 rounding is not flagged.
  const cents = (value: number) => Math.round(value * 100);
  const tolerance = Math.round(taxConfig.tolerance * 100);
  const lineAmounts = invoice.lineItems.map((line) => line.amount);
  if (validAmount(invoice.subtotal) && lineAmounts.every(validAmount)) {
    const lineSum = lineAmounts.reduce((sum, amount) => sum + cents(amount), 0);
    if (Math.abs(lineSum - cents(invoice.subtotal)) > tolerance) {
      add("subtotal_mismatch", "subtotal", "Subtotal does not match the line items. Compare every item amount with the original and correct the subtotal or line items.");
    }
  }
  if (validAmount(invoice.subtotal) && validAmount(invoice.tax) && validAmount(invoice.total) &&
      Math.abs(cents(invoice.subtotal) + cents(invoice.tax) - cents(invoice.total)) > tolerance) {
    add("total_mismatch", "total", "Total does not match subtotal plus tax. Correct the total or its components using the original invoice.");
  }
  if (validAmount(invoice.subtotal) && validAmount(invoice.tax) &&
      Math.abs(cents(invoice.tax) - cents(invoice.subtotal * referenceTaxRate)) > tolerance) {
    add("tax_mismatch", "tax", "Tax differs from the demo reference rate. Ask the accountant to confirm exemptions and the applicable treatment; do not change tax just to match this reference.", "warning");
  }
  if (invoice.invoiceNumber.trim() && invoice.blindIndex && existingBlindIndexes.has(invoice.blindIndex)) {
    add("duplicate", "invoiceNumber", "This invoice number may already be recorded for this supplier. Compare the original records; reject the duplicate or correct a genuinely misread number. Do not invent a new number.");
  }
  return warnings;
}

export function blocksSubmission(warnings: RuleWarning[]): boolean {
  // Retained for compatibility: errors block approval, not submission to a reviewer.
  return warnings.some((warning) => warning.severity === "error");
}
