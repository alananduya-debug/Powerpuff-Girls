// Server-only Runpod vLLM/OpenAI-compatible adapter. Never expose these values
// through API responses, browser bundles or logs.
export function getRunpodConfiguration() {
  const apiKey = process.env.RUNPOD_API_KEY;
  const model = (process.env.RUNPOD_SERVED_MODEL ?? process.env.RUNPOD_MODEL ?? process.env.RUNPOD_MODEL_NAME)?.trim();
  const endpointId = process.env.RUNPOD_ENDPOINT_ID?.trim();
  const base = process.env.RUNPOD_BASE_URL?.trim() ??
    (endpointId && /^[a-zA-Z0-9_-]+$/.test(endpointId)
      ? `https://api.runpod.ai/v2/${endpointId}/openai/v1` : undefined);
  if (!apiKey || !model || !base) return null;
  try {
    const url = new URL(base);
    if (url.protocol !== "https:" || url.username || url.password ||
        url.search || url.hash ||
        !(url.hostname === "api.runpod.ai" || url.hostname.endsWith(".proxy.runpod.net")) ||
        !url.pathname.replace(/\/$/, "").endsWith("/v1")) return null;
    return { apiKey, model, baseUrl: base.replace(/\/$/, "") };
  } catch { return null; }
}

export class RunpodReadError extends Error {
  constructor(message) { super(message); this.name = "RunpodReadError"; }
}

export async function callRunpod(messages) {
  const config = getRunpodConfiguration();
  if (!config) throw new RunpodReadError("Runpod is not configured on the server.");
  const configuredTimeout = Number(process.env.RUNPOD_REQUEST_TIMEOUT_MS ?? 90_000);
  const timeout = Number.isFinite(configuredTimeout) ? Math.min(240_000, Math.max(10_000, configuredTimeout)) : 90_000;
  let response;
  try {
    response = await fetch(`${config.baseUrl}/chat/completions`, {
    method: "POST",
    redirect: "error",
    signal: AbortSignal.timeout(timeout),
    headers: { Authorization: `Bearer ${config.apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: config.model, messages, max_tokens: 4096, temperature: 0,
    }),
    });
  } catch (error) {
    throw new RunpodReadError(error?.name === "TimeoutError" || error?.name === "AbortError"
      ? `Runpod did not finish within ${Math.round(timeout / 1000)} seconds. Its worker may still be starting or jobs may be queued. Check the Runpod worker status before retrying.`
      : "The Runpod worker could not be reached. Check the endpoint status before retrying.");
  }
  // Do not include upstream bodies: they may contain document data or secrets.
  if (!response.ok) {
    const message = response.status === 401 || response.status === 403
      ? "Runpod denied access. The app owner must check the API key and endpoint permissions."
      : response.status === 404
        ? "Runpod could not find this endpoint or model. Check the OpenAI-compatible endpoint and deployed vision model."
        : response.status === 400
          ? "Runpod rejected the model or request format. The app owner must match RUNPOD_MODEL to the endpoint's advertised model and confirm it supports images."
          : response.status === 429
            ? "Runpod is rate-limiting requests. Wait before retrying."
            : "Runpod could not process this invoice. Check the worker logs and model readiness.";
    throw new RunpodReadError(message);
  }
  let result;
  try { result = await response.json(); }
  catch { throw new RunpodReadError("Runpod returned an unreadable response. Check that the worker provides an OpenAI-compatible API."); }
  const content = result?.choices?.[0]?.message?.content;
  if (typeof content !== "string") throw new RunpodReadError("Runpod returned no invoice text. Check the worker model and API compatibility.");
  return content;
}
