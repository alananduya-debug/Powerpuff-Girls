export function getRunpodConfiguration(): {
  apiKey: string; model: string; baseUrl: string;
} | null;
export function callRunpod(messages: unknown[]): Promise<string>;
export class RunpodReadError extends Error {}
