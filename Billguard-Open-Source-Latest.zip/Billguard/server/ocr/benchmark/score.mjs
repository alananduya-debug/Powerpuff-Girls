import { isDeepStrictEqual } from "node:util";

export function scoreExtraction(expected, extracted) {
  const fields = [];
  const add = (field, value, actual) => fields.push({
    field, expected: value, extracted: actual === undefined ? null : actual,
    match: isDeepStrictEqual(value, actual),
  });
  for (const [field, value] of Object.entries(expected)) {
    if (field !== "line_items") add(field, value, extracted?.[field]);
  }
  const lines = Array.isArray(extracted?.line_items) ? extracted.line_items : [];
  add("line_items.length", expected.line_items.length, lines.length);
  for (let index = 0; index < Math.max(expected.line_items.length, lines.length); index++) {
    for (const field of ["description", "quantity", "unit_price", "amount"]) {
      add(`line_items[${index}].${field}`, expected.line_items[index]?.[field], lines[index]?.[field]);
    }
  }
  return { fields, matched: fields.filter((field) => field.match).length, total: fields.length };
}
