import assert from "node:assert/strict";
import test from "node:test";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { fixtures, generateFixtures } from "./fixtures.mjs";
import { scoreExtraction } from "./score.mjs";
import { parseOptions, runBenchmark } from "./cli.mjs";
import { __private__ } from "../extract.js";

test("live calls require two explicit flags, independent of OCR_MODE", async () => {
  for (const args of [
    ["--live"], ["--accept-provider-costs"], ["--provider", "unknown"],
    ["--repeats", "0"], ["--repeats", "6"], ["--repeats", "NaN"], ["--typo"],
  ]) {
    assert.throws(() => parseOptions(args));
  }
  assert.deepEqual(parseOptions(["--live", "--accept-provider-costs", "--provider", "replit", "--repeats", "2"]),
    { live: true, acceptedCosts: true, provider: "replit", repeats: 2 });
  const previous = process.env.OCR_MODE;
  process.env.OCR_MODE = "live";
  try {
    const result = await runBenchmark([], {
      loadExtractor: () => { throw new Error("Offline mode must not import a provider."); },
      log: () => {},
    });
    assert.deepEqual(result, { live: false, calls: 0 });
  } finally {
    if (previous === undefined) delete process.env.OCR_MODE;
    else process.env.OCR_MODE = previous;
  }
});

test("synthetic fixtures produce PNGs and image-only PDFs readable by the production raster path", async () => {
  const directory = await mkdtemp(path.join(tmpdir(), "ocr-pixels-"));
  try {
    const files = await generateFixtures(directory);
    assert.equal(files.length, 6);
    for (const file of files) {
      const buffer = await readFile(file.filePath);
      if (file.mimeType === "image/png") {
        assert.equal(buffer.subarray(1, 4).toString(), "PNG");
      } else {
        assert.equal(buffer.subarray(0, 8).toString(), "%PDF-1.4");
        const input = await __private__.readPdf(buffer);
        assert.equal(input.text, "");
        assert.equal(input.images.length, 1);
        assert.match(input.images[0], /^data:image\/png;base64,/);
      }
    }
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
});

test("scoring counts every TIN digit and leading zero without fuzzy matching", () => {
  const expected = fixtures[0].expected;
  assert.equal(expected.supplier_tin.slice(2).length, 11);
  const score = scoreExtraction(expected, {
    ...expected, supplier_tin: "IG9999999999", invoice_number: "11100",
  });
  assert.deepEqual(score.fields.filter((field) => !field.match).map((field) => field.field),
    ["supplier_tin", "invoice_number"]);
});

test("normalization and scoring preserve wrong printed totals, grouped strings and faint/missing dates", () => {
  for (const fixture of fixtures) {
    const e = fixture.expected;
    const raw = {
      ...e,
      subtotal: e.subtotal.toLocaleString("en-US", { minimumFractionDigits: 2 }),
      tax_amount: String(e.tax_amount), total: String(e.total),
      line_items: e.line_items.map((line) => ({
        ...line, quantity: String(line.quantity), unit_price: String(line.unit_price), amount: String(line.amount),
      })),
    };
    const result = __private__.normalizeExtraction(raw, [], "synthetic.png");
    const score = scoreExtraction(e, result);
    assert.equal(score.matched, score.total);
    assert.equal(result.total, e.total);
    assert.equal(result.date, e.date);
    if (e.subtotal + e.tax_amount !== e.total) {
      assert.equal(result.confidence.total, "Low");
      const corrected = scoreExtraction(e, { ...result, total: e.subtotal + e.tax_amount });
      assert.equal(corrected.fields.find((field) => field.field === "total").match, false);
    }
  }
});

test("missing fields, extra lines and extraction failures cannot receive a perfect score", () => {
  const expected = fixtures[2].expected;
  assert.equal(scoreExtraction(expected, {}).matched, 0);
  const extra = scoreExtraction(expected, { ...expected, line_items: [...expected.line_items, expected.line_items[0]] });
  assert.equal(extra.fields.find((field) => field.field === "line_items.length").match, false);
  const failed = scoreExtraction(expected, { source: "failed", error: "unreadable" });
  assert.equal(failed.matched, 0);
});

test("opted-in benchmark uses the live application reader and records failures without hiding mismatches", async (t) => {
  let calls = 0;
  const directory = await mkdtemp(path.join(tmpdir(), "ocr-fake-report-"));
  t.after(() => rm(directory, { recursive: true, force: true }));
  const report = await runBenchmark(["--live", "--accept-provider-costs"], {
    outputDirectory: directory,
    // Stub only. This routine test never calls any provider.
    loadExtractor: async () => ({
      extractInvoice: async (file, options) => {
        calls++;
        assert.deepEqual(options, { mode: "live", provider: "runpod", knownSuppliers: [] });
        assert.ok(Buffer.isBuffer(file.buffer));
        assert.equal("expected" in file, false);
        const fixture = fixtures.find((entry) => file.fileName.startsWith(entry.id));
        if (calls === 1) return { ...fixture.expected, source: "cached" };
        return { ...fixture.expected, source: "live" };
      },
    }),
    log: () => {},
  });
  assert.equal(calls, 6);
  assert.equal(report.summary.failedExtractions, 1);
  assert.equal(report.summary.exactInvoices, 5);
  assert.equal(report.results[0].matched, 0);
  assert.ok(report.summary.exactFieldAccuracy < 1);
  assert.match(report.results[0].inputSha256, /^[a-f0-9]{64}$/);
});
