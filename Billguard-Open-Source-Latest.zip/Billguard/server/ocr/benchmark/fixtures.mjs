import { createCanvas } from "@napi-rs/canvas";
import { deflateSync } from "node:zlib";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { pathToFileURL } from "node:url";
import fixtures from "./fixtures.json" with { type: "json" };

export { fixtures };
export const defaultOutput = new URL("../../../generated-artifacts/ocr-benchmark/", import.meta.url);

const money = (value) => value.toLocaleString("en-US", {
  minimumFractionDigits: 2, maximumFractionDigits: 2,
});

// Image-only PDF: no hidden text layer, metadata answers, or OCR shortcut.
function rasterPdf(canvas) {
  const { width, height } = canvas;
  const rgba = canvas.getContext("2d").getImageData(0, 0, width, height).data;
  const rgb = Buffer.alloc(width * height * 3);
  for (let i = 0, j = 0; i < rgba.length; i += 4) {
    rgb[j++] = rgba[i]; rgb[j++] = rgba[i + 1]; rgb[j++] = rgba[i + 2];
  }
  const pixels = deflateSync(rgb);
  const content = Buffer.from("q 600 0 0 450 0 0 cm /Im0 Do Q\n");
  const objects = [
    Buffer.from("<< /Type /Catalog /Pages 2 0 R >>"),
    Buffer.from("<< /Type /Pages /Kids [3 0 R] /Count 1 >>"),
    Buffer.from("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 600 450] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>"),
    Buffer.concat([Buffer.from(`<< /Type /XObject /Subtype /Image /Width ${width} /Height ${height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /FlateDecode /Length ${pixels.length} >>\nstream\n`), pixels, Buffer.from("\nendstream")]),
    Buffer.concat([Buffer.from(`<< /Length ${content.length} >>\nstream\n`), content, Buffer.from("endstream")]),
  ];
  const chunks = [Buffer.from("%PDF-1.4\n")];
  const offsets = [0];
  for (const [index, object] of objects.entries()) {
    offsets.push(Buffer.concat(chunks).length);
    chunks.push(Buffer.from(`${index + 1} 0 obj\n`), object, Buffer.from("\nendobj\n"));
  }
  const xrefOffset = Buffer.concat(chunks).length;
  chunks.push(Buffer.from(`xref\n0 6\n0000000000 65535 f \n${offsets.slice(1).map((offset) => `${String(offset).padStart(10, "0")} 00000 n \n`).join("")}trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF\n`));
  return Buffer.concat(chunks);
}

export function renderFixture(fixture) {
  const canvas = createCanvas(1200, 900);
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "#ffffff"; ctx.fillRect(0, 0, 1200, 900);
  const text = (value, x, y, color = "#171717", size = 26) => {
    ctx.fillStyle = color; ctx.font = `${size}px monospace`; ctx.fillText(value, x, y);
  };
  const e = fixture.expected;
  text("SYNTHETIC INVOICE - NOT A REAL TRANSACTION", 45, 65, "#555555", 24);
  text(e.supplier_name, 45, 135, "#171717", 34);
  text(`Supplier TIN: ${e.supplier_tin}`, 45, 200);
  text(`Invoice number: ${e.invoice_number}`, 45, 250);
  text("Date:", 45, 300);
  text(e.date ?? "", 145, 300, fixture.faintDate ? "#c4c4c4" : "#171717");
  text(`Currency: ${e.currency}`, 45, 350);
  text("Description", 45, 435); text("Qty", 510, 435);
  text("Unit price", 660, 435); text("Amount", 980, 435);
  e.line_items.forEach((line, i) => {
    const y = 495 + i * 55;
    text(line.description, 45, y); text(String(line.quantity), 510, y);
    text(money(line.unit_price), 660, y); text(money(line.amount), 980, y);
  });
  text(`Subtotal: ${money(e.subtotal)}`, 700, 665);
  text(`Tax:      ${money(e.tax_amount)}`, 700, 720);
  text(`Total:    ${money(e.total)}`, 700, 775);
  text("For OCR testing only. All names and identifiers are invented.", 45, 855, "#555555", 21);
  return canvas;
}

export async function generateFixtures(directory = defaultOutput) {
  await mkdir(directory, { recursive: true });
  const root = directory instanceof URL ? directory : pathToFileURL(`${path.resolve(directory)}/`);
  const files = [];
  for (const fixture of fixtures) {
    const canvas = renderFixture(fixture);
    for (const [extension, buffer] of [["png", canvas.toBuffer("image/png")], ["pdf", rasterPdf(canvas)]]) {
      const fileName = `${fixture.id}.${extension}`;
      const filePath = new URL(fileName, root);
      await writeFile(filePath, buffer);
      files.push({ fixture, fileName, filePath, mimeType: extension === "pdf" ? "application/pdf" : "image/png" });
    }
  }
  return files;
}
