import { readFile, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { pathToFileURL } from "node:url";
import { fixtures, generateFixtures, defaultOutput } from "./fixtures.mjs";
import { scoreExtraction } from "./score.mjs";

export function parseOptions(args) {
  const options = { live: false, acceptedCosts: false, provider: "runpod", repeats: 1 };
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (arg === "--live") options.live = true;
    else if (arg === "--accept-provider-costs") options.acceptedCosts = true;
    else if (arg === "--provider") options.provider = args[++i];
    else if (arg === "--repeats") options.repeats = Number(args[++i]);
    else throw new Error(`Unknown argument: ${arg}`);
  }
  if (!["runpod", "replit"].includes(options.provider)) throw new Error("Provider must be runpod or replit.");
  if (!Number.isInteger(options.repeats) || options.repeats < 1 || options.repeats > 5) throw new Error("Repeats must be an integer from 1 to 5.");
  if (options.live !== options.acceptedCosts) throw new Error("Live calls require both --live and --accept-provider-costs.");
  return options;
}

export async function runBenchmark(args, {
  loadExtractor = () => import("../extract.js"), log = console.log,
  outputDirectory = defaultOutput,
} = {}) {
  const options = parseOptions(args);
  const files = await generateFixtures(outputDirectory);
  if (!options.live) {
    log(`OFFLINE: generated ${files.length} synthetic PNG/PDF fixtures. No provider called; accuracy not measured.`);
    for (const fixture of fixtures) log(`${fixture.id}: ${fixture.challenge}`);
    return { live: false, calls: 0 };
  }
  // Import the provider path only after explicit opt-in. Never send ground truth
  // or known supplier names to the model; use exactly the application reader.
  const { extractInvoice } = await loadExtractor();
  const report = {
    schemaVersion: 1, startedAt: new Date().toISOString(),
    provider: options.provider,
    model: options.provider === "runpod"
      ? (process.env.RUNPOD_MODEL ?? process.env.RUNPOD_MODEL_NAME ?? "unconfigured")
      : "gpt-5.4-mini",
    repeats: options.repeats,
    fixtureManifestSha256: createHash("sha256").update(JSON.stringify(fixtures)).digest("hex"),
    note: "Exact normalized field agreement, not taxpayer verification or a production accuracy estimate. Provider token/cost usage is not exposed by the application reader; consult provider billing. SDK retries may incur additional requests.",
    results: [],
  };
  log(`LIVE: ${files.length * options.repeats} sequential extractions via ${options.provider}; charges may apply. No benchmark-level retries.`);
  for (let repeat = 1; repeat <= options.repeats; repeat++) {
    for (const file of files) {
      const buffer = await readFile(file.filePath);
      const started = performance.now();
      let extracted;
      try {
        extracted = await extractInvoice({ fileName: file.fileName, mimeType: file.mimeType, buffer },
          { mode: "live", provider: options.provider, knownSuppliers: [] });
      } catch {
        extracted = { source: "failed", error: "Extraction threw an error." };
      }
      const failed = extracted?.source !== "live" || Boolean(extracted?.error);
      const score = scoreExtraction(file.fixture.expected, failed ? undefined : extracted);
      const result = {
        fileName: file.fileName, repeat,
        inputSha256: createHash("sha256").update(buffer).digest("hex"),
        durationMs: Math.round(performance.now() - started),
        source: extracted?.source ?? "failed",
        failed,
        ...score,
      };
      report.results.push(result);
      log(`\n${file.fileName} run ${repeat}: ${score.matched}/${score.total}${result.failed ? " EXTRACTION FAILED" : ""}`);
      for (const field of score.fields) {
        log(`${field.match ? "PASS" : "FAIL"} ${field.field}: expected=${JSON.stringify(field.expected)} extracted=${JSON.stringify(field.extracted)}`);
      }
    }
  }
  const matched = report.results.reduce((sum, result) => sum + result.matched, 0);
  const total = report.results.reduce((sum, result) => sum + result.total, 0);
  report.summary = {
    matched, total, exactFieldAccuracy: total ? matched / total : 0,
    failedExtractions: report.results.filter((result) => result.failed).length,
    exactInvoices: report.results.filter((result) => !result.failed && result.matched === result.total).length,
  };
  report.finishedAt = new Date().toISOString();
  const output = new URL(`report-${new Date().toISOString().replaceAll(":", "-")}.json`, files[0].filePath);
  await writeFile(output, `${JSON.stringify(report, null, 2)}\n`);
  log(`\nExact fields: ${matched}/${total}. JSON report: ${output.pathname}`);
  return report;
}

// Safe to import in routine tests: the command only runs as a direct entrypoint.
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  runBenchmark(process.argv.slice(2)).then((report) => {
    if (report.live === false) return;
    if (report.summary.failedExtractions || report.summary.matched !== report.summary.total) process.exitCode = 1;
  }).catch(() => {
    console.error("Benchmark failed. Check arguments, local write access and provider configuration. Live calls require --live --accept-provider-costs; --provider runpod|replit; --repeats 1..5.");
    process.exitCode = 2;
  });
}
