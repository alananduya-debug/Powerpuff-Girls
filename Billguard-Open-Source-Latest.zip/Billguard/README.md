# Billguard — invoice review

## Current website: no-sign-in submission demo

The public homepage opens directly into the synthetic demo from the submission
ZIP. It does not mount the sign-in/sign-up interface. Previously shared `/demo/`
links remain supported. The role selector simulates Staff, Accountant and Owner;
it is not authentication. Use synthetic samples or non-sensitive test invoices
only. Other visitors can view shared demo records.

Existing account data has not been deleted or made public. Account API routes
remain protected and are not used by the public demo. Authentication-related
instructions below describe the retained account implementation, not the current
public website.

### Runpod Live AI (public testing)

Configure server-only `RUNPOD_API_KEY`, `RUNPOD_ENDPOINT_ID` and `RUNPOD_MODEL`
(the deployed, vision-capable model name). Alternatively use `RUNPOD_BASE_URL`
instead of the endpoint ID, pointing to a Runpod OpenAI-compatible `/v1` URL.
Custom `/runsync` handler payloads are not supported by this adapter.
Never put the API key in a `VITE_` variable or browser code.
`RUNPOD_SERVED_MODEL` is an optional non-secret override for the exact API model
identifier advertised by the endpoint. It takes precedence over `RUNPOD_MODEL`.
`RUNPOD_REQUEST_TIMEOUT_MS` allows a longer cold-start window (up to 240 seconds).

Select Owner → Settings → Live AI. Any simulated role can then upload a PDF
(up to three pages), PNG, JPEG or WebP file, up to 15 MB, without signing in,
after accepting the upload notice. Reads are sent to Runpod and spend the
provider account's credits. Failed live reads never fall back to cached results.
The Load sample buttons always use saved, synthetic results.

Public reads are limited to two concurrent requests and five attempts per minute
per running server, with a default limit of 30 attempts per UTC day. Failed reads
count. `RUNPOD_DAILY_LIMIT` can lower the daily limit, including zero to disable
reads. These are application limits, not a provider-wide billing guarantee;
set a Runpod spending limit as well.

Corrections to an invoice instance save automatically after typing pauses for
one second. The Save corrections button also saves immediately. Submission,
sidebar navigation and role changes wait for pending corrections. A new Load
sample creates a new invoice, not a replacement for a previously corrected one.

The uploaded Orbyte Invoice Assistant was imported with its existing React interface,
SQLite database design and encrypted fields preserved. Archived databases, encrypted
uploads, Git history and secrets were **not imported**. The running demo is seeded from
the original synthetic invoice fixtures.

## Try the demo

1. Open Billguard; the no-sign-in demo inbox is ready immediately. Select a synthetic sample.
2. Submit it as Staff or Owner. Accountants use **Upload & submit** (or load a
   sample) to send directly into review. Invoices with issues can still reach a reviewer.
3. Switch to Owner or Accountant. Read the issue messages, compare the original
   document, enter corrections and select **Save corrections**.
4. Approve once blocking issues are resolved, or return/reject with an explanation.
5. A submitter cannot approve their own invoice; switch to the other reviewer.
6. Approved invoices appear in Records. The owner can export CSV or JSON.

### Invoice access

| Role | Accessible statuses |
| --- | --- |
| Staff | Draft, Needs fixes, Rejected |
| Accountant | In review, Awaiting approval |
| Owner | All statuses |

These are role/status rules, not uploader-only rules. The API enforces them on
lists, individual links, documents, protected fields, changes and workflow actions.
Counts and activity use the same scope. Only owners can see approved records.
Staff return to their inbox after submission; accountants return after a final
decision or sending back. An owner may still see an unsubmitted draft, by design.

Six sample cases cover missing date, wrong TIN, missing TIN, wrong total, clean
invoice and duplicate invoice. Loading a sample creates a new synthetic record.

### Cached versus Live AI

- Cached mode is a simulation using only the exact downloaded demo documents.
  Renaming an unrelated file does not make it a valid sample.
- **Live AI** requires a signed-in account with an assigned role. Public demo
  users, including the simulated Owner, cannot enable it or upload other files.
  OpenAI access uses Replit AI
  Integrations; no personal API key is needed and usage consumes Replit credits.
  Invoice text/images are sent to the AI provider. The public demo remains
  limited to exact synthetic fixtures, regardless of saved or environment settings.
- Supported uploads: PDF (up to 3 pages), PNG, JPEG and WebP, up to 15 MB.
  SVG is limited to exact generated samples.
- A live failure returns an error; it never silently substitutes fixture data.
- AI extraction is fallible. In particular, repeated TIN digits can be misread.
  Always compare extracted values with the original before approving.
- TIN checks are Malaysian-demo format checks plus matching against the synthetic
  supplier list, **not** verification with a tax authority.
- Tax-rate differences are review warnings, not tax advice.

## Corrected behavior

- All three roles can upload and submit.
- Owners can correct all non-final invoices; accountants can correct pending-review invoices.
- Either reviewer can approve; routing to the owner is optional.
- Blocking errors prevent approval, not submission.
- Corrections re-evaluate all rules; reviewed-warning codes cannot bypass errors.
- Impossible dates, missing or mismatched TINs, missing fields, arithmetic errors,
  duplicates, invalid currencies and missing/negative amounts are checked.
- Final records are read-only. Workflow transitions are checked on the server.
- Field updates, line updates and their audit events commit atomically.
- Role changes clear frontend caches/revealed values. Pending screens refresh.
- Unknown demo identities, MIME spoofing and cached-filename spoofing are rejected.
- CSV formula prefixes are neutralised on export.

## Development and verification

```sh
pnpm run typecheck
pnpm --filter @workspace/api-server run test
```

The automated suite covers validation,
workflow permissions/transitions, encrypted values, extraction parsing, and HTTP
integration flows against a disposable database. See `docs/verification.md`.
Managed workflows run the API and the web preview.

The existing demo and account SQLite databases remain separate; neither is migrated
to PostgreSQL or merged with the other. New invoice documents are encrypted with
AES-256-GCM and stored in the private App Storage area, under separate `demo` and
`account` object prefixes. They are never exposed through a public object route:
authorized invoice endpoints fetch and decrypt them only after the existing
workspace and role/status checks. Legacy local-file records are moved to private
storage during API startup while their local files are still available. Missing objects return a not-found
response; storage outages are reported as a protected-file error, not replaced with
fixture content.

### SQLite persistence, backup and restore

`INVOICE_DATA_DIR` still controls the location of `invoice-assistant.sqlite` and
`accounts.sqlite`. These are independent SQLite stores, and the API must remain a
single writer. SQLite should only be used for real operational data when the host
provides a supported durable filesystem for that directory; do not place it on an
ephemeral deployment filesystem, a shared/network filesystem, or run multiple API
instances against it. Replit published-app files reset on publish, so this
workspace's local SQLite files are not by themselves durable across replacement.
No database migration is performed by this change.

The API provides encrypted online snapshots of both databases in private App
Storage. Run the backup command in the environment that owns the data, with its
production secrets and `PRIVATE_OBJECT_DIR` configured:

```sh
pnpm --filter @workspace/api-server run backup:database
```

It prints a backup ID such as `20261024T135100Z-a1b2c3d4`. Keep that ID with the operational
change record. To restore both database files, stop the API first, then run:

```sh
pnpm --filter @workspace/api-server run restore:database -- 20261024T135100Z-a1b2c3d4
```

Restore downloads both encrypted snapshots, authenticates/decrypts them, checks
SQLite integrity and foreign keys, preserves copies of current local database
files when present, and then replaces both files. Start the API and verify both
workspaces afterward. Invoice documents remain in App Storage and are not included
in the SQLite snapshots.

These snapshots protect against local filesystem reset and provide a point-in-time
restore, but they are not continuous database persistence or a second independent
backup of the object bucket. Before real operational use, configure a supported
durable single-writer location for SQLite, automate and monitor backups from that
same environment, and maintain a separate protected copy or retention strategy
for private invoice objects. Prove restore on a non-production copy before relying
on it; a backup is not considered verified until both database integrity and
representative invoice-file reads succeed.

Explicit `ENCRYPTION_KEY` and `HMAC_KEY` remain supported. To add keys through the secure form without
changing existing preview encryption, use `PRODUCTION_ENCRYPTION_KEY` and
`PRODUCTION_HMAC_KEY`: these take precedence only when `NODE_ENV=production`
and are ignored in development. Both must be different; the encryption key must
be 64 hexadecimal characters and the HMAC key must be at least 32 bytes.
The demo can derive
distinct keys from `SESSION_SECRET` using HKDF, but operational accounts must use
stable, separately retained secrets. Store and recover those keys independently
from the database and object backups. Losing/changing `ENCRYPTION_KEY` makes
encrypted invoice fields, files and database snapshots unreadable; losing/changing
`HMAC_KEY` breaks duplicate detection for existing records. Do not place key values
inside a backup, repository, or operational notes.

## Signed-in accounts

The public root is the synthetic demo; account sign-in and sign-up remain
available at `/sign-in` and `/sign-up`. Account pages live under `/workspace`;
the role switcher exists only under `/demo`. Account API requests use verified
session cookies, never a browser-selected identity.
New accounts have **no invoice access** until an Owner assigns a role. The first
Owner must be deliberately bootstrapped by a trusted operator.
All assigned members share one business workspace with the role/status rules above;
this is not a multi-organisation product and does not filter by uploader.

### Manage team access

After the first Owner has been bootstrapped, Owners can open **Team access** in
the signed-in workspace to search existing verified Clerk members and grant
Staff, Accountant or Owner access, or revoke access. Account creation and
invitations remain separate from role assignment.

For deliberate first-owner bootstrap or trusted-operator recovery, ask the
person to create an account and verify their email. In the **target environment**,
a trusted operator with server access can run:

```sh
pnpm --filter @workspace/api-server assign-role member@example.com Staff
pnpm --filter @workspace/api-server assign-role reviewer@example.com Accountant
pnpm --filter @workspace/api-server assign-role administrator@example.com Owner
pnpm --filter @workspace/api-server assign-role member@example.com revoke
```

These addresses are examples, not seeded accounts. The command requires exactly
one existing verified account; it does not create accounts, assign passwords or
accept roles from the browser. The first Owner is never promoted automatically.
Role grants and revocations from either the Owner screen or trusted command are
audited. The API fetches current metadata on every request, so changes do not
wait for token expiry.
Run against the appropriate environment's Clerk credentials: development and
production users are separate. Never copy development IDs or credentials into
production, and do not schedule role-grant commands to rerun automatically.

### Demo separation

`/api/*` requires a signed-in, assigned account. `/api/demo-workspace/*` is the
explicit public simulation and accepts only the three known demo identities.
The old invoice SQLite database is retained exclusively for synthetic demo data;
the account database starts empty and is never seeded from fixtures.
Files are reachable only through the corresponding database's authorized invoice
routes. Lists, summary, detail, file, protected-field reveal, activity, updates,
actions, records and exports are checked server-side. Account reading requires
Live AI; cached synthetic extraction cannot be selected for account uploads.

## Remaining operational checks before real use

Do not put real data in the public demo. Before operational production use:

- Confirm the production API can write and read private App Storage objects, and
  that demo and account prefixes remain isolated.
- Configure a durable, single-writer SQLite location; Replit published local files
  reset on publish, so do not rely on the workspace's local databases.
- Schedule monitored encrypted database backups and separate private-object
  retention/backups, then perform and record a full restore test.
- Retain `ENCRYPTION_KEY` and `HMAC_KEY` securely with tested recovery procedures.
- Add operational monitoring for database integrity, missing/unreadable invoice
  objects, storage availability, backup age and restore-test status.
- Apply jurisdiction-specific tax/TIN rules and add organisation isolation before
  hosting unrelated businesses.

No payments, authority filing, or official TIN verification are performed.
