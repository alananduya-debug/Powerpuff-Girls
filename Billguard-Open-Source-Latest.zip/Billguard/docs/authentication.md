# Authentication verification

The authenticated workspace uses Clerk's signature-verified session, followed by
a fresh server lookup of admin-controlled public metadata. Only exact Staff,
Accountant and Owner roles are accepted. Missing roles and failed lookups deny
access; unsafe metadata, role headers and payload fields never grant access.

The automated authentication suite uses disposable databases and a generated RSA
key. It runs the actual Clerk middleware and application routes with signed test
sessions; only the remote Clerk user-profile lookup is stubbed. It covers:

- unsigned/forged/expired sessions, signed browser cookies, missing roles and browser identity spoofing;
- role-filtered lists, details, files and activity;
- forbidden corrections, decisions and protected-field reveals;
- owner-only exports and no approved records for other roles;
- immediate role revocation and two-way demo/account record isolation.
- owner-only verified-member search and role updates, self-change prevention,
  last-owner protection, access-change auditing and immediate permission refresh.
- cross-site mutation rejection.
- unsigned demo Owners cannot enable live OCR or upload arbitrary PDF/image bytes,
  even with old live-mode settings or a synthetic filename.

The existing workflow suite still tests the same status and action rules in the
isolated demo, including status transfers, self-approval restrictions and data
validation. Run both with `pnpm --filter @workspace/api-server test`.

These tests are not evidence of multi-tenant isolation or durable storage.
Clerk development and production identities are independent. No production
accounts are seeded by this change. See README for first-owner bootstrap and
owner-managed access after bootstrap.
