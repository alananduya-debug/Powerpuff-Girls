# Synthetic pixel-reading benchmark

This benchmark measures agreement with **printed ground truth**, not arithmetic
correctness or official TIN validity. All names, numbers and documents are invented.
Never add customer invoices, supplier records, credentials or personal information.

## Offline preparation (no charges)

From the workspace root:

```sh
pnpm ocr:benchmark
```

This creates three PNGs and three image-only PDFs in
`generated-artifacts/ocr-benchmark/`. It **does not measure live accuracy**.
The committed source of truth is `server/ocr/benchmark/fixtures.json`;
`fixtures.mjs` renders visible pixels from that manifest. The PDFs embed only
raster pixels: there is no hidden text layer or expected-answer metadata.
Outputs and reports are ignored by Git and deployment packaging.

| Fixture | Pixel challenge | Ground-truth traps |
| --- | --- | --- |
| repeated-nines | `IG99999999999` (11 nines), grouped `1,200.50` amount | invoice `0000011100`; printed total **1,396.54**, not calculated 1,296.54 |
| faint-date-zero-run | `IG10000000010`, faint `2024-02-29` in #c4c4c4 on white | invoice `0000100101`; amounts 100.10 + 8.01 = 108.11 |
| missing-date-wrong-subtotal | `IG11111111111` (11 ones), blank date | line sum 100.00, printed subtotal **90.00**, tax 8.00, printed total **120.00** |

Printed quantities and amounts are text, including thousands separators and
two-decimal formatting. The JSON ground truth expects normalized numbers.
Tests separately simulate model responses containing numeric strings: pixels
cannot establish whether a model chose JSON strings or JSON numbers.

## Explicitly opt in to paid live reading

```sh
# Uses existing server-side Runpod configuration.
pnpm ocr:benchmark --live --accept-provider-costs --provider runpod

# Alternative: existing Replit AI integration.
pnpm ocr:benchmark --live --accept-provider-costs --provider replit

# Up to five repeats, for nondeterminism comparisons:
pnpm ocr:benchmark --live --accept-provider-costs --provider runpod --repeats 3
```

Both flags are mandatory, even if `OCR_MODE=live` is set. Unknown arguments,
invalid providers and repeats outside 1–5 fail before any provider import/call.
The default provider is Runpod; there is no automatic provider fallback.
Only the fixed synthetic manifest can be sent; the command has no arbitrary file
input. It calls the same `extractInvoice` implementation as the application,
with `mode: "live"` and no known suppliers, so expected answers are not leaked.
The script bypasses public-demo HTTP quotas and must be run only by an operator.
It creates no invoice records and changes no application data.

### Cost and privacy

One repeat makes **six extraction invocations** (three images + three PDFs);
five repeats make 30. Calls are sequential with no benchmark-level retries.
The Replit reader's SDK permits two retries, so billed upstream requests can
exceed this count. Runpod has no adapter retries; cold starts and request timeouts
can still cost money.

- Runpod charges follow the configured endpoint's compute/pricing arrangement,
  including applicable cold-start/idle time; check the Runpod billing dashboard.
- Replit AI Integrations use the existing integration, require no additional API
  key, and charge the user's Replit credits. The current application reader uses
  `gpt-5.4-mini`; this benchmark does not change it.
- There is **no fixed dollar estimate or spending cap** here. Token usage and
  actual billed cost are not exposed by the reader and are not invented in the
  report. Consult billing before opting in; the call-count limit is not a budget.
- The selected provider receives synthetic document pixels. No credentials,
  endpoint URLs or upstream error bodies are included in reports.

### Report and interpretation

Console output lists each field's expected value, extracted value and PASS/FAIL,
including every line's description, quantity, unit price and amount. JSON reports
include the same comparisons, provider/model, UTC timestamps, repeat index,
latency, manifest/input SHA-256 fingerprints, extraction failures and aggregate
exact-field and exact-invoice agreement. Failed extractions count as misses and
are never silently dropped. Reports are timestamped in the generated directory.

Scoring is strict after the application's normalization: no fuzzy TIN matching,
digit stripping, date guessing, monetary tolerance or recalculation. Missing
values remain missing; a faint date is expected exactly, a blank date is null.
An arithmetically wrong printed total is a **correct extraction** when preserved.
The existing rules may appropriately flag it for human correction.
Exit code 0 means all fields matched (or offline generation succeeded), 1 means
any live mismatch/failure, and 2 means invalid command/setup/local execution.

Model outputs can vary even with temperature zero, identical inputs or the same
model name. Provider deployments can change. Repeat comparisons should retain
provider/model, input hashes and timestamps. This tiny synthetic corpus is a
regression probe, **not** representative accuracy, confidence calibration or a
production acceptance threshold. A perfect run does not remove human review.

## Routine verification

```sh
pnpm --filter @workspace/api-server test
# Or just the benchmark's offline tests:
node --test server/ocr/benchmark/benchmark.test.mjs
```

These tests generate files locally, verify the production PDF rasterization path,
check strict scoring, guard the live opt-in and use an injected fake extractor
for report behavior. They never contact providers, even when credentials exist.
Do not add paid live commands to CI, startup, routine tests or merge validation.

No live benchmark was run when introducing this harness. Earlier anecdotal live
checks in `verification.md` are not scored results for this corpus. Generate a
real report with the explicit opt-in command before claiming measured accuracy.
