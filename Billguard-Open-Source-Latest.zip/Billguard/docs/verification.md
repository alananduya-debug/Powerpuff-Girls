# Invoice Assistant verification

Verified 2026-10-24.

## Automated checks

- API server, Billguard web app and shared libraries TypeScript checks: passed.
- The full `pnpm run typecheck` also checks the separate overview-film artifact,
  which currently fails with missing DOM types and existing animation typing
  errors. No film files were changed by the authentication work.
- API automated test suite includes the original regression checks plus
  status-access and visibility-transition checks.
- Validation cases include missing/impossible/future dates; missing, malformed and
  supplier-mismatched TIN; duplicates; missing fields; invalid currency; missing
  or negative amounts; subtotal and total discrepancies; cent rounding.
- Workflow cases cover all three submitting roles; both approving roles; pending
  statuses; blocking errors; self-approval prevention; required return/rejection
  reasons; final-state locking.
- HTTP integration tests use an isolated temporary SQLite database and generated
  encrypted uploads. They do not mutate preview or archived invoice data.
- Corrections tests cover freshly recomputed warnings, clearing fields, supplier
  changes, malformed line rollback, and attempts to dismiss blocking warnings.
- Other checks cover encryption/tampering, masking, unknown demo identity,
  protected reveals, sample upload for each role, MIME spoofing, cached-filename
  spoofing, records and audit entries.
- OCR normalization tests also cover decimal strings, grouped thousands, blank
  values and ambiguous strings. Numeric strings are not silently discarded.
- Synthetic extraction fixtures now connect normalization to rule messages and
  correction recommendations for dates, TINs and arithmetic. Repeated-digit TINs
  receive a comparison warning, not a claim of official invalidity; a supplier
  mismatch remains a blocking error.
- HTTP regressions exercise each correctable extraction mistake against both
  reviewers in both pending statuses, then correct it and approve. Approval
  rechecks duplicates introduced after submission and does not trust an empty
  saved warning list.
- Malformed model JSON and extraction shapes are rejected; unreadable or
  ambiguous values stay missing rather than becoming zero. Invalid live PDF
  reading cannot fall back to a matching sample filename. Failed account
  extraction returns an actionable 422 error and creates no invoice, activity
  or encrypted file.
- The expanded API suite passed all 167 tests. API/shared-library and Billguard
  typechecks passed; the separate film still has the existing errors noted above.
- Permission checks cover all six statuses for all three roles: list membership,
  direct details, files, invoice activity, protected reveals and forbidden writes.
  Additional checks cover role-scoped totals, records, exports and timeline;
  submission/return/final-decision visibility changes; and accountant submission
  during upload/sample loading.

## Runtime checks

- API and web workflows started successfully.
- `/api/demo/info` confirmed demo mode and configured live AI.
- Desktop preview rendered with synthetic-data warning and sample controls;
  no browser errors were reported in the captured view.
- After the extraction-regression changes, API and web workflows restarted
  cleanly, the API health check passed, and `/demo` still displayed the format/
  supplier-list-only TIN disclaimer. These new tests are deterministic and make
  no live AI-provider requests; they do not establish image-reading accuracy.
- A real AI-provider request succeeded. A synthetic image extraction correctly
  returned a missing date and an incorrect TIN, but miscounted repeated TIN digits
  in one check. That is an extraction-accuracy limitation, not official TIN
  validation; human comparison remains necessary.
- A live upload through the running server succeeded and flagged the missing date
  and mismatched TIN. It returned missing monetary fields rather than the expected
  arithmetic discrepancy, so the live image accuracy check did **not** fully pass.
  Numeric-string normalization and stronger extraction instructions were added
  and covered by automated tests; live image extraction was not re-tested after
  that change. The invoice remained blocked from approval.

## Boundaries

### Reproducible live OCR accuracy benchmark

See [the synthetic pixel benchmark](ocr-benchmark.md) for ground-truth PNG and
image-only PDF fixtures, exact per-field scoring and paid-provider opt-in.
`pnpm ocr:benchmark` only generates fixtures offline; live runs require both
`--live` and `--accept-provider-costs`. Routine tests verify rasterization,
scoring and opt-in safety without contacting a provider. Incorrect printed
subtotals/totals remain the extraction ground truth. No live accuracy score is
claimed from those offline tests; provider costs and nondeterminism are documented.

The authentication update was checked in one browser pass: public landing, demo
role switching/sample loading/download, signed-in Owner and Staff workspaces,
reload persistence, sign-out, direct protected navigation, spoofed role headers
and an unassigned account's denied-access message. Account data stayed empty and
separate from synthetic demo data. No real invoice uploads or live OCR were used
in that pass. No load test was run. See `docs/authentication.md` for automated
signed-session and permission tests.

No production deployment, official tax-authority API,
tenant-isolation guarantee or security certification is included. The demo must
use synthetic data only. Live AI may incur credit usage and shares the supplied
document with its provider.
